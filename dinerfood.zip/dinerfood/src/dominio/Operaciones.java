package dominio;

import javax.swing.JOptionPane;


public class Operaciones {

    public Nodo1 cima;
    public Nodo1 first;
    public Nodo1 last;
    
    Operaciones() {
        cima = first = last = null;
    }
    
    //Insertar Inicio Pila
public void push (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (cima == null)
            cima = nuevo;
        else {
            nuevo.siguiente = cima;
            cima = nuevo;
        }
    }
    
    //Borrar Inicio Pila
public void pop() {
        if (cima != null)
            cima = cima.siguiente;
    }
    
    //Insertar final cola
public void enqueue (String autor, Integer titulo) {
    Nodo1 nuevo = new Nodo1();
    nuevo.autor = autor;
    nuevo.titulo = titulo;
    nuevo.siguiente = null;
    if (first == null)
        first = last = nuevo;
    else {
        last.siguiente = nuevo;
        last = nuevo;
    }
} 
    //Borrar Inicio Cola
public void dequeue () {
        if (first != null)
            first = first.siguiente;
    }
    

public void imprimircola(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
            
        }
        else
            System.out.println("Lista vacia");
        
    }
public void imprimirpila() {

     if (cima != null) {
         Nodo1 nuevo = new Nodo1();
         Nodo1 aux;
         aux = cima;

         while(aux != null) {
             JOptionPane.showMessageDialog(null,aux.autor + "  \t  " + aux.titulo);
             System.out.println(aux.autor + "  \t " + aux.titulo);

             aux = aux.siguiente;
         }

     }
     else
         System.out.println("Lista vacia");

 }
public boolean isEmpty(){
        if (cima == null)
             return true;
        else
        return false;
    }
      
   
    //Insertar Inicio Pila
    public void push2 (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (cima == null)
            cima = nuevo;
        else {
            nuevo.siguiente = cima;
            cima = nuevo;
        }
    }
    
    //Borrar Inicio Pila
    public void pop2() {
        if (cima != null)
            cima = cima.siguiente;
    }
    
    
    
    
    //Insertar final cola
    public void enqueue2 (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
     
    //Borrar Inicio Cola
    public void dequeue2 () {
        if (first != null)
            first = first.siguiente;
    }
    
   public void imprimircola2(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
            
        }
        else
            System.out.println("Lista vacia");
        
    }
   
   public void imprimirpila2() {
        
        if (cima != null) {
            Nodo1 nuevo = new Nodo1();
            Nodo1 aux;
            aux = cima;
            
            while(aux != null) {
                JOptionPane.showMessageDialog(null,aux.autor + "  \t  " + aux.titulo);
                System.out.println(aux.autor + "  \t " + aux.titulo);
                
                aux = aux.siguiente;
            }
            
        }
        else
            System.out.println("Lista vacia");
        
    }
   public boolean isEmpty2(){
        if (cima == null)
             return true;
        else
        return false;
    }
   
   
   
   
     public void enqueuemesa1Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa1Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
       
       
        public void enqueuemesa2Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa2Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia2(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa3Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa3Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia3(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa4Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa4Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia4(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa5Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa5Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia5(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa6Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa6Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia6(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa7Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa7Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia7(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa8Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa8Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia8(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa9Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa9Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia9(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa10Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa10Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia10(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa11Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa11Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia11(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa12Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa12Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia12(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa13Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa13Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia13(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa14Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa14Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia14(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa15Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa15Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia15(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa16Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa16Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia16(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa17Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa17Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia17(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa18Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa18Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia18(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa19Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa19Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia19(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa20Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa20Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia20(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa21Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa21Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia21(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa22Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa22Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia22(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa23Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa23Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia23(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa24Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa24Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia24(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa25Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa25Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia25(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa26Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa26Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia26(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa27Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa27Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia27(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa28Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa28Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia28(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa29Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa29Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia29(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa30Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa30Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia30(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
  public void enqueuemesa31Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa31Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia31(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
 public void enqueuemesa32Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa32Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia32(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa33Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa33Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia33(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
        public void enqueuemesa34Paciencia (String autor, Integer titulo) {
        Nodo1 nuevo = new Nodo1();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    
    //Borrar paciencia
    public void dequeuemesa34Paciencia() {
        if (first != null)
            first = first.siguiente;
    }
       public void imprimirPaciencia34(String autor,Integer titulo) {
        
          
            Nodo1 nuevo = new Nodo1();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
        }
        else
            System.out.println("Lista vacia");
        
    }
    
}
