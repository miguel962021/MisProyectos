package dominio;

import javax.swing.JOptionPane;


public class sinPaciencia {

    public Nodo2 cima;
    public Nodo2 first;
    public Nodo2 last;
    
    sinPaciencia() {
        cima = first = last = null;
    }
    
    //Insertar Inicio Pila
 //Insertar final cola
    public void enqueue3 (String autor, String titulo) {
        Nodo2 nuevo = new Nodo2();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
     
    //Borrar Inicio Cola
    public void dequeue3 () {
        if (first != null)
            first = first.siguiente;
    }
    
   public void imprimircola3(String autor,String titulo) {
        
          
            Nodo2 nuevo = new Nodo2();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
           
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                
                first = first.siguiente;
            }
            
        }
        else
            System.out.println("Lista vacia");
        
    }

    
}
