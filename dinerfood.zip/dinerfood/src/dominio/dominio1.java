/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;
import dominio.Operaciones;
import javax.swing.JOptionPane;
/**
 *
 * @author Miguel
 */
public class dominio1 {

sinPaciencia test00 = new sinPaciencia();
    
Operaciones test = new Operaciones();

Operaciones2 test2 = new Operaciones2();
Operaciones3 test3 = new Operaciones3();
Operaciones4 test4 = new Operaciones4();
Operaciones5 test5 = new Operaciones5();
Operaciones6 test6 = new Operaciones6();
Operaciones7 test7 = new Operaciones7();
Operaciones8 test8 = new Operaciones8();
Operaciones9 test9 = new Operaciones9();
Operaciones10 test10 = new Operaciones10();
Operaciones11 test11 = new Operaciones11();
Operaciones12 test12 = new Operaciones12();
Operaciones13 test13 = new Operaciones13();
Operaciones14 test14 = new Operaciones14();
Operaciones15 test15 = new Operaciones15();
Operaciones16 test16 = new Operaciones16();
Operaciones17 test17 = new Operaciones17();
Operaciones18 test18 = new Operaciones18();
Operaciones19 test19 = new Operaciones19();
Operaciones20 test20 = new Operaciones20();
Operaciones21 test21 = new Operaciones21();


int paciencial=100;
int paciencia2=100;






public   int paciencia1x=1000;
public   int paciencia1x2=1000;
public   int paciencia1x3=1000;
public   int paciencia1x4=1000;
public   int paciencia1x5=1000;
public   int paciencia1x6=1000;
public   int paciencia1x7=1000;
public   int paciencia1x8=1000;
public   int paciencia1x9=1000;
public   int paciencia1x10=1000;
public   int paciencia1x11=1000;
public   int paciencia1x12=1000;
public   int paciencia1x13=1000;
public   int paciencia1x14=1000;
public   int paciencia1x15=1000;
public   int paciencia1x16=1000;
public   int paciencia1x17=1000;
public   int paciencia1x18=1000;
public   int paciencia1x19=1000;
public   int paciencia1x20=1000;
public   int paciencia1x21=1000;
public   int paciencia1x22=1000;
public   int paciencia1x23=1000;
public   int paciencia1x24=1000;
public   int paciencia1x25=1000;
public   int paciencia1x26=1000;
public   int paciencia1x27=1000;
public   int paciencia1x28=1000;
public   int paciencia1x29=1000;
public   int paciencia1x30=1000;
public   int paciencia1x31=1000;
public   int paciencia1x32=1000;
public   int paciencia1x33=1000;
public   int paciencia1x34=1000;
public   int paciencia1x35=1000;









public int menus[]= new int [5];
public int datos1[]= new int [6];
public int datos2[]= new int [4];
public int datos3[]= new int [2];
public int datos4[]= new int [15];
public int cola[][] = new int [10][6];//mesas de 6
public int cola2[][] = new int [5][4];//mesas de 4
public int cola3[][] = new int [4][2];//
public int cola4[] = new int [15];
public int cosina[]= new int [4];
public int despachos[][]= new int [20][5];

public String mensaje1 = "Asiento ocupado";
public String mensaje2 = "La mesa esta llena!";
public String mensaje3 ="Datos incorrectos";
public String mensaje4 = "La persona tomó asiento";
public String mensaje5 = "Se nos acabo este platillo";
public String mensaje6 = "Su orden esta siendo preparada";
public String mensaje7 = "Puede pasar a la caja a pagar su orden";
public String mensaje8 = "Ya ha sido limpiada la mesa";
public String mensajeMenu="1.La original\n2.Hamgurpizza\n3.Hambueguesa de ternera\n4.Sandwich de cerdo\n5.Sandwich de vegetales";
public String mensaje9 = "El pedido fue despachado";

public  int bb=0;


public  String orden="La original";
public  String orden2="Hamgurpizza";
public  String orden3=".Hambueguesa de ternera";
public  String orden4="Sandwich de cerdo";
public  String orden5="Sandwich de vegetales";


public  String comida="♨🍽";
public  String MESA1="Mesa1";
public  String MESA2="Mesa2";
public  String MESA3="Mesa3";
public  String MESA4="Mesa4";
public  String MESA5="Mesa5";
public  String MESA6="Mesa6";
public  String MESA7="Mesa7";
public  String MESA8="Mesa8";
public  String MESA9="Mesa9";
public  String MESA10="Mesa10";
public  String MESA11="Mesa11";
public  String MESA12="Mesa12";
public  String MESA13="Mesa13";
public  String MESA14="Mesa14";
public  String MESA15="Mesa15";
public  String MESA16="Mesa16";
public  String MESA17="Mesa17";
public  String MESA18="Mesa18";
public  String MESA19="Mesa19";
public  String barra20="Barra";



public  void pacienciasG(){
    if ( paciencia1x<=0|| paciencia1x2<=0||paciencia1x3<=0||paciencia1x4<=0||paciencia1x5<=0||paciencia1x6<=0||paciencia1x7<=0||paciencia1x8<=0||paciencia1x9<=0||paciencia1x10<=0||paciencia1x11<=0|| paciencia1x12<=0|| paciencia1x13<=0|| paciencia1x14<=0|| paciencia1x15<=0|| paciencia1x16<=0|| paciencia1x17<=0|| paciencia1x18<=0|| paciencia1x19<=0|| paciencia1x20<=0|| paciencia1x21<=0|| paciencia1x22<=0|| paciencia1x23<=0|| paciencia1x24<=0||paciencia1x25<=0||paciencia1x26<=0||paciencia1x27<=0||paciencia1x28<=0||paciencia1x29<=0||paciencia1x30<=0||paciencia1x31<=0||paciencia1x32<=0|| paciencia1x33<=0||paciencia1x34<=0||paciencia1x35<=0){
        
    
      if (paciencia1x<=0){
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 1 perdio la paciencia");
           test.dequeuemesa1Paciencia();
           paciencia1x=1000;
           test00.enqueue3("mesa1 paga la midad",  "☹");
           
      }
      if (paciencia1x2<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 2 perdio la paciencia");
           test.dequeuemesa2Paciencia();
           paciencia1x2=1000;
           test00.enqueue3("mesa2 paga la midad", "☹");
           
      }
      if (paciencia1x3<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 3 perdio la paciencia");
           test.dequeuemesa3Paciencia();
           paciencia1x3=1000;
           test00.enqueue3("mesa3 paga la midad", "☹");
      }
      if (paciencia1x4<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 4 perdio la paciencia");
           test.dequeuemesa4Paciencia();
           paciencia1x4=1000;
            test00.enqueue3("mesa4 paga la midad", "☹");
      }
      if (paciencia1x5<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 5 perdio la paciencia");
           test.dequeuemesa5Paciencia();
           paciencia1x5=1000;
            test00.enqueue3("mesa5 paga la midad", "☹");
      }
      if (paciencia1x6<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 6 perdio la paciencia");
           test.dequeuemesa6Paciencia();
           paciencia1x6=1000;
            test00.enqueue3("mesa6 paga la midad", "☹");
      }
      if (paciencia1x7<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 7 perdio la paciencia");
           test.dequeuemesa7Paciencia();
           paciencia1x7=1000;
            test00.enqueue3("mesa7 paga la midad", "☹");
      }
      if (paciencia1x8<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 8 perdio la paciencia");
           test.dequeuemesa8Paciencia();
           paciencia1x8=1000;
            test00.enqueue3("mesa8 paga la midad", "☹");
      }
      if (paciencia1x9<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 9 perdio la paciencia");
           test.dequeuemesa9Paciencia();
           paciencia1x9=1000;
            test00.enqueue3("mesa9 paga la midad", "☹");
      }
      if (paciencia1x10<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 10 perdio la paciencia");
           test.dequeuemesa10Paciencia();
           paciencia1x10=1000;
            test00.enqueue3("mesa10 paga la midad", "☹");
      }
      
            if (paciencia1x11<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 11 perdio la paciencia");
           test.dequeuemesa11Paciencia();
           paciencia1x11=1000;
            test00.enqueue3("mesa11 paga la midad", "☹");
      }      if (paciencia1x12<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 12 perdio la paciencia");
           test.dequeuemesa12Paciencia();
           paciencia1x12=1000;
            test00.enqueue3("mesa12 paga la midad", "☹");
      }      if (paciencia1x13<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 13 perdio la paciencia");
           test.dequeuemesa13Paciencia();
           paciencia1x13=1000;
            test00.enqueue3("mesa13 paga la midad", "☹");
      }      if (paciencia1x14<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 14 perdio la paciencia");
           test.dequeuemesa14Paciencia();
           paciencia1x14=1000;
            test00.enqueue3("mesa14 paga la midad", "☹");
      }      if (paciencia1x15<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 15 perdio la paciencia");
           test.dequeuemesa15Paciencia();
           paciencia1x15=1000;
            test00.enqueue3("mesa15 paga la midad", "☹");
      }      if (paciencia1x16<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 16 perdio la paciencia");
           test.dequeuemesa16Paciencia();
           paciencia1x16=1000;
            test00.enqueue3("mesa16 paga la midad", "☹");
      }      if (paciencia1x17<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 17 perdio la paciencia");
           test.dequeuemesa17Paciencia();
           paciencia1x17=1000;
            test00.enqueue3("mesa17 paga la midad", "☹");
      }      if (paciencia1x18<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 18 perdio la paciencia");
           test.dequeuemesa18Paciencia();
           paciencia1x18=1000;
            test00.enqueue3("mesa18 paga la midad", "☹");
      }      if (paciencia1x19<=0){
           JOptionPane.showMessageDialog(null,"El grupo grupo  de la mesa 19 perdio la paciencia");
           test.dequeuemesa19Paciencia();
           paciencia1x19=1000;
            test00.enqueue3("mesa19 paga la midad", "☹");
      }      if (paciencia1x20<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 1  perdio la paciencia");
           test.dequeuemesa20Paciencia();
           paciencia1x20=1000;
            test00.enqueue3("La persona de la barra asiento 1 paga la midad", "☹");
      }      if (paciencia1x21<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 2 perdio la paciencia");
           test.dequeuemesa21Paciencia();
           paciencia1x21=1000;
            test00.enqueue3("La persona de la barra asiento 2 paga la midad", "☹");
      }      if (paciencia1x22<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 3 perdio la paciencia");
           test.dequeuemesa22Paciencia();
           paciencia1x22=1000;
            test00.enqueue3("La persona de la barra asiento 3 paga la midad", "☹");
      }      if (paciencia1x23<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 4 perdio la paciencia");
           test.dequeuemesa23Paciencia();
           paciencia1x23=1000;
            test00.enqueue3("La persona de la barra asiento 4 paga la midad", "☹");
      }      if (paciencia1x24<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 5 perdio la paciencia");
           test.dequeuemesa24Paciencia();
           paciencia1x24=1000;
            test00.enqueue3("La persona de la barra asiento 5 paga la midad", "☹");
      }      if (paciencia1x25<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 6 perdio la paciencia");
           test.dequeuemesa25Paciencia();
           paciencia1x25=1000;
            test00.enqueue3("La persona de la barra asiento 6 paga la midad", "☹");
      }      if (paciencia1x26<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 7 perdio la paciencia");
           test.dequeuemesa26Paciencia();
           paciencia1x26=1000;
            test00.enqueue3("La persona de la barra asiento 7 paga la midad", "☹");
      }      if (paciencia1x27<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 8 perdio la paciencia");
           test.dequeuemesa27Paciencia();
           paciencia1x27=1000;
            test00.enqueue3("La persona de la barra asiento 8 paga la midad", "☹");
      }      if (paciencia1x28<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 9 perdio la paciencia");
           test.dequeuemesa28Paciencia();
           paciencia1x28=1000;
            test00.enqueue3("La persona de la barra asiento 9 paga la midad", "☹");
      }      if (paciencia1x29<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 10 perdio la paciencia");
           test.dequeuemesa29Paciencia();
           paciencia1x29=1000;
            test00.enqueue3("La persona de la barra asiento 10 paga la midad", "☹");
      }      if (paciencia1x30<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 11 perdio la paciencia");
           test.dequeuemesa30Paciencia();
           paciencia1x30=1000;
            test00.enqueue3("La persona de la barra asiento 11 paga la midad", "☹");
      }
      if (paciencia1x31<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 12 perdio la paciencia");
           test.dequeuemesa30Paciencia();
           paciencia1x30=1000;
            test00.enqueue3("La persona de la barra asiento 12 paga la midad", "☹");
      }
      if (paciencia1x32<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 13 perdio la paciencia");
           test.dequeuemesa30Paciencia();
           paciencia1x33=1000;
            test00.enqueue3("La persona de la barra asiento 13 paga la midad", "☹");
      }
      if (paciencia1x34<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 14 perdio la paciencia");
           test.dequeuemesa30Paciencia();
           paciencia1x30=1000;
            test00.enqueue3("La persona de la barra asiento 14 paga la midad", "☹");
      }
      if (paciencia1x35<=0){
           JOptionPane.showMessageDialog(null,"La persona sentada en la barra en el asiento 15 perdio la paciencia");
           test.dequeuemesa30Paciencia();
           paciencia1x30=1000;
            test00.enqueue3("La persona de la barra asiento 15 paga la midad", "☹");
      }
  
    }else{
    
        System.out.println("errrrrrr");
    }      //imprimir();
 }




public  void fila(){
       int min = 1;
       int max = 7;
       int numero =(int)(Math.random()*(max-min))+min;
       int aux = numero;
       test.enqueue("☺", aux);
       this.bb= aux;
       //test.enqueue("☺", (int) (Math.random()*(max-min))+min);
       imprimir();
 }

public  void despachar(){
    int mesa =0;
      
    do{
    mesa = Integer.parseInt(JOptionPane.showInputDialog("Para entregar las ordenes ingrese una mesa del 1 al 19. En caso de que sea la barra digite 20.\nEn caso de salir digite 0")); 

    switch (mesa) {
        case 1:
            if (test2.cima.autor.equals(MESA1)) {
                System.out.println("si es igual");
          
            test2.enqueuemesa(MESA1,comida );
            test.equals(MESA1);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA1);
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
             //JOptionPane.showMessageDialog(null,paciencia1x2+"2");
              // JOptionPane.showMessageDialog(null,paciencia1x34+"      34");
                }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 1 perdio la paciencia y sale sin pagar");
           test.dequeuemesa1Paciencia();
           paciencia1x=1000;
           test00.enqueue3("mesa1 sale sin  pagar",  "☹");
                System.out.println("no es igual");
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
            }
            break;
        case 2:
             if (test2.cima.autor.equals(MESA2)) {
                System.out.println("si es igual");
           
            test3.enqueuemesa(MESA2, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA2);
            paciencia1x=paciencia1x-3;
            //paciencia1x2=paciencia1x2-50;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
           // JOptionPane.showMessageDialog(null,paciencia1x+"1");
            //  JOptionPane.showMessageDialog(null,paciencia1x2+"2");
             }
            else{
                JOptionPane.showMessageDialog(null,"El grupo  de la mesa 2 perdio la paciencia y sale sin pagar");
                test.dequeuemesa2Paciencia();
                paciencia1x=1000;
                test00.enqueue3("mesa2 sale sin pagar",  "☹");
                System.out.println("no es igual");
                paciencia1x=paciencia1x-3;
            //paciencia1x2=paciencia1x2-50;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
            }
            break;
        case 3:
             if (test2.cima.autor.equals(MESA3)) {
                System.out.println("si es igual");
            test4.enqueuemesa(MESA3, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA3);
            paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            //paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
            }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 3 perdio la paciencia y sale sin pagar");
           test.dequeuemesa3Paciencia();
           paciencia1x3=1000;
           test00.enqueue3("mesa3 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            //paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
                
             }
            break;
        case 4:
         if (test2.cima.autor.equals(MESA4)) {
                System.out.println("si es igual");
            test5.enqueuemesa(MESA4, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA4);
            paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            //paciencia1x4=paciencia1x4-50;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
            }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 4 perdio la paciencia y sale sin pagar");
           test.dequeuemesa4Paciencia();
           paciencia1x4=1000;
           test00.enqueue3("mesa4 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            //paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
                
         }
            break;
        case 5:
         if (test2.cima.autor.equals(MESA5)) {
                System.out.println("si es igual");
            test6.enqueuemesa(MESA5, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA5);
            paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
          //  paciencia1x5=paciencia1x5-50;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
               paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
            }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 5 perdio la paciencia y sale sin pagar");
           test.dequeuemesa5Paciencia();
           paciencia1x5=1000;
           test00.enqueue3("mesa5 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
                
         }
            break;
        case 6:
         if (test2.cima.autor.equals(MESA6)) {
                System.out.println("si es igual");
            test7.enqueuemesa(MESA6, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA6);
               paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
          //  paciencia1x6=paciencia1x6-50;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
               paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
            }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 6 perdio la paciencia y sale sin pagar");
           test.dequeuemesa6Paciencia();
           paciencia1x6=1000;
           test00.enqueue3("mesa6 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 7:
            if (test2.cima.autor.equals(MESA7)) {
                System.out.println("si es igual");
            test8.enqueuemesa(MESA7, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA7);
            paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
           // paciencia1x7=paciencia1x7-50;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 7 perdio la paciencia y sale sin pagar");
           test.dequeuemesa7Paciencia();
           paciencia1x7=1000;
           test00.enqueue3("mesa7 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 8:
        if (test2.cima.autor.equals(MESA8)) {
                System.out.println("si es igual");
            test9.enqueuemesa(MESA8, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA8);
            paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
           // paciencia1x8=paciencia1x8-50;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 8 perdio la paciencia y sale sin pagar");
           test.dequeuemesa8Paciencia();
           paciencia1x8=1000;
           test00.enqueue3("mesa8 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 9:
        if (test2.cima.autor.equals(MESA9)) {
                System.out.println("si es igual");
            test10.enqueuemesa(MESA9, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA9);
            paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
           // paciencia1x9=paciencia1x9-50;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
               paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 9 perdio la paciencia y sale sin pagar");
           test.dequeuemesa9Paciencia();
           paciencia1x9=1000;
           test00.enqueue3("mesa9 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 10:
        if (test2.cima.autor.equals(MESA10)) {
                System.out.println("si es igual");
            test11.enqueuemesa(MESA10, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA10);
            paciencia1x=paciencia1x-50;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
          //  paciencia1x10=paciencia1x10-50;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
               paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 10 perdio la paciencia y sale sin pagar");
           test.dequeuemesa10Paciencia();
           paciencia1x10=1000;
           test00.enqueue3("mesa10 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 11:
        if (test2.cima.autor.equals(MESA11)) {
                System.out.println("si es igual");
            test12.enqueuemesa(MESA11, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA11);
            paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
         //   paciencia1x11=paciencia1x11-50;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 11 perdio la paciencia y sale sin pagar");
           test.dequeuemesa11Paciencia();
           paciencia1x11=1000;
           test00.enqueue3("mesa11 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 12:
        if (test2.cima.autor.equals(MESA12)) {
                System.out.println("si es igual");
            test13.enqueuemesa(MESA12, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA12);
            paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
           // paciencia1x12=paciencia1x12-50;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
               paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 12 perdio la paciencia y sale sin pagar");
           test.dequeuemesa12Paciencia();
           paciencia1x12=1000;
           test00.enqueue3("mesa12 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 13:
        if (test2.cima.autor.equals(MESA13)) {
                System.out.println("si es igual");
            test14.enqueuemesa(MESA13, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA13);
               paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
           // paciencia1x13=paciencia1x13-50;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
               paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 13 perdio la paciencia y sale sin pagar");
           test.dequeuemesa13Paciencia();
           paciencia1x13=1000;
           test00.enqueue3("mesa13 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 14:
        if (test2.cima.autor.equals(MESA14)) {
                System.out.println("si es igual");
            test15.enqueuemesa(MESA14, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA14);
               paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
           // paciencia1x14=paciencia1x14-50;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 14 perdio la paciencia y sale sin pagar");
           test.dequeuemesa14Paciencia();
           paciencia1x14=1000;
           test00.enqueue3("mesa14 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 15:
        if (test2.cima.autor.equals(MESA15)) {
                System.out.println("si es igual");
            test16.enqueuemesa(MESA15, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA15);
               paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            //paciencia1x15=paciencia1x15-50;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
               paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 15 perdio la paciencia y sale sin pagar");
           test.dequeuemesa15Paciencia();
           paciencia1x15=1000;
           test00.enqueue3("mesa15 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 16:
        if (test2.cima.autor.equals(MESA16)) {
                System.out.println("si es igual");
            test17.enqueuemesa(MESA16, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA16);
               paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            //paciencia1x16=paciencia1x16-50;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 16 perdio la paciencia y sale sin pagar");
           test.dequeuemesa16Paciencia();
           paciencia1x16=1000;
           test00.enqueue3("mesa16 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 17:
        if (test2.cima.autor.equals(MESA17)) {
                System.out.println("si es igual");
            test18.enqueuemesa(MESA17, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA17);
               paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            //paciencia1x17=paciencia1x17-50;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
               paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 17 perdio la paciencia y sale sin pagar");
           test.dequeuemesa17Paciencia();
           paciencia1x17=1000;
           test00.enqueue3("mesa17 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 18:
        if (test2.cima.autor.equals(MESA18)) {
                System.out.println("si es igual");
            test19.enqueuemesa(MESA18, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA18);
               paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            //paciencia1x18=paciencia1x18-50;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 18 perdio la paciencia y sale sin pagar");
           test.dequeuemesa18Paciencia();
           paciencia1x18=1000;
           test00.enqueue3("mesa18 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 19:
        if (test2.cima.autor.equals(MESA19)) {
                System.out.println("si es igual");
            test20.enqueuemesa(MESA19, comida);
            test2.pop();
            JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+MESA19);
               paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-3;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
           // paciencia1x19=paciencia1x19-50;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
              }
            else{
           JOptionPane.showMessageDialog(null,"El grupo  de la mesa 19 perdio la paciencia y sale sin pagar");
           test.dequeuemesa19Paciencia();
           paciencia1x19=1000;
           test00.enqueue3("mesa19 sale sin  pagar",  "☹");
                System.out.println("no es igual");
                     paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        case 20://falta aplicar logica
            //test21.enqueuemesa(barra20, comida);
            //test2.pop();
            //JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
           if (test2.cima.autor.equals(barra20)) {
                System.out.println("si es igual");
             int asiento = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero de asiento para entregar comida a una persona del 1 a 15"));
            switch (asiento) {
                case 1:
                   test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        //paciencia1x20=paciencia1x20-50;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 2:
                    test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                         paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        //paciencia1x21=paciencia1x21-50;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 3:
                  test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                    paciencia1x=paciencia1x-3;
                    paciencia1x2=paciencia1x2-3;
                    paciencia1x3=paciencia1x3-3;
                    paciencia1x4=paciencia1x4-3;
                    paciencia1x5=paciencia1x5-3;
                    paciencia1x6=paciencia1x6-3;
                    paciencia1x7=paciencia1x7-3;
                    paciencia1x8=paciencia1x8-3;
                    paciencia1x9=paciencia1x9-3;
                    paciencia1x10=paciencia1x10-3;
                    paciencia1x11=paciencia1x11-3;
                    paciencia1x12=paciencia1x12-3;
                    paciencia1x13=paciencia1x13-3;
                    paciencia1x14=paciencia1x14-3;
                    paciencia1x15=paciencia1x15-3;
                    paciencia1x16=paciencia1x16-3;
                    paciencia1x17=paciencia1x17-3;
                    paciencia1x18=paciencia1x18-3;
                    paciencia1x19=paciencia1x19-3;
                    paciencia1x20=paciencia1x20-3;
                    paciencia1x21=paciencia1x21-3;
                  //  paciencia1x22=paciencia1x22-50;
                    paciencia1x23=paciencia1x23-3;
                    paciencia1x24=paciencia1x24-3;
                    paciencia1x25=paciencia1x25-3;
                    paciencia1x26=paciencia1x26-3;
                    paciencia1x27=paciencia1x27-3;
                    paciencia1x28=paciencia1x28-3;
                    paciencia1x29=paciencia1x29-3;
                    paciencia1x30=paciencia1x30-3;
                    paciencia1x31=paciencia1x31-3;
                    paciencia1x32=paciencia1x32-3;
                    paciencia1x33=paciencia1x33-3;
                    paciencia1x34=paciencia1x34-3;
                    paciencia1x35=paciencia1x35-3;
                    break;
                case 4:
                    test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        //paciencia1x23=paciencia1x23-50;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 5:
                    test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                       // paciencia1x24=paciencia1x24-50;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 6:
                 test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                       // paciencia1x25=paciencia1x25-50;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 7:
                test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                       // paciencia1x26=paciencia1x26-50;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 8:
                test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                       // paciencia1x27=paciencia1x27-50;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 9:
                    test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                       // paciencia1x28=paciencia1x28-50;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 10:
                    test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                      //  paciencia1x29=paciencia1x29-50;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 11:
                    test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                      //  paciencia1x30=paciencia1x30-50;
                        paciencia1x31=paciencia1x31-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                    break;
                case 12:
                  test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                       // paciencia1x31=paciencia1x30-50;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                        
                        
                        
                    break;
                case 13:
                  test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x30-3;
                       // paciencia1x32=paciencia1x32-50;
                        paciencia1x33=paciencia1x33-3;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                        
                    break;
                case 14:
                    test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                        paciencia1x31=paciencia1x30-3;
                        paciencia1x32=paciencia1x32-3;
                      //  paciencia1x33=paciencia1x33-50;
                        paciencia1x34=paciencia1x34-3;
                        paciencia1x35=paciencia1x35-3;
                        
                    break;
                case 15:
                 test21.enqueuemesa(barra20, comida);
                   test2.pop();
                   JOptionPane.showMessageDialog(null,this.mensaje9+" a la "+barra20);
                        paciencia1x=paciencia1x-3;
                        paciencia1x2=paciencia1x2-3;
                        paciencia1x3=paciencia1x3-3;
                        paciencia1x4=paciencia1x4-3;
                        paciencia1x5=paciencia1x5-3;
                        paciencia1x6=paciencia1x6-3;
                        paciencia1x7=paciencia1x7-3;
                        paciencia1x8=paciencia1x8-3;
                        paciencia1x9=paciencia1x9-3;
                        paciencia1x10=paciencia1x10-3;
                        paciencia1x11=paciencia1x11-3;
                        paciencia1x12=paciencia1x12-3;
                        paciencia1x13=paciencia1x13-3;
                        paciencia1x14=paciencia1x14-3;
                        paciencia1x15=paciencia1x15-3;
                        paciencia1x16=paciencia1x16-3;
                        paciencia1x17=paciencia1x17-3;
                        paciencia1x18=paciencia1x18-3;
                        paciencia1x19=paciencia1x19-3;
                        paciencia1x20=paciencia1x20-3;
                        paciencia1x21=paciencia1x21-3;
                        paciencia1x22=paciencia1x22-3;
                        paciencia1x23=paciencia1x23-3;
                        paciencia1x24=paciencia1x24-3;
                        paciencia1x25=paciencia1x25-3;
                        paciencia1x26=paciencia1x26-3;
                        paciencia1x27=paciencia1x27-3;
                        paciencia1x28=paciencia1x28-3;
                        paciencia1x29=paciencia1x29-3;
                        paciencia1x30=paciencia1x30-3;
                       paciencia1x31=paciencia1x30-3;
                        paciencia1x32=paciencia1x32-3;
                        paciencia1x33=paciencia1x33-3;
                       // paciencia1x34=paciencia1x34-50;
                        paciencia1x35=paciencia1x35-3;
                        
                    break;
                default:
                    break;
                   
                }
            }
            else{
           JOptionPane.showMessageDialog(null,"El pedido no corresponde a la barra");
           //test.dequeuemesa1Paciencia();
           //paciencia1x=1000;
           // test00.enqueue3("persona de la barra sale sin pagar sale sin  pagar",  "☹");
            System.out.println("no es igual");
            paciencia1x=paciencia1x-3;
            paciencia1x2=paciencia1x2-3;
            paciencia1x3=paciencia1x3-50;
            paciencia1x4=paciencia1x4-3;
            paciencia1x5=paciencia1x5-3;
            paciencia1x6=paciencia1x6-3;
            paciencia1x7=paciencia1x7-3;
            paciencia1x8=paciencia1x8-3;
            paciencia1x9=paciencia1x9-3;
            paciencia1x10=paciencia1x10-3;
            paciencia1x11=paciencia1x11-3;
            paciencia1x12=paciencia1x12-3;
            paciencia1x13=paciencia1x13-3;
            paciencia1x14=paciencia1x14-3;
            paciencia1x15=paciencia1x15-3;
            paciencia1x16=paciencia1x16-3;
            paciencia1x17=paciencia1x17-3;
            paciencia1x18=paciencia1x18-3;
            paciencia1x19=paciencia1x19-3;
            paciencia1x20=paciencia1x20-3;
            paciencia1x21=paciencia1x21-3;
            paciencia1x22=paciencia1x22-3;
            paciencia1x23=paciencia1x23-3;
            paciencia1x24=paciencia1x24-3;
            paciencia1x25=paciencia1x25-3;
            paciencia1x26=paciencia1x26-3;
      
            paciencia1x27=paciencia1x27-3;
            paciencia1x28=paciencia1x28-3;
            paciencia1x29=paciencia1x29-3;
            paciencia1x30=paciencia1x30-3;
            paciencia1x31=paciencia1x31-3;
            paciencia1x32=paciencia1x32-3;
            paciencia1x33=paciencia1x33-3;
            paciencia1x34=paciencia1x34-3;
            paciencia1x35=paciencia1x35-3;
                
         }
            break;
        default:
            
            JOptionPane.showMessageDialog(null,this.mensaje3);
            
            break;
    }
  }while(mesa !=0);      
 }
 
public void cosina(){
     test2.imprimirpila();
     test2.isEmpty();
    
  }
    
  public void iniciar() {     
    int mesa = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un mesa del 1 al 10 para sentar al grupo de personas"));
    while (bb>0) {         
       int asiento= this.bb; 
        if(mesa>=1 && mesa<=10 &&asiento>=1 && asiento<=6   ){
            if(cola[mesa-1][asiento-1]==0){
                cola[mesa-1][asiento-1]=1;
               JOptionPane.showMessageDialog(null,this.mensaje4);       
               this.bb--;
                switch (mesa) {
                    case 1:
                        //int paciencia1=100;
                        test.enqueuemesa1Paciencia("☺",this.paciencial);
                        paciencia1x=paciencial;
                        test.dequeue();
                        break;
                    case 2:
                       // int paciencia2=100;
                        test.enqueuemesa2Paciencia("☺",this.paciencia2);
                        paciencia1x2=this.paciencia2;
                        test.dequeue();
                        System.out.println("mesa 2");
                        break;
                        
                      case 3:
                        //int paciencia3=100;
                        test.enqueuemesa3Paciencia("☺",this.paciencial);
                        paciencia1x3=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 3");
                        break;
                      case 4:
                        //int paciencia4=100;
                        test.enqueuemesa4Paciencia("☺",this.paciencial);
                        paciencia1x4=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 4");
                        break;
                        
                         case 5:
                        //int paciencia5=100;
                        test.enqueuemesa5Paciencia("☺",this.paciencial);
                        paciencia1x5=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 5");
                        break;
                        
                         case 6:
                       // int paciencia6=100;
                        test.enqueuemesa6Paciencia("☺",this.paciencial);
                        paciencia1x6=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 6");
                        break;
                        
                         case 7:
                       // int paciencia7=100;
                        test.enqueuemesa7Paciencia("☺",this.paciencial);
                        paciencia1x7=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 7");
                        break;
                        
                         case 8:
                        //int paciencia8=100;
                        test.enqueuemesa8Paciencia("☺",this.paciencial);
                        paciencia1x8=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 8");
                        break;
                        
                         case 9:
                       // int paciencia9=100;
                        test.enqueuemesa9Paciencia("☺",this.paciencial);
                        paciencia1x9=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 9");
                        break;
                        
                         case 10:
                       //int paciencia10=100;
                        test.enqueuemesa10Paciencia("☺",this.paciencial);
                        paciencia1x10=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 10");
                        break;
                    default:
                        System.out.println("error");
                        break;
                }
               
             }else{
                bb=0;
            JOptionPane.showMessageDialog(null,this.mensaje1);
            }
        }else{
            JOptionPane.showMessageDialog(null,this.mensaje3);
        }
      }
  }
  public void iniciar2() {
       int mesa = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un mesa del 1 al 5 para sentar al grupo de personas"));
       while (bb>0) {         
    // int asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento para sentar a una persona"));
       int asiento= this.bb; 
       //int asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento para sentar a una persona"));
       
        if(mesa>=1 && mesa<=5 &&asiento>=1 && asiento<=4   ){
            if(cola2[mesa-1][asiento-1]==0){
                cola2[mesa-1][asiento-1]=1;
               JOptionPane.showMessageDialog(null,this.mensaje4);
               this.bb--;
               switch (mesa) {
                    case 1:
                        //int paciencia1=100;
                        test.enqueuemesa11Paciencia("☺",this.paciencial);
                        paciencia1x11=paciencial;
                        test.dequeue();
                        break;
                    case 2:
                       // int paciencia2=100;
                        test.enqueuemesa12Paciencia("☺",this.paciencial);
                        paciencia1x12=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 2");
                        break;
                        
                      case 3:
                        //int paciencia3=100;
                        test.enqueuemesa13Paciencia("☺",this.paciencial);
                        paciencia1x13=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 3");
                        break;
                      case 4:
                        //int paciencia4=100;
                        test.enqueuemesa14Paciencia("☺",this.paciencial);
                        paciencia1x14=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 4");
                        break;
                        
                         case 5:
                        //int paciencia5=100;
                        test.enqueuemesa15Paciencia("☺",this.paciencial);
                        paciencia1x15=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 5");
                        break;
               
                         default:
                        System.out.println("error");
                        break;
                }
              // test.dequeue(); 
             }else{
                bb=0;
            JOptionPane.showMessageDialog(null,this.mensaje1);
            }
        }else{
            JOptionPane.showMessageDialog(null,this.mensaje3);
        }
       }
  }
  public void iniciar3() {
       int mesa = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un mesa del 1 al 4 para sentar al grupo de personas"));
       while (bb>0) {         
           int asiento= this.bb; 
       //int asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento para sentar a una persona"));
       
        if(mesa>=1 && mesa<=4 &&asiento>=1 && asiento<=2   ){
            if(cola3[mesa-1][asiento-1]==0){
                cola3[mesa-1][asiento-1]=1;
               JOptionPane.showMessageDialog(null,this.mensaje4);
               this.bb--;
               
                 switch (mesa) {
                    case 1:
                        //int paciencia1=100;
                        test.enqueuemesa16Paciencia("☺",this.paciencial);
                        paciencia1x16=paciencial;
                        test.dequeue();
                        break;
                    case 2:
                       // int paciencia2=100;
                        test.enqueuemesa17Paciencia("☺",this.paciencial);
                        paciencia1x17=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 2");
                        break;
                        
                      case 3:
                        //int paciencia3=100;
                        test.enqueuemesa18Paciencia("☺",this.paciencial);
                        paciencia1x18=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 3");
                        break;
                      case 4:
                        //int paciencia4=100;
                        test.enqueuemesa19Paciencia("☺",this.paciencial);
                        paciencia1x19=this.paciencial;
                        test.dequeue();
                        System.out.println("mesa 4");
                        break;
                        
               
                         default:
                        System.out.println("error");
                        break;
                }
               
               test.dequeue(); 
             }else{
                bb=0;
            JOptionPane.showMessageDialog(null,this.mensaje1);
            }
        }else{
            JOptionPane.showMessageDialog(null,this.mensaje3);
        }
  }
  }
  public void iniciar4() {
      //falta desarrollar
       int asiento = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero de asiento para sentar a una persona del 1 a 15"));
       
        if(asiento>=1 && asiento<=15   ){
            if(cola4[asiento-1]==0){
                cola4[asiento-1]=1;
               JOptionPane.showMessageDialog(null,this.mensaje4);
                  switch (asiento) {
                    case 1:
                        //int paciencia1=100;
                        test.enqueuemesa20Paciencia("☺",this.paciencial);
                        paciencia1x20=paciencial;
                        test.dequeue();
                        break;
                    case 2:
                       // int paciencia2=100;
                        test.enqueuemesa21Paciencia("☺",this.paciencial);
                        paciencia1x21=this.paciencial;
                        test.dequeue();
                       
                        break;
                        
                      case 3:
                        //int paciencia3=100;
                        test.enqueuemesa22Paciencia("☺",this.paciencial);
                        paciencia1x22=this.paciencial;
                        test.dequeue();
                       
                        break;
                      case 4:
                        //int paciencia4=100;
                        test.enqueuemesa23Paciencia("☺",this.paciencial);
                        paciencia1x23=this.paciencial;
                        test.dequeue();
                       
                        break;
                        case 5:
                        //int paciencia1=100;
                        test.enqueuemesa24Paciencia("☺",this.paciencial);
                        paciencia1x24=paciencial;
                        test.dequeue();
                        break;
                    case 6:
                       // int paciencia2=100;
                        test.enqueuemesa25Paciencia("☺",this.paciencial);
                        paciencia1x25=this.paciencial;
                        test.dequeue();
                       
                        break;
                        
                      case 7:
                        //int paciencia3=100;
                        test.enqueuemesa26Paciencia("☺",this.paciencial);
                        paciencia1x26=this.paciencial;
                        test.dequeue();
                        
                        break;
                      case 8:
                        //int paciencia4=100;
                        test.enqueuemesa27Paciencia("☺",this.paciencial);
                        paciencia1x27=this.paciencial;
                        test.dequeue();
                       
                        break;
                        case 9:
                        //int paciencia1=100;
                        test.enqueuemesa28Paciencia("☺",this.paciencial);
                        paciencia1x28=paciencial;
                        test.dequeue();
                        break;
                    case 10:
                       // int paciencia2=100;
                        test.enqueuemesa29Paciencia("☺",this.paciencial);
                        paciencia1x29=this.paciencial;
                        test.dequeue();
                     
                        break;
                        
                      case 11:
                        //int paciencia3=100;
                        test.enqueuemesa30Paciencia("☺",this.paciencial);
                        paciencia1x30=this.paciencial;
                        test.dequeue();
                        
                        break;
                      case 12:
                        //int paciencia4=100;
                        test.enqueuemesa31Paciencia("☺",this.paciencial);
                        paciencia1x31=this.paciencial;
                        test.dequeue();
                        
                        break;
                        case 13:
                        //int paciencia1=100;
                        test.enqueuemesa32Paciencia("☺",this.paciencial);
                        paciencia1x32=paciencial;
                        test.dequeue();
                        break;
                    case 14:
                       // int paciencia2=100;
                        test.enqueuemesa33Paciencia("☺",this.paciencial);
                        paciencia1x33=this.paciencial;
                        test.dequeue();
                        
                        break;
                        case 15:
                       // int paciencia2=100;
                        test.enqueuemesa34Paciencia("☺",this.paciencial);
                        paciencia1x34=this.paciencial;
                        test.dequeue();
                        
                        break;
                        
                 
               
                         default:
                        System.out.println("error");
                        break;
                }
               
               test.dequeue(); 
             }else{
                
            JOptionPane.showMessageDialog(null,this.mensaje1);
            }
        }else{
            JOptionPane.showMessageDialog(null,this.mensaje3);
        }
  }
  public void imprimir(){
      test.imprimircola("",1); 
      
  } 
 

  
   public void reporte(){
    int mesa = Integer.parseInt(JOptionPane.showInputDialog("ELIJA UN NUMERO DE MESA DE 1 AL 10"));
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
   public void reporte2(){
    int mesa = Integer.parseInt(JOptionPane.showInputDialog("ELIJA UN NUMERO DE MESA DE 1 AL 5"));
    if(mesa>=1 && mesa<=5 ){
        for (int i = 0; i < 4; i++) {
            if(cola2[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
   public void reporte3(){
       int mesa = Integer.parseInt(JOptionPane.showInputDialog("ELIJA UN NUMERO DE MESA DE 1 AL 4"));
      
    if(mesa>=1 && mesa<=4 ){
        for (int i = 0; i < 2; i++) {
            if(cola3[mesa-1][i]==0){
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
   public void reporte4(){
       for (int i = 0; i < 15; i++) {
            if(cola4[i]==0){
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }
       
      
      
      
public void reporteMesa1(){
       int mesa = 1;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa2(){
       int mesa = 2;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa3(){
       int mesa = 3;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa4(){
       int mesa = 4;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa5(){
       int mesa = 5;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa6(){
       int mesa = 6;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa7(){
       int mesa = 7;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa8(){
       int mesa = 8;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa9(){
       int mesa = 9;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa10(){
       int mesa = 10;
       
    if(mesa>=1 && mesa<=10 ){
        for (int i = 0; i < 6; i++) {
            if(cola[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
                
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
        
public void reporteMesa11(){
    int mesa = 1;
    if(mesa>=1 && mesa<=5 ){
        for (int i = 0; i < 4; i++) {
            if(cola2[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa12(){
int mesa = 2;
if(mesa>=1 && mesa<=5 ){
    for (int i = 0; i < 4; i++) {
        if(cola2[mesa-1][i]==0){

            JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                   System.out.print(i+1+"  ");

        }else{
            JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
            System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
        }
        if((i+1) % 4 ==0){

            System.out.println("");
        }
    }
}else{
    JOptionPane.showMessageDialog(null,this.mensaje3);
}
}
public void reporteMesa13(){
    int mesa = 3;
    if(mesa>=1 && mesa<=5 ){
        for (int i = 0; i < 4; i++) {
            if(cola2[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa14(){
    int mesa = 4;
    if(mesa>=1 && mesa<=5 ){
        for (int i = 0; i < 4; i++) {
            if(cola2[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa15(){
    int mesa = 5;
    if(mesa>=1 && mesa<=5 ){
        for (int i = 0; i < 4; i++) {
            if(cola2[mesa-1][i]==0){

                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }

public void reporteMesa16(){
            int mesa = 1;
      
    if(mesa>=1 && mesa<=4 ){
        for (int i = 0; i < 2; i++) {
            if(cola3[mesa-1][i]==0){
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa17(){
       int mesa = 2;
      
    if(mesa>=1 && mesa<=4 ){
        for (int i = 0; i < 2; i++) {
            if(cola3[mesa-1][i]==0){
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa18(){
       int mesa = 3;
      
    if(mesa>=1 && mesa<=4 ){
        for (int i = 0; i < 2; i++) {
            if(cola3[mesa-1][i]==0){
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+ "ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
public void reporteMesa19(){
       int mesa = 4;
      
    if(mesa>=1 && mesa<=4 ){
        for (int i = 0; i < 2; i++) {
            if(cola3[mesa-1][i]==0){
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+" ¡ESTA LIBRE!");
                       System.out.print(i+1+"  ");
               
            }else{
                JOptionPane.showMessageDialog(null,"EL ASIENTO "+(i+1)+"ESTA OCUPADO!");
                System.out.println("EL ASIENTO"+i+"ESTA OCUPADO!");
            }
            if((i+1) % 4 ==0){
              
                System.out.println("");
            }
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }
     


public void menu1(){
    int persona =0;
    do{
        persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));
        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
            switch (comida) {
                case 1:
                    test2.push(MESA1, orden);
                    break;
                case 2:
                    test2.push(MESA1, orden2);
                    break;
                case 3:
                    test2.push(MESA1, orden3);
                    break;
                case 4:
                    test2.push(MESA1, orden4);
                    break;
                case 5:
                    test2.push(MESA1, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
    
    
         
}
public void menu2(){
        int persona =0;
        do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA2, orden);
                  //    paciencia1x=paciencia1x-50;
                    break;
                case 2:
                    test2.push(MESA2, orden2);
                  //  paciencia1x=paciencia1x-50;
                    break;
                case 3:
                    test2.push(MESA2, orden3);
                   // paciencia1x=paciencia1x-50;
                    break;
                case 4:
                    test2.push(MESA2, orden4);
                   // paciencia1x=paciencia1x-50;
                    break;
                case 5:
                    test2.push(MESA2, orden5);
                   // paciencia1x=paciencia1x-50;
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
} 
public void menu3(){
    int persona=0; 
    do{    
    persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA3, orden);
                    break;
                case 2:
                    test2.push(MESA3, orden2);
                    break;
                case 3:
                    test2.push(MESA3, orden3);
                    break;
                case 4:
                    test2.push(MESA3, orden4);
                    break;
                case 5:
                    test2.push(MESA3, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu4(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA4, orden);
                    break;
                case 2:
                    test2.push(MESA4, orden2);
                    break;
                case 3:
                    test2.push(MESA4, orden3);
                    break;
                case 4:
                    test2.push(MESA4, orden4);
                    break;
                case 5:
                    test2.push(MESA4, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu5(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA5, orden);
                    break;
                case 2:
                    test2.push(MESA5, orden2);
                    break;
                case 3:
                    test2.push(MESA5, orden3);
                    break;
                case 4:
                    test2.push(MESA5, orden4);
                    break;
                case 5:
                    test2.push(MESA5, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu6(){
    int persona =0;
    do{
        persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA6, orden);
                    break;
                case 2:
                    test2.push(MESA6, orden2);
                    break;
                case 3:
                    test2.push(MESA6, orden3);
                    break;
                case 4:
                    test2.push(MESA6, orden4);
                    break;
                case 5:
                    test2.push(MESA6, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu7(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA7, orden);
                    break;
                case 2:
                    test2.push(MESA7, orden2);
                    break;
                case 3:
                    test2.push(MESA7, orden3);
                    break;
                case 4:
                    test2.push(MESA7, orden4);
                    break;
                case 5:
                    test2.push(MESA7, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu8(){
    int persona=0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA8, orden);
                    break;
                case 2:
                    test2.push(MESA7, orden2);
                    break;
                case 3:
                    test2.push(MESA8, orden3);
                    break;
                case 4:
                    test2.push(MESA8, orden4);
                    break;
                case 5:
                    test2.push(MESA8, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu9(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA9, orden);
                    break;
                case 2:
                    test2.push(MESA9, orden2);
                    break;
                case 3:
                    test2.push(MESA9, orden3);
                    break;
                case 4:
                    test2.push(MESA9, orden4);
                    break;
                case 5:
                    test2.push(MESA9, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu10(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 6\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=6 ){
        if(datos1[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA10, orden);
                    break;
                case 2:
                    test2.push(MESA10, orden2);
                    break;
                case 3:
                    test2.push(MESA10, orden3);
                    break;
                case 4:
                    test2.push(MESA10, orden4);
                    break;
                case 5:
                    test2.push(MESA10, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu11(){
    int persona =0;
    do{
        persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 4\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=4 ){
        if(datos2[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA11, orden);
                    break;
                case 2:
                    test2.push(MESA11, orden2);
                    break;
                case 3:
                    test2.push(MESA11, orden3);
                    break;
                case 4:
                    test2.push(MESA11, orden4);
                    break;
                case 5:
                    test2.push(MESA11, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu12(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 4\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=4 ){
        if(datos2[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA12, orden);
                    break;
                case 2:
                    test2.push(MESA12, orden2);
                    break;
                case 3:
                    test2.push(MESA12, orden3);
                    break;
                case 4:
                    test2.push(MESA12, orden4);
                    break;
                case 5:
                    test2.push(MESA12, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu13(){
    int persona=0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 4\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=4 ){
        if(datos2[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA13, orden);
                    break;
                case 2:
                    test2.push(MESA13, orden2);
                    break;
                case 3:
                    test2.push(MESA13, orden3);
                    break;
                case 4:
                    test2.push(MESA13, orden4);
                    break;
                case 5:
                    test2.push(MESA13, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu14(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 4\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=4 ){
        if(datos2[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA14, orden);
                    break;
                case 2:
                    test2.push(MESA14, orden2);
                    break;
                case 3:
                    test2.push(MESA14, orden3);
                    break;
                case 4:
                    test2.push(MESA14, orden4);
                    break;
                case 5:
                    test2.push(MESA14, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu15(){
    int persona =0;
    do{
        persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 4\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=4 ){
        if(datos2[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA15, orden);
                    break;
                case 2:
                    test2.push(MESA15, orden2);
                    break;
                case 3:
                    test2.push(MESA15, orden3);
                    break;
                case 4:
                    test2.push(MESA15, orden4);
                    break;
                case 5:
                    test2.push(MESA15, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu16(){
        int persona =0;
        do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 2\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=2 ){
        if(datos3[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA16, orden);
                    break;
                case 2:
                    test2.push(MESA16, orden2);
                    break;
                case 3:
                    test2.push(MESA16, orden3);
                    break;
                case 4:
                    test2.push(MESA16, orden4);
                    break;
                case 5:
                    test2.push(MESA16, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu17(){
    int persona =0;
    do{
        persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 2\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=2 ){
        if(datos3[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA17, orden);
                    break;
                case 2:
                    test2.push(MESA17, orden2);
                    break;
                case 3:
                    test2.push(MESA17, orden3);
                    break;
                case 4:
                    test2.push(MESA17, orden4);
                    break;
                case 5:
                    test2.push(MESA17, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu18(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 2\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=2 ){
        if(datos3[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA18, orden);
                    break;
                case 2:
                    test2.push(MESA18, orden2);
                    break;
                case 3:
                    test2.push(MESA18, orden3);
                    break;
                case 4:
                    test2.push(MESA18, orden4);
                    break;
                case 5:
                    test2.push(MESA18, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu19(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 2\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=2 ){
        if(datos3[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(MESA19, orden);
                    break;
                case 2:
                    test2.push(MESA19, orden2);
                    break;
                case 3:
                    test2.push(MESA19, orden3);
                    break;
                case 4:
                    test2.push(MESA19, orden4);
                    break;
                case 5:
                    test2.push(MESA19, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}
public void menu20(){
    int persona =0;
    do{
         persona = Integer.parseInt(JOptionPane.showInputDialog("elija un numero de persona para atender  del 1 al 15\n.Ingrese ''0'' para salir"));
        int comida = Integer.parseInt(JOptionPane.showInputDialog(this.mensajeMenu));

        if(comida>=1 && comida<=5&&persona>=1 && persona<=15 ){
        if(datos4[persona-1]==0&&menus[comida-1]==0){
        
            switch (comida) {
                case 1:
                    test2.push(barra20, orden);
                    break;
                case 2:
                    test2.push(barra20, orden2);
                    break;
                case 3:
                    test2.push(barra20, orden3);
                    break;
                case 4:
                    test2.push(barra20, orden4);
                    break;
                case 5:
                    test2.push(barra20, orden5);
                    break;
                default:
                    break;
            }
        JOptionPane.showMessageDialog(null,this.mensaje6);
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje5);
        }
        }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
        }
        }while(persona !=0); 
}  
   
    
 
  
public void CUENTA(){
    test00.enqueue3("mesa 1", "☺");
    test.dequeuemesa1Paciencia();
    paciencia1x=1000;
    JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA2(){
 test00.enqueue3("mesa 2", "☺");
  test.dequeuemesa2Paciencia();
   paciencia1x2=1000;
  JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA3(){
     test.dequeuemesa3Paciencia();
test00.enqueue3("mesa 3", "☺");
 paciencia1x3=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA4(){
     test.dequeuemesa4Paciencia();
test00.enqueue3("mesa 4", "☺");
 paciencia1x4=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA5(){
     test.dequeuemesa5Paciencia();
test00.enqueue3("mesa 5", "☺");
 paciencia1x5=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA6(){
     test.dequeuemesa6Paciencia();
test00.enqueue3("mesa 6", "☺");
 paciencia1x6=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA7(){
     test.dequeuemesa7Paciencia();
test00.enqueue3("mesa 7", "☺");
 paciencia1x7=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA8(){
     test.dequeuemesa8Paciencia();
test00.enqueue3("mesa 8", "☺");
JOptionPane.showMessageDialog(null,this.mensaje7);
 paciencia1x8=1000;
} 
public void CUENTA9(){
     test.dequeuemesa9Paciencia();
test00.enqueue3("mesa 9","☺");
 paciencia1x9=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA10(){
     test.dequeuemesa10Paciencia();
test00.enqueue3("mesa 10", "☺");
 paciencia1x10=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA11(){
     test.dequeuemesa11Paciencia();
test00.enqueue3("mesa 11", "☺");
 paciencia1x11=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA12(){
     test.dequeuemesa12Paciencia();
test00.enqueue3("mesa 12", "☺");
 paciencia1x12=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA13(){
     test.dequeuemesa13Paciencia();
test00.enqueue3("mesa 13", "☺");
 paciencia1x13=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA14(){
     test.dequeuemesa14Paciencia();
test00.enqueue3("mesa 14", "☺");
 paciencia1x14=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA15(){
     test.dequeuemesa15Paciencia();
test00.enqueue3("mesa 15", "☺");
 paciencia1x15=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA16(){
test.dequeuemesa16Paciencia();
test00.enqueue3("mesa 16", "☺");
 paciencia1x16=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA17(){
     test.dequeuemesa17Paciencia();
      test00.enqueue3("mesa 17", "☺");
       paciencia1x17=1000;
       JOptionPane.showMessageDialog(null,this.mensaje7);
  } 
public void CUENTA18(){
     test.dequeuemesa18Paciencia();
test00.enqueue3("mesa 18", "☺");
 paciencia1x18=1000;
JOptionPane.showMessageDialog(null,this.mensaje7);
} 
public void CUENTA19(){
     test.dequeuemesa19Paciencia();
      test00.enqueue3("mesa 19", "☺");
       paciencia1x19=1000;
       JOptionPane.showMessageDialog(null,this.mensaje7);
  } 
public void CUENTA20(){//falta aplicar mas logica
    
    
     int asiento = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero de asiento para la cuenta de la caja, del 1 a 15"));
       
        if(asiento>=1 && asiento<=15   ){
                 //JOptionPane.showMessageDialog(null,this.mensaje7);
                  switch (asiento) {
                    case 1:
                        test.dequeuemesa20Paciencia();
                        test00.enqueue3("BARRA asiento 1","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x20=1000;
                      
                       
                        break;
                    case 2:
                        test.dequeuemesa21Paciencia();
                        test00.enqueue3("BARRA asiento 2","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x21=1000;
                        break;
                        
                      case 3:
                     test.dequeuemesa22Paciencia();
                        test00.enqueue3("BARRA asiento 3","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x22=1000;
                       
                        break;
                      case 4:
                       test.dequeuemesa23Paciencia();
                        test00.enqueue3("BARRA asiento 4","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x23=1000;
                       
                        break;
                        case 5:
                  test.dequeuemesa24Paciencia();
                        test00.enqueue3("BARRA asiento 5","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x24=1000;
                        break;
                    case 6:
                    
                       test.dequeuemesa25Paciencia();
                        test00.enqueue3("BARRA asiento 6","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x25=1000;
                        break;
                        
                      case 7:
                      test.dequeuemesa26Paciencia();
                        test00.enqueue3("BARRA asiento 7","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x26=1000;
                        
                        break;
                      case 8:
                  test.dequeuemesa27Paciencia();
                        test00.enqueue3("BARRA asiento 8","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x27=1000;
                       
                        break;
                        case 9:
                      test.dequeuemesa28Paciencia();
                        test00.enqueue3("BARRA asiento 9","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x28=1000;
                        break;
                    case 10:
                      
                     test.dequeuemesa29Paciencia();
                        test00.enqueue3("BARRA asiento 10","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x29=1000;
                        break;
                        
                      case 11:
                   test.dequeuemesa30Paciencia();
                        test00.enqueue3("BARRA asiento 11","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x30=1000;
                        
                        break;
                      case 12:
                       test.dequeuemesa31Paciencia();
                        test00.enqueue3("BARRA asiento 12","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x31=1000;
                        
                        break;
                        case 13:
                     test.dequeuemesa32Paciencia();
                        test00.enqueue3("BARRA asiento 13","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x32=1000;
                        break;
                    case 14:
              
                        test.dequeuemesa33Paciencia();
                        test00.enqueue3("BARRA asiento 14","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x33=1000;
                        break;
                        case 15:
                         test.dequeuemesa34Paciencia();
                        test00.enqueue3("BARRA asiento 15","☺" );
                        JOptionPane.showMessageDialog(null,this.mensaje7);
                        paciencia1x34=1000;
                        break;
                        
                 
               
                         default:
                        System.out.println("error");
                        break;
                }
               
               //test.dequeue(); 
             }else{
            JOptionPane.showMessageDialog(null,this.mensaje3);
            }
       // }else{
           // JOptionPane.showMessageDialog(null,this.mensaje3);
        //}
    
//      test.dequeuemesa20Paciencia();
  //    test00.enqueue3("BARRA","☺" );
    //  JOptionPane.showMessageDialog(null,this.mensaje7);

  } 
 

//caja   
public void pagar(){
     
      test00.imprimircola3("", "");
      test00.dequeue3();
      JOptionPane.showMessageDialog(null,"Grupos despachados");
  } 

public void  colaDeCaja(){//no se usa
      test.imprimircola2("",10);
      test.dequeue2();
      JOptionPane.showMessageDialog(null,"Grupos despachados");
     
      
  }
//----------------------------------------------------------------------------------
  
public void limpiarMesa1(){
    int mesa = 1;
    //int numero =6;
      //while (numero>0) {          
    int asiento=0;      
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
    if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
        if(cola[mesa-1][asiento-1]==1){
           cola[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado ");
//           numero--;
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
     }while(asiento !=0); 
    //}
  }
public void limpiarMesa2(){
 int mesa = 2;
 int asiento=0;
 do{
  asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
 if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
     if(cola[mesa-1][asiento-1]==1){
        cola[mesa-1][asiento-1]=0;
        JOptionPane.showMessageDialog(null,"Campo desocupado");

      }else{
     JOptionPane.showMessageDialog(null,this.mensaje8);
     }
 }else{
     JOptionPane.showMessageDialog(null,this.mensaje3);
 }
  }while(asiento !=0); 
 }
public void limpiarMesa3(){
int mesa = 3;
int asiento=0;
do{
asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
 if(cola[mesa-1][asiento-1]==1){
    cola[mesa-1][asiento-1]=0;
    JOptionPane.showMessageDialog(null,"Campo desocupado");

  }else{
 JOptionPane.showMessageDialog(null,this.mensaje8);
 }
}else{
 JOptionPane.showMessageDialog(null,this.mensaje3);
}
}while(asiento !=0); 
}
public void limpiarMesa4(){
    int mesa = 4;
    int asiento=0;
    do{

 asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
if(cola[mesa-1][asiento-1]==1){
cola[mesa-1][asiento-1]=0;
JOptionPane.showMessageDialog(null,"Campo desocupado");

}else{
JOptionPane.showMessageDialog(null,this.mensaje8);
}
}else{
JOptionPane.showMessageDialog(null,this.mensaje3);
}
}while(asiento !=0); 
}
public void limpiarMesa5(){
int mesa = 5;
int asiento =0;
do{
 asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
if(cola[mesa-1][asiento-1]==1){
cola[mesa-1][asiento-1]=0;
JOptionPane.showMessageDialog(null,"Campo desocupado");

}else{
JOptionPane.showMessageDialog(null,this.mensaje8);
}
}else{
JOptionPane.showMessageDialog(null,this.mensaje3);
}
}while(asiento !=0);
}
public void limpiarMesa6(){
int mesa = 6;
int asiento=0;
do{
 asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
if(cola[mesa-1][asiento-1]==1){
cola[mesa-1][asiento-1]=0;
JOptionPane.showMessageDialog(null,"Campo desocupado");

}else{
JOptionPane.showMessageDialog(null,this.mensaje8);
}
}else{
JOptionPane.showMessageDialog(null,this.mensaje3);
}
}while(asiento !=0);
}
public void limpiarMesa7(){
int mesa = 7;
int asiento =0;
do{
 asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
if(cola[mesa-1][asiento-1]==1){
cola[mesa-1][asiento-1]=0;
JOptionPane.showMessageDialog(null,"Campo desocupado");

}else{
JOptionPane.showMessageDialog(null,this.mensaje8);
}
}else{
JOptionPane.showMessageDialog(null,this.mensaje3);
}
}while(asiento !=0);
}
public void limpiarMesa8(){
    int mesa = 8;
    int asiento=0;
            do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
    if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
        if(cola[mesa-1][asiento-1]==1){
           cola[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }}while(asiento !=0);
    }
public void limpiarMesa9(){
    
    int mesa = 9;
    int asiento=0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
    if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
        if(cola[mesa-1][asiento-1]==1){
           cola[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
   }while(asiento !=0);
    }
public void limpiarMesa10(){
    int mesa = 10;
    int asiento=0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 6"));
    if( mesa>=1 && mesa<=10 && asiento>=1 && asiento<=6 ){
        if(cola[mesa-1][asiento-1]==1){
           cola[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
           
public void limpiarMesa11(){
    int mesa = 1;
    int asiento=0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 4"));
    if( mesa>=1 && mesa<=5 && asiento>=1 && asiento<=4 ){
        if(cola2[mesa-1][asiento-1]==1){
           cola2[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
public void limpiarMesa12(){
    int mesa = 2;
    int asiento =0;
    do{
    asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 4"));
    if( mesa>=1 && mesa<=5 && asiento>=1 && asiento<=4 ){
        if(cola2[mesa-1][asiento-1]==1){
           cola2[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
public void limpiarMesa13(){
    int mesa = 3;
    int asiento =0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 4"));
    if( mesa>=1 && mesa<=5 && asiento>=1 && asiento<=4 ){
        if(cola2[mesa-1][asiento-1]==1){
           cola2[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
public void limpiarMesa14(){
    int mesa = 4;
    int asiento =0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 4"));
    if( mesa>=1 && mesa<=5 && asiento>=1 && asiento<=4 ){
        if(cola2[mesa-1][asiento-1]==1){
           cola2[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
public void limpiarMesa15(){
    
    int mesa = 5;
    int asiento=0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 4"));
    if( mesa>=1 && mesa<=5 && asiento>=1 && asiento<=4 ){
        if(cola2[mesa-1][asiento-1]==1){
           cola2[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
public void limpiarMesa16(){
    int mesa = 1;
    int asiento=0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 ó 2"));
    if( mesa>=1 && mesa<=4 && asiento>=1 && asiento<=2 ){
        if(cola3[mesa-1][asiento-1]==1){
           cola3[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
public void limpiarMesa17(){
    int mesa = 2;
    int asiento=0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 ó 2"));
    if( mesa>=1 && mesa<=4 && asiento>=1 && asiento<=2 ){
        if(cola3[mesa-1][asiento-1]==1){
           cola3[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
public void limpiarMesa18(){
    int mesa = 3;
    int asiento =0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 ó 2"));
    if( mesa>=1 && mesa<=4 && asiento>=1 && asiento<=2 ){
        if(cola3[mesa-1][asiento-1]==1){
           cola3[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
public void limpiarMesa19(){
    int mesa = 4;
    int asiento =0;
    do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 ó 2"));
    if( mesa>=1 && mesa<=4 && asiento>=1 && asiento<=2 ){
        if(cola3[mesa-1][asiento-1]==1){
           cola3[mesa-1][asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }
public void limpiarBarra(){
    int asiento =0;
            do{
     asiento = Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero de asiento de 1 a 15"));
    if(  asiento>=1 && asiento<=15 ){
        if(cola4[asiento-1]==1){
           cola4[asiento-1]=0;
           JOptionPane.showMessageDialog(null,"Campo desocupado");
           
         }else{
        JOptionPane.showMessageDialog(null,this.mensaje8);
        }
    }else{
        JOptionPane.showMessageDialog(null,this.mensaje3);
    }
    }while(asiento !=0);
    }

 
public void mesa1Comidas(){
    test2.imprimircolamesa(orden, orden);
    test2.dequeuemesa();
}

public void mesa2Comidas2(){
   test3.imprimircolamesa(orden, orden);
   test3.dequeuemesa();
    
}

public void mesa1Comidas3(){
    test4.imprimircolamesa(MESA3, comida);
    test4.dequeuemesa();
}

public void mesa1Comidas4(){
    test5.imprimircolamesa(MESA4, comida);
    test5.dequeuemesa();
}

public void mesa1Comidas5(){
    test6.imprimircolamesa(MESA5, comida);
    test6.dequeuemesa();
}

public void mesa1Comidas6(){
    test7.imprimircolamesa(MESA6, comida);
    test7.dequeuemesa();
}

public void mesa1Comidas7(){
    test8.imprimircolamesa(MESA7, comida);
    test8.dequeuemesa();
}

public void mesa1Comidas8(){
    test9.imprimircolamesa(MESA8, comida);
    test9.dequeuemesa();
}

public void mesa1Comidas9(){
    test10.imprimircolamesa(MESA9, comida);
    test10.dequeuemesa();
}

public void mesa1Comidas10(){
    test11.imprimircolamesa(MESA10, comida);
   test11.dequeuemesa(); 
}

public void mesa1Comidas11(){
    test12.imprimircolamesa(MESA11, comida);
    test12.dequeuemesa();
}

public void mesa1Comidas12(){
    test13.imprimircolamesa(MESA12, comida);
    test13.dequeuemesa();
}

public void mesa1Comidas13(){
    test14.imprimircolamesa(MESA13, comida);
    test14.dequeuemesa();
}

public void mesa1Comidas14(){
    test15.imprimircolamesa(MESA14, comida);
    test15.dequeuemesa();
}

public void mesa1Comidas15(){
    test16.imprimircolamesa(MESA15, comida);
    test16.dequeuemesa();
}

public void mesa1Comidas16(){
    test17.imprimircolamesa(MESA16, comida);
    test17.dequeuemesa();
}

public void mesa1Comidas17(){
    test18.imprimircolamesa(MESA17, comida);
    test18.dequeuemesa();
}
public void mesa1Comidas18(){
    test19.imprimircolamesa(MESA18, comida);
    test19.dequeuemesa();
}
public void mesa1Comidas19(){
    test20.imprimircolamesa(MESA19, comida);
   test20.dequeuemesa(); 
}

public void barracomidas(){
    test21.imprimircolamesa(barra20, comida);
    test21.dequeuemesa();
}



  
  
}//fin
