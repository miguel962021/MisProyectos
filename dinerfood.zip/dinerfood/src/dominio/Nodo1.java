package dominio;


public class Nodo1 {
    public String autor;
    public Integer titulo;
    public Nodo1 siguiente;
}
