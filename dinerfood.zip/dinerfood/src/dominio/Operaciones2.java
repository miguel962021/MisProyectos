package dominio;

import javax.swing.JOptionPane;


public class Operaciones2 {

    public Nodo2 cima;
    public Nodo2 first;
    public Nodo2 last;
    
    Operaciones2() {
        cima = first = last = null;
    }
    public void push (String autor, String titulo) {
        Nodo2 nuevo = new Nodo2();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (cima == null)
            cima = nuevo;
        else {
            nuevo.siguiente = cima;
            cima = nuevo;
        }
    }
    
      
    //Borrar Inicio Pila
public void pop() {
        if (cima != null)
            cima = cima.siguiente;
    }
    
    
public void imprimirpila() {

     if (cima != null) {
         Nodo2 nuevo = new Nodo2();
         Nodo2 aux;
         aux = cima;

         while(aux != null) {
             JOptionPane.showMessageDialog(null,aux.autor + "  \t  " + aux.titulo);
             System.out.println(aux.autor + "  \t " + aux.titulo);

             aux = aux.siguiente;
         }

     }
     else
         System.out.println("Lista vacia");

 }
public boolean isEmpty(){
        if (cima == null)
            
             return true;
        else
            System.out.println(cima.autor);
        return false;
    }    
    
    
    
    
    
    
    
     public void enqueuemesa (String autor, String titulo) {
        Nodo2 nuevo = new Nodo2();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    //Borrar Inicio Cola
    public void dequeuemesa() {
        if (first != null)
            first = first.siguiente;
    }
     public void imprimircolamesa(String autor,String titulo) {     
            Nodo2 nuevo = new Nodo2();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                first = first.siguiente;
            }
        }
        else
            JOptionPane.showMessageDialog(null,"No hay Comida ");
            System.out.println("Lista vacia");
    }
    
}