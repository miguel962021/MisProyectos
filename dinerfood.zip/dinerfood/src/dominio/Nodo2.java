package dominio;


public class Nodo2 {
    public String autor;
    public String titulo;
    public Nodo2 siguiente;
}
