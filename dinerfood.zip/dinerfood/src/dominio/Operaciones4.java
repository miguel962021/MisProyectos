package dominio;

import javax.swing.JOptionPane;


public class Operaciones4 {

    public Nodo2 cima;
    public Nodo2 first;
    public Nodo2 last;
    
    Operaciones4() {
        cima = first = last = null;
    }
      
     public void enqueuemesa (String autor, String titulo) {
        Nodo2 nuevo = new Nodo2();
        nuevo.autor = autor;
        nuevo.titulo = titulo;
        nuevo.siguiente = null;
        if (first == null)
            first = last = nuevo;
        else {
            last.siguiente = nuevo;
            last = nuevo;
        }
    }
    //Borrar Inicio Cola
    public void dequeuemesa() {
        if (first != null)
            first = first.siguiente;
    }
     public void imprimircolamesa(String autor,String titulo) {     
            Nodo2 nuevo = new Nodo2();
            nuevo.autor=autor;
            nuevo.titulo=titulo;
            nuevo.siguiente=null;
            if (first != null) {
            while(first != null) {
                JOptionPane.showMessageDialog(null,first.autor + "   \t  " + first.titulo);
                System.out.println(first.autor + "  \t  " + first.titulo);
                first = first.siguiente;
            }
        }
        else
            JOptionPane.showMessageDialog(null,"No hay Comida ");
            System.out.println("Lista vacia");
    }
    
     
     
     
     
     
     
}
