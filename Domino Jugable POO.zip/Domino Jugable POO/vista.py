import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter.constants import FALSE

import pygame
import controlador
from  pygame import*
mixer.init()
mixer.music.load('movimiento1.ogg')

init()
pygame.mixer.init()
sonido_fondo = pygame.mixer.Sound("erroraudio1.ogg")
sonido_ganador1 = pygame.mixer.Sound("gana1.ogg")
sonido_ganado2 = pygame.mixer.Sound("gana2.ogg")
sonido_ganador3 = pygame.mixer.Sound("gana3.ogg")
sonido_ganador4 = pygame.mixer.Sound("gana4_1.ogg")


ventana = tk.Tk()
ventana.title ("Domino")
ttk.Label(ventana, text="").grid(row=0, column=1)
ttk.Label(ventana, text="").grid(row=15, column=0)
#ttk.Label(ventana, text="").grid(row=14, column=1)
#ttk.Label(ventana, text="").grid(row=14, column=1)
#ttk.Label(ventana, text="").grid(row=14, column=1)
#ttk.Label(ventana, text="").grid(row=14, column=1)
#ttk.Label(ventana, text="").grid(row=14, column=2)
#ttk.Label(ventana, text="").grid(row=14, column=3)
ttk.Label(ventana, text="").grid(row=14, column=4)
ttk.Label(ventana, text="").grid(row=14, column=5)
ttk.Label(ventana, text="Jugador 1").grid(row=11, column=0)
ttk.Label(ventana, text="Jugador 2").grid(row=11, column=1)
ttk.Label(ventana, text="Jugador 3").grid(row=11, column=2)
ttk.Label(ventana, text="Jugador 4").grid(row=11, column=3)

app = controlador.Juego()

etiqueta = ttk.Label(ventana, text="Resultado")
etiqueta.grid(row=11, column=4)

etiqueta1 = ttk.Label(ventana, text="Jugador1: ")
etiqueta1.grid(row=12, column=0)

etiqueta2 = ttk.Label(ventana, text="Jugador2: ")
etiqueta2.grid(row=12, column=1)

etiqueta3 = ttk.Label(ventana, text="Jugador3: ")
etiqueta3.grid(row=12, column=2)

etiqueta4 = ttk.Label(ventana, text="Jugador4: ")
etiqueta4.grid(row=12, column=3)



def reiniciar():
    reinicio =app.reiniciarContadores()
    messagebox.showinfo("Jugar de nuevo", "Cree ficha nuevamente")


def ganador1():#contador
    ganador1=app.ganadores1()
    if ganador1 == False:
         pygame.mixer.Sound.play(sonido_fondo)
         messagebox.showinfo("Error", "jugador 1 tiene fichas")
    else:
        pygame.mixer.Sound.play(sonido_ganador1)
        messagebox.showinfo("felicitaciones", "Jugador 1 gano la ronda")
        etiqueta1.configure(text=ganador1)

def ganador2():#contador
    ganador2=app.ganadores2()
    if ganador2 == False:
         pygame.mixer.Sound.play(sonido_fondo)
         messagebox.showinfo("Error", "jugador 2 tiene fichas")
    else:
        pygame.mixer.Sound.play(sonido_ganado2)
        messagebox.showinfo("felicitaciones", "Jugador 2  gano la ronda")
        etiqueta2.configure(text=ganador2)##falta

def ganador3():#contador
    ganador3=app.ganadores3()
    if ganador3 == False:
         pygame.mixer.Sound.play(sonido_fondo)
         messagebox.showinfo("Error", "jugador 3 tiene fichas")
    else:
        pygame.mixer.Sound.play(sonido_ganador3)
        messagebox.showinfo("felicitaciones", "Jugador 3  gano la ronda")
        etiqueta3.configure(text=ganador3)##falta

def ganador4():#contador
    ganador4=app.ganadores4()
    if ganador4 == False:
         pygame.mixer.Sound.play(sonido_fondo)
         messagebox.showinfo("Error", "jugador 4 tiene fichas ")
    else:
        pygame.mixer.Sound.play(sonido_ganador4)
        messagebox.showinfo("felicitaciones", "Jugador 4 gano la ronda")
        etiqueta4.configure(text=ganador4)##falta
       
def ganadorPTS(): #ganador:
     sumaPTs=app.puntossum()
     messagebox.showinfo("fichas ", sumaPTs)
     if sumaPTs == FALSE:
         messagebox.showinfo("Jugador 1 ", "No gano")
     else:
         etiqueta1.configure(text=sumaPTs)##falta


def ganadorPTS2(): #ganador
    sumaPTs2=app.puntossum2()
    messagebox.showinfo("fichas ", sumaPTs2)
    if sumaPTs2 == FALSE:
        messagebox.showinfo("Jugador 2 ", "No gano")
    else:
         etiqueta2.configure(text=sumaPTs2)##falta


def ganadorPTS3(): #ganador
    sumaPTs3=app.puntossum3()
    messagebox.showinfo("fichas ", sumaPTs3)
    if sumaPTs3 == False:
       messagebox.showinfo("Jugador 3 ", "No gano")
    else:
        etiqueta3.configure(text=sumaPTs3)##falta

def ganadorPTS4(): #rganador
    sumaPTs4=app.puntossum4()
    messagebox.showinfo("fichas ", sumaPTs4)
    if sumaPTs4 == False:
        messagebox.showinfo("Jugador 4 ", "No gano")
    else:
        etiqueta4.configure(text=sumaPTs4)##falta
#-----------------------------------------------------------------------------

def ganadorPTS5(): #ganador:
     sumaPTs5=app.puntossum5()
     messagebox.showinfo("fichas ", sumaPTs5)
     if sumaPTs5 == FALSE:
         messagebox.showinfo("Jugador 1 ", "No gano")
     else:
         etiqueta1.configure(text=sumaPTs5)##falta


def ganadorPTS6(): #ganador
    sumaPTs6=app.puntossum6()
    messagebox.showinfo("fichas ", sumaPTs6)
    if sumaPTs6 == FALSE:
        messagebox.showinfo("Jugador 2 ", "No gano")
    else:
         etiqueta2.configure(text=sumaPTs6)##falta


def ganadorPTS7(): #ganador
    sumaPTs7=app.puntossum7()
    messagebox.showinfo("fichas ", sumaPTs7)
    if sumaPTs7 == False:
       messagebox.showinfo("Jugador 3 ", "No gano")
    else:
        etiqueta3.configure(text=sumaPTs7)##falta
def ganadorPTS8(): #ganador:
     sumaPTs8=app.puntossum8()
     messagebox.showinfo("fichas ", sumaPTs8)
     if sumaPTs8 == FALSE:
         messagebox.showinfo("Jugador 1 ", "No gano")
     else:
         etiqueta1.configure(text=sumaPTs8)##falta


def ganadorPTS9(): #ganador
    sumaPTs9=app.puntossum9()
    messagebox.showinfo("fichas ", sumaPTs9)
    if sumaPTs9 == FALSE:
        messagebox.showinfo("Jugador 2 ", "No gano")
    else:
         etiqueta2.configure(text=sumaPTs9)##falta






def ingresar_click(): #crear lista de fichas
    crearFichas=app.crear_fichas()
    #app.crear_fichas()
    if crearFichas==False:
        messagebox.showerror("Error","No puede crear mas veces")
    else:
        messagebox.showinfo("Fichas ", "Fichas creadas")

    

    

def revolverFichas(): #revolver las fichas:
    fichasRevueltas = app.revolverFichas()
    messagebox.showinfo("fichas ", fichasRevueltas)
   # mixer.music.play()
    

def verFichas(): #ver las fichas:
    listaFichas = app.verFichas()
    messagebox.showinfo("fichas ", listaFichas)

def mostarMesa(mesaFichas): #Muestra la mesa o tablero
    etiqueta.configure(text=mesaFichas)

  #jugador 1  
def jugar1(): 
    testjugador1 = app.tomaFichas1()
    print(testjugador1)

def voltearDerecha1():
    fichaSelecc = (inputFicha1.get())
    voltearDer1 = app.voltearDerecha1(fichaSelecc)
    if voltearDer1 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showerror("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(voltearDer1)
def voltearIzquierda1():
    fichaSelecc = (inputFicha1.get())
    voltearIzq1= app.voltearIzquierda1(fichaSelecc)
    if voltearIzq1 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(voltearIzq1)
    
def izquierda1():
    fichaSelecc = (inputFicha1.get())
    colocarIzquierda1 = app.jugador1Izquierda(fichaSelecc)
    if colocarIzquierda1 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showerror("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(colocarIzquierda1)

def derecha1(): 
    fichaSelecc = (inputFicha1.get())
    colocarDerecha1 = app.jugador1Derecha(fichaSelecc)
    if colocarDerecha1 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(colocarDerecha1)

def Primera1():
    fichaSelecc = (inputFicha1.get())
    colocarPrimera1= app.primeraFicha1(fichaSelecc)
    if colocarPrimera1 == "Error":
         pygame.mixer.Sound.play(sonido_fondo)
         messagebox.showinfo("Error", "la mesa no esta vacia")
    else:
        mixer.music.play()
        mostarMesa(colocarPrimera1)
    
  
#jugador 2
def jugar2(): 
    testjugador2 = app.tomaFichas2()
    print(testjugador2)

def voltearDerecha2():
    fichaSelecc = (inputFicha2.get())
    voltearDer2 = app.voltearDerecha2(fichaSelecc)
    if voltearDer2 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(voltearDer2)
def voltearIzquierda2():
    fichaSelecc = (inputFicha2.get())
    voltearIzq2= app.voltearIzquierda2(fichaSelecc)
    if voltearIzq2 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(voltearIzq2)
    
def izquierda2():
    fichaSelecc = (inputFicha2.get())
    colocarIzquierda2 = app.jugador2Izquierda(fichaSelecc)
    if colocarIzquierda2 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(colocarIzquierda2)

def derecha2(): 
    fichaSelecc = (inputFicha2.get())
    colocarDerecha2 = app.jugador2Derecha(fichaSelecc)
    if colocarDerecha2 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(colocarDerecha2)

def Primera2():
    fichaSelecc = (inputFicha2.get())
    colocarPrimera2= app.primeraFicha2(fichaSelecc)
    if colocarPrimera2 == "Error":
         pygame.mixer.Sound.play(sonido_fondo)
         messagebox.showinfo("Error", "la mesa no esta vacia")
    else:
        mixer.music.play()
        mostarMesa(colocarPrimera2)



#jugador 3
def jugar3(): 
    testjugador3 = app.tomaFichas3()
    print(testjugador3)

def voltearDerecha3():
    fichaSelecc = (inputFicha3.get())
    voltearDer3 = app.voltearDerecha3(fichaSelecc)
    if voltearDer3 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(voltearDer3)
def voltearIzquierda3():
    fichaSelecc = (inputFicha3.get())
    voltearIzq3= app.voltearIzquierda3(fichaSelecc)
    if voltearIzq3 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play() 
        mostarMesa(voltearIzq3)
    
def izquierda3():
    fichaSelecc = (inputFicha3.get())
    colocarIzquierda3 = app.jugador3Izquierda(fichaSelecc)
    if colocarIzquierda3 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(colocarIzquierda3)

def derecha3(): 
    fichaSelecc = (inputFicha3.get())
    colocarDerecha3 = app.jugador3Derecha(fichaSelecc)
    if colocarDerecha3 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(colocarDerecha3)

def Primera3():
    fichaSelecc = (inputFicha3.get())
    colocarPrimera3= app.primeraFicha3(fichaSelecc)
    if colocarPrimera3 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "la mesa no esta vacia")
    else:
        mixer.music.play()
        mostarMesa(colocarPrimera3)
    

 

#jugador 4
def jugar4(): 
    testjugador4 = app.tomaFichas4()
    print(testjugador4)

def voltearDerecha4():
    fichaSelecc = (inputFicha4.get())
    voltearDer4 = app.voltearDerecha4(fichaSelecc)
    if voltearDer4 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(voltearDer4)
def voltearIzquierda4():
    fichaSelecc = (inputFicha4.get())
    voltearIzq4= app.voltearIzquierda4(fichaSelecc)
    if voltearIzq4 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(voltearIzq4)
    
def izquierda4():
    fichaSelecc = (inputFicha4.get())
    colocarIzquierda4 = app.jugador4Izquierda(fichaSelecc)
    if colocarIzquierda4 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(colocarIzquierda4)

def derecha4(): 
    fichaSelecc = (inputFicha4.get())
    colocarDerecha4 = app.jugador4Derecha(fichaSelecc)
    if colocarDerecha4 == "Error":
        pygame.mixer.Sound.play(sonido_fondo)
        messagebox.showinfo("Error", "Movimiento no valido")
    else:
        mixer.music.play()
        mostarMesa(colocarDerecha4)

def Primera4():
    fichaSelecc = (inputFicha4.get())
    colocarPrimera4= app.primeraFicha4(fichaSelecc)
    if colocarPrimera4 == "Error":
         pygame.mixer.Sound.play(sonido_fondo)
         messagebox.showinfo("Error", "la mesa no esta vacia")
    else:
        mixer.music.play()
        mostarMesa(colocarPrimera4)




def verFichasJug1():# ver fichas del jugador 1
    ver1 = app.verFichasJugado1()
    messagebox.showinfo("fichas ", ver1)

def verFichasJug2():#ver fichas del jugador 2
    ver2 = app.verFichasJugado2()
    messagebox.showinfo("fichas ", ver2)

def verFichasJug3():#ver fichas del jugador 3
    ver3 = app.verFichasJugado3()
    messagebox.showinfo("fichas ", ver3)

def verFichasJug4():#ver fichas del jugador 4
    ver4 = app.verFichasJugado4()
    messagebox.showinfo("fichas ", ver4)


ttk.Label(ventana, text="").grid(row=13, column=0)
#crear fichas boton
ingresar = ttk.Button(ventana, text="Crear fichas", command=ingresar_click)
ingresar.grid(row=14, column = 0)



#pasar fichas a una lista boton
terminar = ttk.Button(ventana, text="Revolver fichas", command=revolverFichas)
terminar.grid(row=14, column = 1)

#ver las fichas  boton
terminar2 = ttk.Button(ventana, text="ver fichas", command=verFichas)
terminar2.grid(row=14, column = 2)



jugadores4 = ttk.Button(ventana, text="ver", command=verFichasJug1)
jugadores4.grid(row=0, column = 0)

jugadores3 = ttk.Button(ventana, text="ver", command=verFichasJug3)
jugadores3.grid(row=0, column = 2)

jugadores2 = ttk.Button(ventana, text="ver", command=verFichasJug2)
jugadores2.grid(row=0, column = 1)

jugadores4 = ttk.Button(ventana, text="ver", command=verFichasJug4)
jugadores4.grid(row=0, column = 3)


jugarD1 = ttk.Button(ventana, text="Tomar fichas", command=jugar1)
jugarD1.grid(row=2, column = 0)

jugarD2 = ttk.Button(ventana, text="Tomar fichas", command=jugar2)
jugarD2.grid(row=2, column = 1)

jugarD3 = ttk.Button(ventana, text="Tomar fichas", command=jugar3)
jugarD3.grid(row=2, column = 2)

jugarD4 = ttk.Button(ventana, text="Tomar fichas", command=jugar4)
jugarD4.grid(row=2, column = 3)

jugarD1_izquierda = ttk.Button(ventana, text="jugardor1 izq", command=izquierda1)
jugarD1_izquierda.grid(row=3, column = 0)
jugarD1_derecha = ttk.Button(ventana, text="jugardor1 der", command=derecha1)
jugarD1_derecha.grid(row=4, column = 0)

jugarD2_izquierda = ttk.Button(ventana, text="jugardor2 izq", command=izquierda2)
jugarD2_izquierda.grid(row=3, column = 1)
jugarD2_derecha = ttk.Button(ventana, text="jugardor2 der", command=derecha2)
jugarD2_derecha.grid(row=4, column = 1)

jugarD3_izquierda = ttk.Button(ventana, text="jugardor3 izq", command=izquierda3)
jugarD3_izquierda.grid(row=3, column = 2)
jugarD3_derecha = ttk.Button(ventana, text="jugardor3 der", command=derecha3)
jugarD3_derecha.grid(row=4, column = 2)

jugarD4_izquierda = ttk.Button(ventana, text="jugardor4 izq", command=izquierda4)
jugarD4_izquierda.grid(row=3, column = 3)
jugarD4_derecha = ttk.Button(ventana, text="jugardor4 der", command=derecha4)
jugarD4_derecha.grid(row=4, column = 3)


#mesa = ttk.Button(ventana, text="mesa", command=mostarMesa)
#mesa.grid(row=5, column = 0)


jugarD1_voltear = ttk.Button(ventana, text="Voltear a la derecha", command=voltearDerecha1)
jugarD1_voltear.grid(row=5, column = 0)

jugarD1_voltear = ttk.Button(ventana, text="Voltear a la izquierda", command=voltearIzquierda1)
jugarD1_voltear.grid(row=6, column = 0)

jugarD2_voltear = ttk.Button(ventana, text="Voltear a la derecha", command=voltearDerecha2)
jugarD2_voltear.grid(row=5, column = 1)

jugarD2_voltear = ttk.Button(ventana, text="Voltear a la izquierda", command=voltearIzquierda2)
jugarD2_voltear.grid(row=6, column = 1)

jugarD3_voltear = ttk.Button(ventana, text="Voltear a la derecha", command=voltearDerecha3)
jugarD3_voltear.grid(row=5, column = 2)

jugarD3_voltear = ttk.Button(ventana, text="Voltear a la izquierda", command=voltearIzquierda3)
jugarD3_voltear.grid(row=6, column = 2)

jugarD4_voltear = ttk.Button(ventana, text="Voltear a la derecha", command=voltearDerecha4)
jugarD4_voltear.grid(row=5, column = 3)

jugarD4_voltear = ttk.Button(ventana, text="Voltear a la izquierda", command=voltearIzquierda4)
jugarD4_voltear.grid(row=6, column = 3)


inputFicha1 = tk.IntVar()
ttk.Entry(ventana, width=10, textvariable=inputFicha1).grid(row=7, column=0)

inputFicha2 = tk.IntVar()
ttk.Entry(ventana, width=10, textvariable=inputFicha2).grid(row=7, column=1)

inputFicha3 = tk.IntVar()
ttk.Entry(ventana, width=10, textvariable=inputFicha3).grid(row=7, column=2)


inputFicha4 = tk.IntVar()
ttk.Entry(ventana, width=10, textvariable=inputFicha4).grid(row=7, column=3)

jugarD11_Primera = ttk.Button(ventana, text="jugardor1 primera ficha", command=Primera1)
jugarD11_Primera.grid(row=1, column = 0)

jugarD11_Primera = ttk.Button(ventana, text="jugardor2 primera ficha", command=Primera2)
jugarD11_Primera.grid(row=1, column = 1)

jugarD11_Primera = ttk.Button(ventana, text="jugardor3 primera ficha", command=Primera3)
jugarD11_Primera.grid(row=1, column = 2)

jugarD11_Primera = ttk.Button(ventana, text="jugardor4 primera ficha", command=Primera4)
jugarD11_Primera.grid(row=1, column = 3)

ganador = ttk.Button(ventana, text="¡Gane!", command=ganador1)
ganador.grid(row=8, column = 0)

ganador = ttk.Button(ventana, text="¡Gane!", command=ganador2)
ganador.grid(row=8, column = 1)

ganador = ttk.Button(ventana, text="¡Gane!", command=ganador3)
ganador.grid(row=8, column = 2)

ganador = ttk.Button(ventana, text="¡Gane!", command=ganador4)
ganador.grid(row=8, column = 3)


ganador = ttk.Button(ventana, text="Jugar de nuevo", command=reiniciar)
ganador.grid(row=14, column = 3)

ttk.Label(ventana, text="validar puntos para 4 jugadores").grid(row=16, column=0)

ganador = ttk.Button(ventana, text="¿GANO el 1:?", command=ganadorPTS)
ganador.grid(row=17, column = 0)

ganador = ttk.Button(ventana, text="¿GANO el 2:?", command=ganadorPTS2)
ganador.grid(row=18, column = 0)

ganador = ttk.Button(ventana, text="¿GANO el 3:?", command=ganadorPTS3)
ganador.grid(row=19, column = 0)

ganador = ttk.Button(ventana, text="¿GANO el 4:?", command=ganadorPTS4)
ganador.grid(row=21, column = 0)

ttk.Label(ventana, text="").grid(row=22, column=0)
ttk.Label(ventana, text="validar puntos para 3 jugadores").grid(row=23, column=0)

ganador = ttk.Button(ventana, text="¿GANO el 1:?", command=ganadorPTS5)
ganador.grid(row=24, column = 0)

ganador = ttk.Button(ventana, text="¿GANO el 2:?", command=ganadorPTS6)
ganador.grid(row=25, column = 0)

ganador = ttk.Button(ventana, text="¿GANO el 3:?", command=ganadorPTS7)
ganador.grid(row=26, column = 0)

ttk.Label(ventana, text="").grid(row=27, column=0)
ttk.Label(ventana, text="validar puntos para 2 jugadores").grid(row=28, column=0)

ganador = ttk.Button(ventana, text="¿GANO el 1:?", command=ganadorPTS8)
ganador.grid(row=29, column = 0)

ganador = ttk.Button(ventana, text="¿GANO el 2:?", command=ganadorPTS9)
ganador.grid(row=30, column = 0)



ventana.geometry("900x400")
#ventana.resizable(False, False)
#ventana.state('zoomed')

ventana.mainloop()
