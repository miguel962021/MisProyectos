from tkinter.constants import FALSE
import pygame
import random
class Juego: 

    pygame.init()
    pygame.mixer.init()
    

    def __init__(self):
        self.conjuntoRevuelto = set()
        self.listaFichasCreadas = []
        self.listaFichasRevueltas=[]
        self.jugador1 = []
        self.jugador2 = []
        self.jugador3 = []
        self.jugador4 = []
        self.mesaFichas=[]
        self.cont = 0
        self.suma1=0
        self.suma2=0
        self.suma3=0
        self.suma4=0
        self.cont22 = 0
        self.contGanador1=0
        self.contGanador2=0
        self.contGanador3=0
        self.contGanador4=0
        self.sonido_fondo = pygame.mixer.Sound("erroraudio1.ogg")
        self.sonido_ganador1 = pygame.mixer.Sound("gana1.ogg")
        self.sonido_ganador2 = pygame.mixer.Sound("gana2.ogg")
        self.sonido_ganador3 = pygame.mixer.Sound("gana3.ogg")
        self.sonido_ganador4 = pygame.mixer.Sound("gana4_1.ogg")

    
    def reiniciarContadores(self):
        self.jugador1.clear()
        self.jugador2.clear()
        self.jugador3.clear()
        self.jugador4.clear()
        self.cont22=0
        self.cont=0
        self.mesaFichas.clear()
        self.listaFichasRevueltas.clear()
        self.listaFichasCreadas.clear()
       
       
    def ganadores1(self):
        if len(self.jugador1)==0:
            self.contGanador1+=1
            print (self.contGanador1)
            return self.contGanador1
        else:
            print (len(self.jugador1))
            return False
    def ganadores2(self):
        if len(self.jugador2)==0:
            self.contGanador2+=1
            print (self.contGanador2)
            return self.contGanador2
        else:
            print (len(self.jugador2))
            return False
    
    def ganadores3(self):
        if len(self.jugador3)==0:
            self.contGanador3+=1
            print (self.contGanador3)
            return self.contGanador3
        else:
            print (len(self.jugador4))
            return False
    
    def ganadores4(self):
        if len(self.jugador4)==0:
            self.contGanador4+=1
            print (self.contGanador4)
            return self.contGanador4
        else:
            print (len(self.jugador4))
            return False


    def crear_fichas(self):
        if self.cont22 == 0:
            for i in range(0,7):
                for j in range(0,i+1):
                    fichas=((i),(j))
                    print(fichas)
                    self.listaFichasCreadas.append(fichas)
                    self.cont22 +=1
            return self.listaFichasCreadas
        else:
            return False

    def revolverFichas(self):
        if self.cont == 0:
            for i in self.listaFichasCreadas:
                self.listaFichasRevueltas.append(i)

            random.shuffle(self.listaFichasRevueltas)
            print(self.listaFichasRevueltas)
            print(type(self.listaFichasRevueltas[1])) 
            self.cont +=1
            return "Fichas revueltas"
        else:
            return "No puede revolver mas veces"

    def verFichas(self):
        return self.listaFichasRevueltas
    
    def verMesa(self):
        return len(self.mesaFichas)
    
    def verganadores(self):
        return (self.contGanador1)



#4 jugadores validacion de puntos
    def puntossum(self):
        self.suma1=0
        self.suma2=0
        self.suma3=0
        self.suma4=0
        for i in self.jugador1:
            ficha= i    
            self.suma1+= (sum(ficha)) 
            f1=self.suma1       
        print(f1)
        
        for i in self.jugador2:
            ficha2= i    
            self.suma2+= (sum(ficha2))
            f2=self.suma2          
        print(f2)
        
        for i in self.jugador3:
            ficha3= i    
            self.suma3+= (sum(ficha3)) 
            f3=self.suma3         
        print(f3)
        
        for i in self.jugador4:
            ficha4= i    
            self.suma4+= (sum(ficha4))  
            f4=self.suma4        
        print(f4)
        
        if f1<=f2 and f1<=f3 and f1<=f4:
            print("gano el jugador 1")
            self.contGanador1+=1
            pygame.mixer.Sound.play(self.sonido_ganador1)
            return self.contGanador1
        else:
            return False

    def puntossum2(self):
        self.suma1=0
        self.suma2=0
        self.suma3=0
        self.suma4=0
        for i in self.jugador1:
            ficha= i    
            self.suma1+= (sum(ficha)) 
            f1=self.suma1       
        print(f1)
        
        for i in self.jugador2:
            ficha2= i    
            self.suma2+= (sum(ficha2))
            f2=self.suma2          
        print(f2)
        
        for i in self.jugador3:
            ficha3= i    
            self.suma3+= (sum(ficha3)) 
            f3=self.suma3         
        print(f3)
        
        for i in self.jugador4:
            ficha4= i    
            self.suma4+= (sum(ficha4))  
            f4=self.suma4        
        print(f4) 
        
        if f2<=f1 and f2<=f3 and f2<=f4:
            print("gano el jugador 2")
            self.contGanador2+=1
            pygame.mixer.Sound.play(self.sonido_ganador2)
            return self.contGanador2  
        else: 
            return FALSE

    def puntossum3(self):
        self.suma1=0
        self.suma2=0
        self.suma3=0
        self.suma4=0
        for i in self.jugador1:
            ficha= i    
            self.suma1+= (sum(ficha)) 
            f1=self.suma1       
        print(f1)
        
        for i in self.jugador2:
            ficha2= i    
            self.suma2+= (sum(ficha2))
            f2=self.suma2          
        print(f2)
        
        for i in self.jugador3:
            ficha3= i    
            self.suma3+= (sum(ficha3)) 
            f3=self.suma3         
        print(f3)
        
        for i in self.jugador4:
            ficha4= i    
            self.suma4+= (sum(ficha4))  
            f4=self.suma4        
        print(f4) 
        if f3<=f1 and f3<=f2 and f3<=f4:
            print("gano el jugador 3")
            self.contGanador3+=1
            pygame.mixer.Sound.play(self.sonido_ganador3)
            return self.contGanador3
        else: 
            return False
    
    def puntossum4(self):
        self.suma1=0
        self.suma2=0
        self.suma3=0
        self.suma4=0
        for i in self.jugador1:
            ficha= i    
            self.suma1+= (sum(ficha)) 
            f1=self.suma1       
        print(f1)
        
        for i in self.jugador2:
            ficha2= i    
            self.suma2+= (sum(ficha2))
            f2=self.suma2          
        print(f2)
        
        for i in self.jugador3:
            ficha3= i    
            self.suma3+= (sum(ficha3)) 
            f3=self.suma3         
        print(f3)
        
        for i in self.jugador4:
            ficha4= i    
            self.suma4+= (sum(ficha4))  
            f4=self.suma4        
        print(f4) 
        
        if f4<=f1 and f4<=f2 and f4<=f3:
            print("gano el jugador 4")
            self.contGanador4+=1
            pygame.mixer.Sound.play(self.sonido_ganador4)
            return self.contGanador4
        else: 
            return False
        
        #-------------------------------------------------------------------------

        #3 jugadores validacion de puntos
    def puntossum5(self):
        self.suma1=0
        self.suma2=0
        self.suma3=0
        for i in self.jugador1:
            ficha= i    
            self.suma1+= (sum(ficha)) 
            f1=self.suma1       
        print(f1)
        
        for i in self.jugador2:
            ficha2= i    
            self.suma2+= (sum(ficha2))
            f2=self.suma2          
        print(f2)
        
        for i in self.jugador3:
            ficha3= i    
            self.suma3+= (sum(ficha3)) 
            f3=self.suma3         
        print(f3)
        
        if f1<=f2 and f1<=f3 :
            print("gano el jugador 1")
            self.contGanador1+=1
            pygame.mixer.Sound.play(self.sonido_ganador1)
            return self.contGanador1
        else:
            return False

    def puntossum6(self):
        self.suma1=0
        self.suma2=0
        self.suma3=0
        for i in self.jugador1:
            ficha= i    
            self.suma1+= (sum(ficha)) 
            f1=self.suma1       
        print(f1)
        
        for i in self.jugador2:
            ficha2= i    
            self.suma2+= (sum(ficha2))
            f2=self.suma2          
        print(f2)
        
        for i in self.jugador3:
            ficha3= i    
            self.suma3+= (sum(ficha3)) 
            f3=self.suma3         
        print(f3)
        
        
        if f2<=f1 and f2<=f3:
            print("gano el jugador 2")
            self.contGanador2+=1
            pygame.mixer.Sound.play(self.sonido_ganador2)
            return self.contGanador2  
        else: 
            return FALSE

    def puntossum7(self):
        self.suma1=0
        self.suma2=0
        self.suma3=0
        for i in self.jugador1:
            ficha= i    
            self.suma1+= (sum(ficha)) 
            f1=self.suma1       
        print(f1)
        
        for i in self.jugador2:
            ficha2= i    
            self.suma2+= (sum(ficha2))
            f2=self.suma2          
        print(f2)
        
        for i in self.jugador3:
            ficha3= i    
            self.suma3+= (sum(ficha3)) 
            f3=self.suma3         
        print(f3)
        
        if f3<=f1 and f3<=f2 :
            print("gano el jugador 3")
            self.contGanador3+=1
            pygame.mixer.Sound.play(self.sonido_ganador3)
            return self.contGanador3
        else: 
            return False   
    
            #--------------------------------------------------------------------------
    #2 jugadores ganador por puntos
    def puntossum8(self):
        self.suma1=0
        self.suma2=0
        for i in self.jugador1:
            ficha= i    
            self.suma1+= (sum(ficha)) 
            f1=self.suma1       
        print(f1)
        
        for i in self.jugador2:
            ficha2= i    
            self.suma2+= (sum(ficha2))
            f2=self.suma2          
        print(f2)
        
        if f1<=f2 :
            print("gano el jugador 1")
            self.contGanador1+=1
            pygame.mixer.Sound.play(self.sonido_ganador1)
            return self.contGanador1
        else:
            return False

    def puntossum9(self):
        self.suma1=0
        self.suma2=0
        for i in self.jugador1:
            ficha= i    
            self.suma1+= (sum(ficha)) 
            f1=self.suma1       
        print(f1)
        
        for i in self.jugador2:
            ficha2= i    
            self.suma2+= (sum(ficha2))
            f2=self.suma2          
        print(f2)
        if f2<=f1 :
            print("gano el jugador 2")
            self.contGanador2+=1
            pygame.mixer.Sound.play(self.sonido_ganador2)
            return self.contGanador2  
        else: 
            return FALSE

   

    #jugador 1 acciones
    def tomaFichas1(self):
        self.jugador1.append(self.listaFichasRevueltas.pop())
        return self.jugador1

    def primeraFicha1(self,fichaSelecc):
        ficha=self.jugador1[fichaSelecc-1]
        aux22=len(self.mesaFichas)
        if aux22==0:
            self.mesaFichas.insert(0,ficha)
            self.jugador1.pop(fichaSelecc-1)  
            
        else:
            return "Error"
        return self.mesaFichas


    def verFichasJugado1(self):
        return self.jugador1
    
    def jugador1Izquierda(self,fichaSelecc):
        ficha=self.jugador1[fichaSelecc-1]
        ficha2=self.mesaFichas[0]
        aux22=len(self.mesaFichas)
        if aux22==0:
            self.mesaFichas.insert(0,ficha)
            self.jugador1.pop(fichaSelecc-1)       
        if ficha[1]==ficha2[0]:
            self.mesaFichas.insert(0,ficha)
            self.jugador1.pop(fichaSelecc-1)
        else:
            return "Error"
        return self.mesaFichas

    def jugador1Derecha(self,fichaSelecc):
        ficha=self.jugador1[fichaSelecc-1] 
        aux=len(self.mesaFichas)
        ficha2=self.mesaFichas[aux-1]
        if ficha[0]==ficha2[1]:
            self.mesaFichas.append(ficha)
            self.jugador1.pop(fichaSelecc-1)
        else:
            return "Error"
        return self.mesaFichas

    def voltearDerecha1(self,fichaSelecc):
        ficha=self.jugador1[fichaSelecc-1]  
        ficha= ficha[::-1]
        aux=len(self.mesaFichas)
        print(self.mesaFichas[aux-1])
        ficha2=self.mesaFichas[aux-1]
        if ficha[0]==ficha2[1]:
            self.mesaFichas.append(ficha)
            self.jugador1.pop(fichaSelecc-1)
        else:
            return"Error"
        return self.mesaFichas

    def voltearIzquierda1(self,fichaSelecc):
        ficha=self.jugador1[fichaSelecc-1]  
        ficha= ficha[::-1]
        ficha2=self.mesaFichas[0]
        print(ficha2[0])
        if ficha[1]==ficha2[0]:
            self.mesaFichas.insert(0,ficha)
            self.jugador1.pop(fichaSelecc-1)
        else:
            return"Error"
        return self.mesaFichas


    #jugador 2 acciones
    def tomaFichas2(self):
        print('Jugador 2')
        self.jugador2.append(self.listaFichasRevueltas.pop())
        return self.jugador2

    def primeraFicha2(self,fichaSelecc):
        ficha=self.jugador2[fichaSelecc-1]
        aux22=len(self.mesaFichas)
        if aux22==0:
            self.mesaFichas.insert(0,ficha)
            self.jugador2.pop(fichaSelecc-1)   
        else:
            return "Error"
            print("error")
        return self.mesaFichas


    def verFichasJugado2(self):
        return self.jugador2
    
    def jugador2Izquierda(self,fichaSelecc):
        ficha=self.jugador2[fichaSelecc-1]
        ficha2=self.mesaFichas[0]
        aux22=len(self.mesaFichas)
        if aux22==0:
            self.mesaFichas.insert(0,ficha)
            self.jugador2.pop(fichaSelecc-1)       
        if ficha[1]==ficha2[0]:
            self.mesaFichas.insert(0,ficha)
            self.jugador2.pop(fichaSelecc-1)
        else:
            return "Error"
        return self.mesaFichas

    def jugador2Derecha(self,fichaSelecc):
        ficha=self.jugador2[fichaSelecc-1] 
        aux=len(self.mesaFichas)
        ficha2=self.mesaFichas[aux-1]
        if ficha[0]==ficha2[1]:
            self.mesaFichas.append(ficha)
            self.jugador2.pop(fichaSelecc-1)
        else:
            return "Error"
        return self.mesaFichas

    def voltearDerecha2(self,fichaSelecc):
        ficha=self.jugador2[fichaSelecc-1]  
        ficha= ficha[::-1]
        aux=len(self.mesaFichas)
        print(self.mesaFichas[aux-1])
        ficha2=self.mesaFichas[aux-1]
        if ficha[0]==ficha2[1]:
            self.mesaFichas.append(ficha)
            self.jugador2.pop(fichaSelecc-1)
        else:
            return"Error"
        return self.mesaFichas

    def voltearIzquierda2(self,fichaSelecc):
        ficha=self.jugador2[fichaSelecc-1]  
        ficha= ficha[::-1]
        ficha2=self.mesaFichas[0]
        print(ficha2[0])
        if ficha[1]==ficha2[0]:
            self.mesaFichas.insert(0,ficha)
            self.jugador2.pop(fichaSelecc-1)
        else:
            return"Error"
        return self.mesaFichas
    

    
    #jugador 3 acciones
    def tomaFichas3(self):
        print('Jugador 3')
        self.jugador3.append(self.listaFichasRevueltas.pop())
        return self.jugador3

    def primeraFicha3(self,fichaSelecc):
        ficha=self.jugador3[fichaSelecc-1]
        aux22=len(self.mesaFichas)
        if aux22==0:
            self.mesaFichas.insert(0,ficha)
            self.jugador3.pop(fichaSelecc-1)   
        else:
            return "Error"
            print("error")
        return self.mesaFichas


    def verFichasJugado3(self):
        return self.jugador3
    
    def jugador3Izquierda(self,fichaSelecc):
        ficha=self.jugador3[fichaSelecc-1]
        ficha2=self.mesaFichas[0]
        aux22=len(self.mesaFichas)
        if aux22==0:
            self.mesaFichas.insert(0,ficha)
            self.jugador3.pop(fichaSelecc-1)       
        if ficha[1]==ficha2[0]:
            self.mesaFichas.insert(0,ficha)
            self.jugador3.pop(fichaSelecc-1)
        else:
            return "Error"
        return self.mesaFichas

    def jugador3Derecha(self,fichaSelecc):
        ficha=self.jugador3[fichaSelecc-1] 
        aux=len(self.mesaFichas)
        ficha2=self.mesaFichas[aux-1]
        if ficha[0]==ficha2[1]:
            self.mesaFichas.append(ficha)
            self.jugador3.pop(fichaSelecc-1)
        else:
            return "Error"
        return self.mesaFichas

    def voltearDerecha3(self,fichaSelecc):
        ficha=self.jugador3[fichaSelecc-1]  
        ficha= ficha[::-1]
        aux=len(self.mesaFichas)
        print(self.mesaFichas[aux-1])
        ficha2=self.mesaFichas[aux-1]
        if ficha[0]==ficha2[1]:
            self.mesaFichas.append(ficha)
            self.jugador3.pop(fichaSelecc-1)
        else:
            return"Error"
        return self.mesaFichas

    def voltearIzquierda3(self,fichaSelecc):
        ficha=self.jugador3[fichaSelecc-1]  
        ficha= ficha[::-1]
        ficha2=self.mesaFichas[0]
        print(ficha2[0])
        if ficha[1]==ficha2[0]:
            self.mesaFichas.insert(0,ficha)
            self.jugador3.pop(fichaSelecc-1)
        else:
            return"Error"
        return self.mesaFichas
    
    
    #jugador 4 acciones
    def tomaFichas4(self):
        print('Jugador 4')
        self.jugador4.append(self.listaFichasRevueltas.pop())
        return self.jugador4

    def primeraFicha4(self,fichaSelecc):
        ficha=self.jugador4[fichaSelecc-1]
        aux22=len(self.mesaFichas)
        if aux22==0:
            self.mesaFichas.insert(0,ficha)
            self.jugador4.pop(fichaSelecc-1)   
        else:
            print("error")
            return"Error"
        return self.mesaFichas


    def verFichasJugado4(self):
        return self.jugador4
    
    def jugador4Izquierda(self,fichaSelecc):
        ficha=self.jugador4[fichaSelecc-1]
        ficha2=self.mesaFichas[0]
        aux22=len(self.mesaFichas)
        if aux22==0:
            self.mesaFichas.insert(0,ficha)
            self.jugador4.pop(fichaSelecc-1)       
        if ficha[1]==ficha2[0]:
            self.mesaFichas.insert(0,ficha)
            self.jugador4.pop(fichaSelecc-1)
        else:
            return "Error"
        return self.mesaFichas

    def jugador4Derecha(self,fichaSelecc):
        ficha=self.jugador4[fichaSelecc-1] 
        aux=len(self.mesaFichas)
        ficha2=self.mesaFichas[aux-1]
        if ficha[0]==ficha2[1]:
            self.mesaFichas.append(ficha)
            self.jugador4.pop(fichaSelecc-1)
        else:
            return "Error"
        return self.mesaFichas

    def voltearDerecha4(self,fichaSelecc):
        ficha=self.jugador4[fichaSelecc-1]  
        ficha= ficha[::-1]
        aux=len(self.mesaFichas)
        print(self.mesaFichas[aux-1])
        ficha2=self.mesaFichas[aux-1]
        if ficha[0]==ficha2[1]:
            self.mesaFichas.append(ficha)
            self.jugador4.pop(fichaSelecc-1)
        else:
            return"Error"
        return self.mesaFichas

    def voltearIzquierda4(self,fichaSelecc):
        ficha=self.jugador4[fichaSelecc-1]  
        ficha= ficha[::-1]
        ficha2=self.mesaFichas[0]
        print(ficha2[0])
        if ficha[1]==ficha2[0]:
            self.mesaFichas.insert(0,ficha)
            self.jugador4.pop(fichaSelecc-1)
        else:
            return"Error"
        return self.mesaFichas

    