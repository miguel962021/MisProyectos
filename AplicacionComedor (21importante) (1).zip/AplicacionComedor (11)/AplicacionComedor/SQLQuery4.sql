﻿

create proc SP_consultacarnetAusentes
As
select  e.id
from estudiante e
where e.asistenciabit=0;


exec SP_consultacarnetAusentes ;