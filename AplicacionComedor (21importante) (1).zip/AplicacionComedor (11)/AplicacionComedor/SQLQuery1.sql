﻿create table loginicio(
id int identity (1,1) not null primary key ,
usuario     varchar(50)not null,
contraseña  varchar(50)not null,
bitpar int ,
);



create proc SP_inicioLogin
@USUARIO as varchar(50),
@CONTRASEÑA  as varchar(50)
as 
select BIT
from LOGIN 
where USUARIO= @USUARIO AND  CONTRASEÑA= @CONTRASEÑA;

exec SP_inicioLogin 'admin', 'admin';





create proc SP_inicioLogin3
@USUARIO as varchar(50),
@CONTRASEÑA  as varchar(50)
as 
select bitpar
from loginicio 
where usuario= @USUARIO AND  contraseña = @CONTRASEÑA;

exec SP_inicioLogin3 'admin', 'admin';



select * from loginicio;


INSERT INTO loginicio(id, usuario, contraseña, bitpar)
VALUES (0,'admin', 'admin',1);