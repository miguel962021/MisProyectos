﻿

create proc SP_consultafechaasitencia77
@FECHA as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre
from asistencia A
join estudiante E on E.id = A.idcarnet
where A.fecha = @FECHA and a.asistenciabit=1;

exec SP_consultafechaasitencia77 '2022-07-18';





create proc SP_consultaFechatotal77
@FECHA as date
As
select count(id) as count
from asistencia A
where A.fecha = @FECHA and a.asistenciabit=1;


exec SP_consultaFechatotal77 '2022-07-15';