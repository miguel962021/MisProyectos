﻿
create proc SP_tardia3
@ID as int
As
update asistencia
set asistenciabit=1
where id =@ID ;

exec SP_tardia3 1;
