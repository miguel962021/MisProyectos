﻿create proc SP_confirmarUsrID2
@ID as INT
as 
select l.id
from loginicio l
where l.id= @ID;