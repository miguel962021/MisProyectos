﻿

create proc SP_todoest
As
select * from estudiante;


exec SP_todoest;
