﻿create proc SP_consultafechaasitenciaRango2
@FECHA1 as date,
@FECHA2 as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre,a.fecha
from asistencia A
join estudiante E on E.id = A.idcarnet
where  a.asistenciabit=1 and A.fecha between @FECHA1 and  @FECHA2;

exec SP_consultafechaasitenciaRango2 '2022-07-01','2022-07-23';



create proc SP_consultaAusenciasRango2
@FECHA1 as date,
@FECHA2 as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre,a.fecha
from asistencia A
join estudiante E on E.id = A.idcarnet
where  a.asistenciabit=0 and A.fecha between @FECHA1 and  @FECHA2;

exec SP_consultaAusenciasRango2 '2022-07-01','2022-07-23';
