﻿create proc SP_aux
@FECHA as date,
@ID as int
As
select  A.id
from asistencia A
where A.fecha = @FECHA and a.idcarnet = @ID and a.asistenciabit=1 ;