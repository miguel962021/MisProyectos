﻿

create table tFecha(
id int not null primary key ,
fecha  date  not null, 
);

INSERT INTO tFecha (id,fecha )
VALUES (1,'2022-08-15');



create proc SP_fechaDia
As
select  A.fecha
from tFecha A
;	

exec SP_fechaDia;
