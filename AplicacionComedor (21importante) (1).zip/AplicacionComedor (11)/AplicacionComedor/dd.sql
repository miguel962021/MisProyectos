﻿create proc SP_ausenciasfechaId
@FECHA as date,
@ID as int
As
select  A.id
from asistencia A
where A.fecha = @FECHA and a.idcarnet = @ID and a.asistenciabit=0 ;

exec SP_ausenciasfechaId '2022-07-17',1;