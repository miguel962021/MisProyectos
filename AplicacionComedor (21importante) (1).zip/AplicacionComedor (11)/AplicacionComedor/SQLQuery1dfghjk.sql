﻿



create proc SP_consultafechaasitenciaRangoId2
@FECHA1 as date,
@FECHA2 as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre,a.fecha
from asistencia A
join estudiante E on E.id = A.idcarnet
where  a.asistenciabit=1 and A.fecha between @FECHA1 and @FECHA2
order by a.idcarnet asc;

exec SP_consultafechaasitenciaRangoId2 '2022-07-01','2022-07-23';





create proc SP_consultaAusenciasRangoID2
@FECHA1 as date,
@FECHA2 as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre,a.fecha
from asistencia A
join estudiante E on E.id = A.idcarnet
where  a.asistenciabit=0 and A.fecha between @FECHA1 and  @FECHA2
order by a.idcarnet asc;

exec SP_consultaAusenciasRangoID2 '2021-07-01','2022-07-23';

