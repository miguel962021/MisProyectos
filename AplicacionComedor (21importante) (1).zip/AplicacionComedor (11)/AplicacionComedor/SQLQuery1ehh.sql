﻿--consulta para saber el total de asistencias en un dia 
create proc SP_Hoy
As
select count(id) as count
from estudiante 
;

exec SP_Hoy ;




create proc SP_consultafechaasitenciaRangoId
@FECHA1 as date,
@FECHA2 as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre,a.fecha
from asistencia A
join estudiante E on E.id = A.idcarnet
where  a.asistenciabit=1 and A.fecha between @FECHA1 and @FECHA2
order by a.id;

exec SP_consultafechaasitenciaRangoId '2022-07-01','2022-07-23';



create proc SP_consultaAusenciasRangoID
@FECHA1 as date,
@FECHA2 as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre,a.fecha
from asistencia A
join estudiante E on E.id = A.idcarnet
where  a.asistenciabit=0 and A.fecha between @FECHA1 and  @FECHA2
order by a.id;

exec SP_consultaAusenciasRangoID '2022-07-01','2022-07-23';






