﻿select * from estudiante;

delete from estudiante
where id = 1;

INSERT INTO estudiante (id, apellido1, apellido2, nombre,asistenciabit)
VALUES (4,'MORA', 'RIOS','MELVIN',0);