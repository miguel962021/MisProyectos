﻿create table loginicio(
id int identity (1,1) not null primary key ,
usuario     varchar(50)not null,
contraseña  varchar(50)not null,
bitpar int ,
);




select * from loginicio;


INSERT INTO loginicio(usuario, contraseña, bitpar)
VALUES ('admin', 'admin',1);


create proc SP_inicioLogin3
@USUARIO as varchar(50),
@CONTRASEÑA  as varchar(50)
as 
select bitpar
from loginicio 
where usuario= @USUARIO AND  contraseña = @CONTRASEÑA;

exec SP_inicioLogin3 'admin', 'admin';


create proc SP_usuariosCon
as 
select *
from loginicio;



create proc SP_consultafechaasitenciaRango
@FECHA1 as date,
@FECHA2 as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre
from asistencia A
join estudiante E on E.id = A.idcarnet
where  a.asistenciabit=1 and A.fecha between @FECHA1 and  @FECHA2;

exec SP_consultafechaasitenciaRango '2022-07-01','2022-07-23';




create proc SP_consultaAusenciasRango
@FECHA1 as date,
@FECHA2 as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre
from asistencia A
join estudiante E on E.id = A.idcarnet
where  a.asistenciabit=0 and A.fecha between @FECHA1 and  @FECHA2;

exec SP_consultaAusenciasRango '2022-07-01','2022-07-23';




