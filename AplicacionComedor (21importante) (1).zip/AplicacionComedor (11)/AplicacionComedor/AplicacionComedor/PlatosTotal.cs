﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class PlatosTotal : Form
    {
        public PlatosTotal()
        {
            InitializeComponent();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();


            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.SP_Hoy().ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) { }

            }
        }
    }
}
