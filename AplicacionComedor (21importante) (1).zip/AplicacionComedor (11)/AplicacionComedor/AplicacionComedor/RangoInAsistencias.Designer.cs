﻿namespace AplicacionComedor
{
    partial class RangoInAsistencias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.principalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PasarAsistenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.asistenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porFechaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porRangoDeFechaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ausenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porFechaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.porRangoDeFechaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.regirtroEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.actulizarEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(522, 333);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker2.TabIndex = 187;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(428, 341);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 186;
            this.label1.Text = "DD/MM/YY";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(262, 334);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(97, 20);
            this.dateTimePicker1.TabIndex = 185;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(174, 340);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 184;
            this.label8.Text = "DD/MM/YY";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.PaleTurquoise;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Location = new System.Drawing.Point(159, 115);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(556, 146);
            this.dataGridView1.TabIndex = 183;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.principalToolStripMenuItem,
            this.PasarAsistenciasToolStripMenuItem,
            this.consultasToolStripMenuItem,
            this.regirtroEstudiantesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 191;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // principalToolStripMenuItem
            // 
            this.principalToolStripMenuItem.Name = "principalToolStripMenuItem";
            this.principalToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.principalToolStripMenuItem.Text = "Principal";
            this.principalToolStripMenuItem.Click += new System.EventHandler(this.principalToolStripMenuItem_Click);
            // 
            // PasarAsistenciasToolStripMenuItem
            // 
            this.PasarAsistenciasToolStripMenuItem.Name = "PasarAsistenciasToolStripMenuItem";
            this.PasarAsistenciasToolStripMenuItem.Size = new System.Drawing.Size(134, 24);
            this.PasarAsistenciasToolStripMenuItem.Text = "Pasar Asistencia";
            this.PasarAsistenciasToolStripMenuItem.Click += new System.EventHandler(this.PasarAsistenciasToolStripMenuItem_Click);
            // 
            // consultasToolStripMenuItem
            // 
            this.consultasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.asistenciasToolStripMenuItem,
            this.ausenciasToolStripMenuItem});
            this.consultasToolStripMenuItem.Name = "consultasToolStripMenuItem";
            this.consultasToolStripMenuItem.Size = new System.Drawing.Size(89, 24);
            this.consultasToolStripMenuItem.Text = "Consultas";
            // 
            // asistenciasToolStripMenuItem
            // 
            this.asistenciasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.porFechaToolStripMenuItem,
            this.porRangoDeFechaToolStripMenuItem});
            this.asistenciasToolStripMenuItem.Name = "asistenciasToolStripMenuItem";
            this.asistenciasToolStripMenuItem.Size = new System.Drawing.Size(167, 24);
            this.asistenciasToolStripMenuItem.Text = "Asistencias";
            // 
            // porFechaToolStripMenuItem
            // 
            this.porFechaToolStripMenuItem.Name = "porFechaToolStripMenuItem";
            this.porFechaToolStripMenuItem.Size = new System.Drawing.Size(285, 24);
            this.porFechaToolStripMenuItem.Text = "Asistencia por fecha";
            this.porFechaToolStripMenuItem.Click += new System.EventHandler(this.porFechaToolStripMenuItem_Click);
            // 
            // porRangoDeFechaToolStripMenuItem
            // 
            this.porRangoDeFechaToolStripMenuItem.Name = "porRangoDeFechaToolStripMenuItem";
            this.porRangoDeFechaToolStripMenuItem.Size = new System.Drawing.Size(285, 24);
            this.porRangoDeFechaToolStripMenuItem.Text = "Asistencia por rango de fecha";
            this.porRangoDeFechaToolStripMenuItem.Click += new System.EventHandler(this.porRangoDeFechaToolStripMenuItem_Click);
            // 
            // ausenciasToolStripMenuItem
            // 
            this.ausenciasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.porFechaToolStripMenuItem1,
            this.porRangoDeFechaToolStripMenuItem1});
            this.ausenciasToolStripMenuItem.Name = "ausenciasToolStripMenuItem";
            this.ausenciasToolStripMenuItem.Size = new System.Drawing.Size(167, 24);
            this.ausenciasToolStripMenuItem.Text = "Inasistencias";
            // 
            // porFechaToolStripMenuItem1
            // 
            this.porFechaToolStripMenuItem1.Name = "porFechaToolStripMenuItem1";
            this.porFechaToolStripMenuItem1.Size = new System.Drawing.Size(210, 24);
            this.porFechaToolStripMenuItem1.Text = "Por fecha";
            this.porFechaToolStripMenuItem1.Click += new System.EventHandler(this.porFechaToolStripMenuItem1_Click);
            // 
            // porRangoDeFechaToolStripMenuItem1
            // 
            this.porRangoDeFechaToolStripMenuItem1.Name = "porRangoDeFechaToolStripMenuItem1";
            this.porRangoDeFechaToolStripMenuItem1.Size = new System.Drawing.Size(210, 24);
            this.porRangoDeFechaToolStripMenuItem1.Text = "Por rango de fecha";
            this.porRangoDeFechaToolStripMenuItem1.Click += new System.EventHandler(this.porRangoDeFechaToolStripMenuItem1_Click);
            // 
            // regirtroEstudiantesToolStripMenuItem
            // 
            this.regirtroEstudiantesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consultarEstudiantesToolStripMenuItem,
            this.agregarEstudiantesToolStripMenuItem,
            this.actulizarEstudiantesToolStripMenuItem,
            this.eliminarEstudiantesToolStripMenuItem});
            this.regirtroEstudiantesToolStripMenuItem.Name = "regirtroEstudiantesToolStripMenuItem";
            this.regirtroEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(186, 24);
            this.regirtroEstudiantesToolStripMenuItem.Text = "Registro de estudiantes";
            // 
            // consultarEstudiantesToolStripMenuItem
            // 
            this.consultarEstudiantesToolStripMenuItem.Name = "consultarEstudiantesToolStripMenuItem";
            this.consultarEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.consultarEstudiantesToolStripMenuItem.Text = "Consultar estudiantes";
            this.consultarEstudiantesToolStripMenuItem.Click += new System.EventHandler(this.consultarEstudiantesToolStripMenuItem_Click);
            // 
            // agregarEstudiantesToolStripMenuItem
            // 
            this.agregarEstudiantesToolStripMenuItem.Name = "agregarEstudiantesToolStripMenuItem";
            this.agregarEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.agregarEstudiantesToolStripMenuItem.Text = "Agregar estudiantes";
            this.agregarEstudiantesToolStripMenuItem.Click += new System.EventHandler(this.agregarEstudiantesToolStripMenuItem_Click);
            // 
            // actulizarEstudiantesToolStripMenuItem
            // 
            this.actulizarEstudiantesToolStripMenuItem.Name = "actulizarEstudiantesToolStripMenuItem";
            this.actulizarEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.actulizarEstudiantesToolStripMenuItem.Text = "Actualizar estudiantes";
            this.actulizarEstudiantesToolStripMenuItem.Click += new System.EventHandler(this.actulizarEstudiantesToolStripMenuItem_Click);
            // 
            // eliminarEstudiantesToolStripMenuItem
            // 
            this.eliminarEstudiantesToolStripMenuItem.Name = "eliminarEstudiantesToolStripMenuItem";
            this.eliminarEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.eliminarEstudiantesToolStripMenuItem.Text = "Eliminar estudiantes";
            this.eliminarEstudiantesToolStripMenuItem.Click += new System.EventHandler(this.eliminarEstudiantesToolStripMenuItem_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(425, 299);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 31);
            this.label2.TabIndex = 199;
            this.label2.Text = "Fecha fin";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkBlue;
            this.label9.Location = new System.Drawing.Point(166, 300);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(155, 31);
            this.label9.TabIndex = 198;
            this.label9.Text = "Fecha inicio";
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button21.BackgroundImage = global::AplicacionComedor.Properties.Resources.WhatsApp_Image_2022_08_12_at_5_484;
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button21.Image = global::AplicacionComedor.Properties.Resources.id1;
            this.button21.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button21.Location = new System.Drawing.Point(275, 373);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(88, 65);
            this.button21.TabIndex = 197;
            this.button21.Text = "Consutar por estudiante";
            this.button21.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button16.BackgroundImage = global::AplicacionComedor.Properties.Resources.WhatsApp_Image_2022_08_12_at_5_484;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button16.Image = global::AplicacionComedor.Properties.Resources.calendar_blank;
            this.button16.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button16.Location = new System.Drawing.Point(380, 373);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(88, 65);
            this.button16.TabIndex = 196;
            this.button16.Text = "Consutar";
            this.button16.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.Location = new System.Drawing.Point(153, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(521, 31);
            this.label3.TabIndex = 200;
            this.label3.Text = "Consulta de asistencia por rango de fecha";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button2.BackgroundImage = global::AplicacionComedor.Properties.Resources.WhatsApp_Image_2022_08_12_at_5_485;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = global::AplicacionComedor.Properties.Resources.exel1;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.Location = new System.Drawing.Point(484, 373);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 65);
            this.button2.TabIndex = 201;
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // RangoInAsistencias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AplicacionComedor.Properties.Resources.WhatsApp_Image_2022_08_12_at_5_483;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dataGridView1);
            this.Name = "RangoInAsistencias";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Sistema de comedor";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.RangoInAsistencias_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem principalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PasarAsistenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asistenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem porFechaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem porRangoDeFechaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ausenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem porFechaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem porRangoDeFechaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem regirtroEstudiantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarEstudiantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarEstudiantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem actulizarEstudiantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminarEstudiantesToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
    }
}