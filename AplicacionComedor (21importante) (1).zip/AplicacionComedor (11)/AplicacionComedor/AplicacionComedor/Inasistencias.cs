﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class Inasistencias : Form
    {
        public Inasistencias()
        {
            InitializeComponent();
        }

        private void button13_Click(object sender, EventArgs e)
        {
          
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();



            string date = dateTimePicker1.Text;

            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.SP_consultaFechatotal33(DateTime.Parse(date)).ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) { }

            }

            dateTimePicker1.Text="";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();



            string date = dateTimePicker1.Text;

            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.SP_consultaFechatotal33(DateTime.Parse(date)).ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) { }

            }

            dateTimePicker1.Text="";
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            VentanaPrincipal v3 = new VentanaPrincipal();
            v3.Show();
        }

        private void PasarAsistenciasToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void porFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            rangoasistencias2 v3 = new rangoasistencias2();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            RangoInAsistencias v3 = new RangoInAsistencias();
            v3.Show();
        }

        private void totalDePlatosEsperadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void consultarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarEst v3 = new ConsultarEst();
            v3.Show();
        }

        private void agregarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AgregarEst v3 = new AgregarEst();
            v3.Show();
        }

        private void actulizarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ActualizarEst v3 = new ActualizarEst();
            v3.Show();
        }

        private void eliminarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EliminarEst v3 = new EliminarEst();
            v3.Show();
        }

        private void Inasistencias_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();

            string date = dateTimePicker1.Text;

            try
            {



                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    dataGridView1.DataSource = bd.SP_ausenciasfecha2R(DateTime.Parse(date)).ToList();
                    dataGridView1.Refresh();


                }



            }
            catch (Exception ex) {; }


            string mensase = "";
            string mensasef = "";


            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    var registro = bd.SP_consultaFechatotal33(DateTime.Parse(date)).ToList();

                    foreach (var people in registro)
                    {

                        mensase = people.GetValueOrDefault().ToString();

                    }

                    mensasef=("¡El número de ausencias en la fecha "+date+" es de "+mensase+" estudiantes!");

                    labelMensaje.Text=mensasef;



                }
                catch (Exception ex) { mensase="Error"; }

            }




            //dateTimePicker1.Text="";

        }

        private void button2_Click(object sender, EventArgs e)
        {

            ExportarDatos(dataGridView1);
        }



        public void ExportarDatos(DataGridView datalistado)
        {

            try
            {

                Microsoft.Office.Interop.Excel.Application exportarexcel = new Microsoft.Office.Interop.Excel.Application();

                exportarexcel.Application.Workbooks.Add(true);

                int idicecolumna = 0;
                foreach (DataGridViewColumn columna in datalistado.Columns)
                {
                    idicecolumna++;

                    exportarexcel.Cells[1, idicecolumna] = columna.Name;

                }

                int indicefila = 0;

                foreach (DataGridViewRow fila in datalistado.Rows)
                {
                    indicefila++;
                    idicecolumna=0;

                    foreach (DataGridViewColumn columna in datalistado.Columns)
                    {
                        idicecolumna++;
                        exportarexcel.Cells[indicefila+1, idicecolumna] = fila.Cells[columna.Name].Value;

                    }
                }

                exportarexcel.Visible=true;

            }
            catch (Exception ex) { MessageBox.Show("algun error"); }
        }
    }
}
