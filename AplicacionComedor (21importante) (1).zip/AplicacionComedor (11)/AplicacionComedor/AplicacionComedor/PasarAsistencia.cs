﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class PasarAsistencia : Form
    {
        public PasarAsistencia()
        {
            InitializeComponent();
            listBox1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();





            if (textBox5.Text!= string.Empty)
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {



                    try
                    {
                        listBox1.DataSource = bd.SP_consulta(int.Parse(textBox5.Text)).ToList();
                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("¡El estudiante no está registrado en el área de comedor!");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                           
                        }
                    }
                    catch (Exception ex) {; }




                }
            }



            DateTime date = DateTime.Now;

            if (textBox5.Text == string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    dataGridView1.DataSource = bd.SP_consultafecha23R(date).ToList();
                    dataGridView1.Refresh();

                }



            }


            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.SP_consultaAsistencia2R(int.Parse(textBox5.Text), date).ToList();
                    dataGridView1.Refresh();
                  
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se ingresó carnet de estudiante.");
                }


                try
                {
                    listBox1.DataSource = bd.SP_consultaAsistencia2(int.Parse(textBox5.Text), date).ToList();
                    string resultado = (string)listBox1.SelectedItem;

                    if (resultado == null)
                    {
                        MessageBox.Show("¡El estudiante no ha comido hoy!");
                    }
                    else
                    {
                        MessageBox.Show(resultado);
                        
                    }

                }
                catch (Exception ex) {; }





              //  textBox5.Text="";


            }
        }

        private void PasarAsistencia_Load(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();
            DateTime fechaBd = DateTime.Now;
            DateTime fechaActual = DateTime.Today;

            



            string mensase = "";
            string mensasef = "";

            try
            {
                using (DbComedor1Entities bd3 = new DbComedor1Entities())
                {
                    var registro = bd3.SP_fechaDia().ToList();

                    foreach (var people in registro)
                    {

                        mensase = people.ToString();

                    }

                    fechaBd = Convert.ToDateTime(mensase);

                    if (fechaBd< fechaActual)
                    {



                       // MessageBox.Show(fechaBd +" la fechas de la Bd es menor que la fecha actual "+fechaActual);
                        app2.ActualizarfechaBD(fechaActual);
                        iniciardia();
                        //button9.PerformClick(); ;
                        //button9.Visible=false;
                        // ActualizarfechaBD(DateTime fecha)
                    }
                    else
                    {
                       // MessageBox.Show("son iguales");
                      //  button9.Visible=false;

                    }


                    

                    //labelMensaje.Text=mensasef;



                }
            }
            catch (Exception ex) { mensase="Error"; }
        }


        public void iniciardia()
        {

            Controlador app2 = new Controlador();
            MessageBox.Show(app2.reiniciaeAsistencia1().ToString());
           // MessageBox.Show("Ya puede Iniciar el programa");


            DateTime date = DateTime.Now;


            // using (DbComedor1Entities bd = new DbComedor1Entities())
            // {
            try
            {
                // dataGridView1.DataSource = bd.SP_consultacarnetAusentes().ToList();
                //dataGridView1.Refresh();

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    var registro = bd.SP_consultacarnetAusentes().ToList();

                    foreach (var people in registro)
                    {

                        int v = people.GetValueOrDefault();

                        String b = app2.ausentes(v, date, 0).ToString();

                    }
                    bd.SaveChanges();

                }


            }
            catch (Exception ex) { }
        }



        private void button5_Click(object sender, EventArgs e)
        {/*
            Controlador app2 = new Controlador();
            DateTime date = DateTime.Now;

            try
            {
                string a = (app2.asistencia(int.Parse(textBox5.Text), date, 2).ToString());

                //  MessageBox.Show(app2.asistencia(int.Parse(textBox5.Text), date, 1).ToString());

                if (a.Equals("True"))
                {
                    app2.ActualizaralumnoAsistencia(int.Parse(textBox5.Text)).ToString();
                    MessageBox.Show(a);
                }
                else
                {
                    MessageBox.Show("False");

                }


            }
            catch (Exception ex) { MessageBox.Show("Compruebe los datos de entrada."); }


            textBox5.Text="";
            */
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();
            DateTime date = DateTime.Now;

            try
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {


                    var r = bd.SP_ausenciasfechaId(date, int.Parse(textBox5.Text)).ToList();

                    if (r.Count == 0)
                    {


                        var r2 = bd.SP_aux(date, int.Parse(textBox5.Text)).ToList();

                        if (r2.Count > 0)
                        {
                            MessageBox.Show("¡El estudiante ya comió!");
                        }
                        else 
                        { 



                            //    MessageBox.Show("aqui busca en estudiante si no esta en lista");
                                string a = (app2.asistencia(int.Parse(textBox5.Text), date, 1).ToString());

                                //  MessageBox.Show(app2.asistencia(int.Parse(textBox5.Text), date, 1).ToString());

                                if (a.Equals("True"))
                                {

                                    app2.ActualizaralumnoAsistencia(int.Parse(textBox5.Text)).ToString();
                                    MessageBox.Show(a);

                                //    MessageBox.Show("aqui actualiza");
                                }
                                else
                                {
                                    MessageBox.Show("False");

                                }


                        }
                    }

                    else { MessageBox.Show("Correcto"); }


                    //  dataGridView1.DataSource =r;

                    int v = 0;
                    foreach (var people in r)
                    {

                        v= people.GetValueOrDefault();
                        bd.SP_tardia3(v);
                      //  MessageBox.Show(v.ToString());

                    }
                    bd.SaveChanges();
                  //  MessageBox.Show(app2.ActualizaralumnoAsistencia(int.Parse(textBox5.Text)).ToString());
                    app2.ActualizaralumnoAsistencia(int.Parse(textBox5.Text)).ToString();
                   // MessageBox.Show("Estudiante Agregado");
                }



            }
            catch (Exception ex) { MessageBox.Show("Compruebe los datos de entrada."); }


            textBox5.Text="";








        }

        private void button2_Click(object sender, EventArgs e)
        {
            ExportarDatos(dataGridView1);
        }


        public void ExportarDatos(DataGridView datalistado)
        {

            try
            {

                Microsoft.Office.Interop.Excel.Application exportarexcel = new Microsoft.Office.Interop.Excel.Application();

                exportarexcel.Application.Workbooks.Add(true);

                int idicecolumna = 0;
                foreach (DataGridViewColumn columna in datalistado.Columns)
                {
                    idicecolumna++;

                    exportarexcel.Cells[1, idicecolumna] = columna.Name;

                }

                int indicefila = 0;

                foreach (DataGridViewRow fila in datalistado.Rows)
                {
                    indicefila++;
                    idicecolumna=0;

                    foreach (DataGridViewColumn columna in datalistado.Columns)
                    {
                        idicecolumna++;
                        exportarexcel.Cells[indicefila+1, idicecolumna] = fila.Cells[columna.Name].Value;

                    }
                }

                exportarexcel.Visible=true;

            }
            catch (Exception ex) { MessageBox.Show("Algún error."); }
        }

        private void button9_Click(object sender, EventArgs e)
        {
          
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
          
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            appComedor v3 = new appComedor();
            v3.Show();
        }

        private void pasarAsistenciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            appComedor v3 = new appComedor();
            v3.Show();
        }

        private void consultasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void regirtrasNuevoEstudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void regirtrarNuevoEstudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegistroEst v3 = new RegistroEst();
            v3.Show();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            VentanaPrincipal v3 = new VentanaPrincipal();
            v3.Show();
        }

        private void porFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            rangoasistencias2 v3 = new rangoasistencias2();
            v3.Show();
        }

        private void porFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Inasistencias v3 = new Inasistencias();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            RangoInAsistencias v3 = new RangoInAsistencias();
            v3.Show();
        }

        private void totalDePlatosEsperadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void consultarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarEst v3 = new ConsultarEst();
            v3.Show();
        }

        private void agregarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AgregarEst v3 = new AgregarEst();
            v3.Show();
        }

        private void actulizarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ActualizarEst v3 = new ActualizarEst();
            v3.Show();
        }

        private void eliminarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EliminarEst v3 = new EliminarEst();
            v3.Show();
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo numeros
            if ((e.KeyChar >=32  && e.KeyChar <=47) || (e.KeyChar>=58 && e.KeyChar<=255))
            {
                MessageBox.Show("¡No se puede ingresar letras en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }
    }
}
