﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AplicacionComedor
{
    public partial class upNombreColegio : Form
    {
        public upNombreColegio()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();

           
            try
            {
                string nombre = textBox1.Text;
                if (nombre == string.Empty) {
                    MessageBox.Show("Ingrese un nombre");
                }
                else
                {
                    using (DbComedor1Entities bd = new DbComedor1Entities())
                    {

                        app2.ActualizarnombreColegio(1, nombre).ToString();
                        MessageBox.Show("Nombre Agregado");
                    }

                    textBox1.Text="";
                    this.Hide();
                    upNombreColegio v3 = new upNombreColegio();
                    v3.Show();

                }



            }
            catch (Exception ex) { MessageBox.Show("Compruebe los datos de entrada"); }


            textBox1.Text="";

        }

        private void regresarAlInicioDeSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            principal v3 = new principal();
            v3.Show();
        }

        private void usuarioComunToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrearUsuario v3 = new CrearUsuario();
            v3.Show();
        }

        private void usuarioAdministradorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrearUsuarioAdmin v3 = new CrearUsuarioAdmin();
            v3.Show();
        }

        private void consultarUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            ConsultarUsuarios v3 = new ConsultarUsuarios();
            v3.Show();
        }

        private void actualizarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ActualizarUsuario v3 = new ActualizarUsuario();
            v3.Show();
        }

        private void eliminarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EliminarUsuario v3 = new EliminarUsuario();
            v3.Show();
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegisroUsr v3 = new RegisroUsr();
            v3.Show();
        }

        private void nombreDeColegioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void upNombreColegio_Load(object sender, EventArgs e)
        {

            string mensase = "";
            string mensasef = "";

            try
            {
                using (DbComedor1Entities bd3 = new DbComedor1Entities())
                {
                    var registro = bd3.SP_NOMBREDECOLEVista3().ToList();

                    foreach (var people in registro)
                    {

                        mensase = people.ToString();

                    }

                    mensasef=("El nombre actual es: "+mensase);

                    labelMensaje.Text=mensasef;



                }
            }
            catch (Exception ex) { mensase="Error"; }
        }

        private void button3_Click(object sender, EventArgs e)
        {


        }
    }
}
