﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class ConsultarEst : Form
    {
        public ConsultarEst()
        {
            InitializeComponent();
            listBox1.Visible = false;
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            VentanaPrincipal v3 = new VentanaPrincipal();
            v3.Show();
        }

        private void PasarAsistenciasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void porFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            rangoasistencias2 v3 = new rangoasistencias2();
            v3.Show();
        }

        private void porFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Inasistencias v3 = new Inasistencias();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            RangoInAsistencias v3 = new RangoInAsistencias();
            v3.Show();
        }

        private void totalDePlatosEsperadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void agregarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AgregarEst v3 = new AgregarEst();
            v3.Show();
        }

        private void actulizarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ActualizarEst v3 = new ActualizarEst();
            v3.Show();
        }

        private void eliminarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EliminarEst v3 = new EliminarEst();
            v3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            if (textBox1.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    try
                    {
                        dataGridView1.DataSource = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();

                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado.");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }


                }
            }
            else if (textBox2.Text!= string.Empty && textBox3.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    try
                    {
                        dataGridView1.DataSource = bd.SP_consultaApellidos3R(textBox2.Text.ToUpper(), textBox3.Text.ToUpper()).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consultaApellidos3R(textBox2.Text, textBox3.Text).ToList();


                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado o ingreso mal los valores.");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }

                }

            }
            else
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    try
                    {
                        dataGridView1.DataSource = bd.SP_todoest33R().ToList();
                        dataGridView1.Refresh();

                        //  dataGridView1.DataSource = bd.estudiantes.ToList();
                        //dataGridView1.Refresh();
                    }
                    catch (Exception ex) {; }
                }
            }


            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
            textBox4.Text="";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ExportarDatos(dataGridView1);
        }


        public void ExportarDatos(DataGridView datalistado)
        {

            try
            {

                Microsoft.Office.Interop.Excel.Application exportarexcel = new Microsoft.Office.Interop.Excel.Application();

                exportarexcel.Application.Workbooks.Add(true);

                int idicecolumna = 0;
                foreach (DataGridViewColumn columna in datalistado.Columns)
                {
                    idicecolumna++;

                    exportarexcel.Cells[1, idicecolumna] = columna.Name;

                }

                int indicefila = 0;

                foreach (DataGridViewRow fila in datalistado.Rows)
                {
                    indicefila++;
                    idicecolumna=0;

                    foreach (DataGridViewColumn columna in datalistado.Columns)
                    {
                        idicecolumna++;
                        exportarexcel.Cells[indicefila+1, idicecolumna] = fila.Cells[columna.Name].Value;

                    }
                }

                exportarexcel.Visible=true;

            }
            catch (Exception ex) { MessageBox.Show("algun error."); }
        }

        private void ConsultarEst_Load(object sender, EventArgs e)
        {

            string mensase = "";
            string mensasef = "";

            try
            {
                using (DbComedor1Entities bd3 = new DbComedor1Entities())
                {
                    var registro = bd3.SP_Hoy().ToList();

                    foreach (var people in registro)
                    {

                        mensase = people.GetValueOrDefault().ToString();

                    }

                    mensasef=("¡Actualmente hay "+mensase+" estudiantes registrados!");

                    labelMensaje.Text=mensasef;



                }
            }
            catch (Exception ex) { mensase="Error"; }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo numeros
            if ((e.KeyChar >=32  && e.KeyChar <=47) || (e.KeyChar>=58 && e.KeyChar<=255))
            {
                MessageBox.Show("¡No se puede ingresar letras en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }
    }
}
