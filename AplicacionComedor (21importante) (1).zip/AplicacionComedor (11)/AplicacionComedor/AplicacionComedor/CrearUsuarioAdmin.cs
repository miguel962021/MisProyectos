﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class CrearUsuarioAdmin : Form
    {
        public CrearUsuarioAdmin()
        {
            InitializeComponent();
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegisroUsr v3 = new RegisroUsr();
            v3.Show();
        }

        private void usuarioComunToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrearUsuario v3 = new CrearUsuario();
            v3.Show();
        }

        private void usuarioAdministradorToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void consultarUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarUsuarios v3 = new ConsultarUsuarios();
            v3.Show();
        }

        private void actualizarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ActualizarUsuario v3 = new ActualizarUsuario();
            v3.Show();
        }

        private void eliminarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EliminarUsuario v3 = new EliminarUsuario();
            v3.Show();
        }

        private void regresarAlInicioDeSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            principal v3 = new principal();
            v3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.loginicios.ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) {; }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text!= string.Empty && textBox2.Text!= string.Empty)
            {
                string usuario = textBox1.Text;
                string num = "";
                int numero = 0;




                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    try
                    {
                        var registro = bd.SP_confirmarUsr(usuario).ToList();

                        foreach (var people in registro)
                        {

                            numero = people.GetValueOrDefault();

                            //num = people.ToString();

                        }
                        //numero = Convert.ToInt32(Convert.ToString(num));



                        if (numero >0)
                        {
                            MessageBox.Show(Convert.ToString("El nombre de usuario ya existe."));
                        }
                        else
                        {
                            try
                            {
                                Controlador app2 = new Controlador();
                                MessageBox.Show(app2.insertarusuario(0, textBox1.Text, textBox2.Text, 1).ToString());

                            }
                            catch (Exception ex) { MessageBox.Show("Error al cargar datos."); }


                        }
                    }
                    catch (Exception ex) {; }
                }



                //insertarusuario(int id, string usuario, string contraseña, int bitpar)
           /*     try
                {
                    Controlador app2 = new Controlador();
                    MessageBox.Show(app2.insertarusuario(0, textBox1.Text, textBox2.Text, 1).ToString());

                }
                catch (Exception ex) { MessageBox.Show("Error al cargar datos."); }
            */
            }
            else
            {
                MessageBox.Show("Error al agregar usuario.  No pueden quedar campos vacíos.");
            }
            textBox1.Text="";
            textBox2.Text="";
            
        }

        private void nombreDeColegioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            upNombreColegio v3 = new upNombreColegio();
            v3.Show();
        }

        private void CrearUsuarioAdmin_Load(object sender, EventArgs e)
        {

        }
    }
}
