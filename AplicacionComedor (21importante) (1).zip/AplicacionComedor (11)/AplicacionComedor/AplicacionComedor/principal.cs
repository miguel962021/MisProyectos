﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class principal : Form
    {
        public principal()
        {
            InitializeComponent();
            listBox1.Visible = false;
        }

        private void principal_Load(object sender, EventArgs e)
        {
            /*
            string mensase = "";
            string mensasef = "";

            try
            {
                using (DbComedor1Entities bd3 = new DbComedor1Entities())
                {
                    var registro = bd3.SP_NOMBREDECOLEVista3().ToList();

                    foreach (var people in registro)
                    {

                        mensase = people.ToString();

                    }

                    mensasef=(mensase);

                    labelMensaje.Text=mensasef;



                }
            }
            catch (Exception ex) { mensase="Error"; }
            */
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text!= string.Empty && textBox2.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    try
                    {

                        int d = 0;
                        var re = bd.SP_inicioLogin3(textBox1.Text, textBox2.Text).ToList();

                        foreach (var people in re)
                        {
                            int v = people.GetValueOrDefault();
                            d = v; 
                        }

                        if (d==1)
                        {
                            MessageBox.Show("El usuario administrador ha sido encontrado.");
                            //Application.Run(new appComedor());
                            this.Hide();
                            RegisroUsr v1 = new RegisroUsr();
                            v1.Show();
                        }
                        else if (d ==2) {
                            MessageBox.Show("El usuario ha sido encontrado.");
                            this.Hide();
                            VentanaPrincipal v2 = new VentanaPrincipal();
                            v2.Show();

                        }
                        else
                        {
                            MessageBox.Show("El usuario no ha sido encontrado.");
                        }
                      
                    }
                    catch (Exception ex) {; }

                }
            }
            else
            {
                MessageBox.Show("No ingresio el usuario ó  la contraseña.");

            }


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
        }
    }
}
