﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class EliminarUsuario : Form
    {
        public EliminarUsuario()
        {
            InitializeComponent();
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegisroUsr v3 = new RegisroUsr();
            v3.Show();
        }

        private void usuarioComunToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrearUsuario v3 = new CrearUsuario();
            v3.Show();
        }

        private void usuarioAdministradorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrearUsuarioAdmin v3 = new CrearUsuarioAdmin();
            v3.Show();
        }

        private void consultarUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarUsuarios v3 = new ConsultarUsuarios();
            v3.Show();
        }

        private void actualizarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ActualizarUsuario v3 = new ActualizarUsuario();
            v3.Show();
        }

        private void eliminarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void regresarAlInicioDeSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            principal v3 = new principal();
            v3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.loginicios.ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) {; }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Controlador app2 = new Controlador();
                MessageBox.Show(app2.EliminarUsuario(int.Parse(textBox3.Text)).ToString());
               
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error al eliminar usuario");
            }

           

        }

        private void nombreDeColegioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            upNombreColegio v3 = new upNombreColegio();
            v3.Show();
        }
    }
}
