﻿namespace AplicacionComedor
{
    partial class RegisroUsr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.principalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crearUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crearUsuarioToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.usuarioComunToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usuarioAdministradorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.actualizarUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regresarAlInicioDeSessionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.principalToolStripMenuItem,
            this.crearUsuarioToolStripMenuItem,
            this.regresarAlInicioDeSessionToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 152;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // principalToolStripMenuItem
            // 
            this.principalToolStripMenuItem.Name = "principalToolStripMenuItem";
            this.principalToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.principalToolStripMenuItem.Text = "Principal";
            this.principalToolStripMenuItem.Click += new System.EventHandler(this.principalToolStripMenuItem_Click);
            // 
            // crearUsuarioToolStripMenuItem
            // 
            this.crearUsuarioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.crearUsuarioToolStripMenuItem1,
            this.consultarUsuariosToolStripMenuItem,
            this.actualizarUsuarioToolStripMenuItem,
            this.eliminarUsuarioToolStripMenuItem});
            this.crearUsuarioToolStripMenuItem.Name = "crearUsuarioToolStripMenuItem";
            this.crearUsuarioToolStripMenuItem.Size = new System.Drawing.Size(119, 24);
            this.crearUsuarioToolStripMenuItem.Text = "Configuración";
            // 
            // crearUsuarioToolStripMenuItem1
            // 
            this.crearUsuarioToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usuarioComunToolStripMenuItem,
            this.usuarioAdministradorToolStripMenuItem});
            this.crearUsuarioToolStripMenuItem1.Name = "crearUsuarioToolStripMenuItem1";
            this.crearUsuarioToolStripMenuItem1.Size = new System.Drawing.Size(204, 24);
            this.crearUsuarioToolStripMenuItem1.Text = "Crear usuario";
            // 
            // usuarioComunToolStripMenuItem
            // 
            this.usuarioComunToolStripMenuItem.Name = "usuarioComunToolStripMenuItem";
            this.usuarioComunToolStripMenuItem.Size = new System.Drawing.Size(235, 24);
            this.usuarioComunToolStripMenuItem.Text = "Usuario común";
            this.usuarioComunToolStripMenuItem.Click += new System.EventHandler(this.usuarioComunToolStripMenuItem_Click);
            // 
            // usuarioAdministradorToolStripMenuItem
            // 
            this.usuarioAdministradorToolStripMenuItem.Name = "usuarioAdministradorToolStripMenuItem";
            this.usuarioAdministradorToolStripMenuItem.Size = new System.Drawing.Size(235, 24);
            this.usuarioAdministradorToolStripMenuItem.Text = "Usuario administrador";
            this.usuarioAdministradorToolStripMenuItem.Click += new System.EventHandler(this.usuarioAdministradorToolStripMenuItem_Click);
            // 
            // consultarUsuariosToolStripMenuItem
            // 
            this.consultarUsuariosToolStripMenuItem.Name = "consultarUsuariosToolStripMenuItem";
            this.consultarUsuariosToolStripMenuItem.Size = new System.Drawing.Size(204, 24);
            this.consultarUsuariosToolStripMenuItem.Text = "Consultar usuario";
            this.consultarUsuariosToolStripMenuItem.Click += new System.EventHandler(this.consultarUsuariosToolStripMenuItem_Click);
            // 
            // actualizarUsuarioToolStripMenuItem
            // 
            this.actualizarUsuarioToolStripMenuItem.Name = "actualizarUsuarioToolStripMenuItem";
            this.actualizarUsuarioToolStripMenuItem.Size = new System.Drawing.Size(204, 24);
            this.actualizarUsuarioToolStripMenuItem.Text = "Actualizar usuario";
            this.actualizarUsuarioToolStripMenuItem.Click += new System.EventHandler(this.actualizarUsuarioToolStripMenuItem_Click);
            // 
            // eliminarUsuarioToolStripMenuItem
            // 
            this.eliminarUsuarioToolStripMenuItem.Name = "eliminarUsuarioToolStripMenuItem";
            this.eliminarUsuarioToolStripMenuItem.Size = new System.Drawing.Size(204, 24);
            this.eliminarUsuarioToolStripMenuItem.Text = "Eliminar usuario";
            this.eliminarUsuarioToolStripMenuItem.Click += new System.EventHandler(this.eliminarUsuarioToolStripMenuItem_Click);
            // 
            // regresarAlInicioDeSessionToolStripMenuItem
            // 
            this.regresarAlInicioDeSessionToolStripMenuItem.Name = "regresarAlInicioDeSessionToolStripMenuItem";
            this.regresarAlInicioDeSessionToolStripMenuItem.Size = new System.Drawing.Size(209, 24);
            this.regresarAlInicioDeSessionToolStripMenuItem.Text = "Regresar al inicio de sesión";
            this.regresarAlInicioDeSessionToolStripMenuItem.Click += new System.EventHandler(this.regresarAlInicioDeSessionToolStripMenuItem_Click);
            // 
            // RegisroUsr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AplicacionComedor.Properties.Resources.WhatsApp_Image_2022_08_12_at_5_482;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Name = "RegisroUsr";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Sistema de comedor";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem principalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crearUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crearUsuarioToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem usuarioComunToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuarioAdministradorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem actualizarUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminarUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regresarAlInicioDeSessionToolStripMenuItem;
    }
}