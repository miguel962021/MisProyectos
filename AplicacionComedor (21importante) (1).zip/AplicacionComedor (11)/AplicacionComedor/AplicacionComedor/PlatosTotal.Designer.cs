﻿namespace AplicacionComedor
{
    partial class PlatosTotal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button19 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.principalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PasarAsistenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.asistenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porFechaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porRangoDeFechaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ausenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porFechaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.porRangoDeFechaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.totalDePlatosEsperadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regirtroEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.actulizarEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarEstudiantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(278, 250);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(180, 25);
            this.button19.TabIndex = 153;
            this.button19.Text = "Platos Esperados";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.PaleTurquoise;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Location = new System.Drawing.Point(193, 64);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(438, 146);
            this.dataGridView1.TabIndex = 154;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.principalToolStripMenuItem,
            this.PasarAsistenciasToolStripMenuItem,
            this.consultasToolStripMenuItem,
            this.regirtroEstudiantesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 170;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // principalToolStripMenuItem
            // 
            this.principalToolStripMenuItem.Name = "principalToolStripMenuItem";
            this.principalToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.principalToolStripMenuItem.Text = "Principal";
            // 
            // PasarAsistenciasToolStripMenuItem
            // 
            this.PasarAsistenciasToolStripMenuItem.Name = "PasarAsistenciasToolStripMenuItem";
            this.PasarAsistenciasToolStripMenuItem.Size = new System.Drawing.Size(134, 24);
            this.PasarAsistenciasToolStripMenuItem.Text = "Pasar Asistencia";
            // 
            // consultasToolStripMenuItem
            // 
            this.consultasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.asistenciasToolStripMenuItem,
            this.ausenciasToolStripMenuItem,
            this.totalDePlatosEsperadosToolStripMenuItem});
            this.consultasToolStripMenuItem.Name = "consultasToolStripMenuItem";
            this.consultasToolStripMenuItem.Size = new System.Drawing.Size(89, 24);
            this.consultasToolStripMenuItem.Text = "Consultas";
            // 
            // asistenciasToolStripMenuItem
            // 
            this.asistenciasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.porFechaToolStripMenuItem,
            this.porRangoDeFechaToolStripMenuItem});
            this.asistenciasToolStripMenuItem.Name = "asistenciasToolStripMenuItem";
            this.asistenciasToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.asistenciasToolStripMenuItem.Text = "Asistencias";
            // 
            // porFechaToolStripMenuItem
            // 
            this.porFechaToolStripMenuItem.Name = "porFechaToolStripMenuItem";
            this.porFechaToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.porFechaToolStripMenuItem.Text = "Por fecha";
            // 
            // porRangoDeFechaToolStripMenuItem
            // 
            this.porRangoDeFechaToolStripMenuItem.Name = "porRangoDeFechaToolStripMenuItem";
            this.porRangoDeFechaToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.porRangoDeFechaToolStripMenuItem.Text = "Por rango de fecha";
            // 
            // ausenciasToolStripMenuItem
            // 
            this.ausenciasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.porFechaToolStripMenuItem1,
            this.porRangoDeFechaToolStripMenuItem1});
            this.ausenciasToolStripMenuItem.Name = "ausenciasToolStripMenuItem";
            this.ausenciasToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.ausenciasToolStripMenuItem.Text = "Inasistencias";
            // 
            // porFechaToolStripMenuItem1
            // 
            this.porFechaToolStripMenuItem1.Name = "porFechaToolStripMenuItem1";
            this.porFechaToolStripMenuItem1.Size = new System.Drawing.Size(210, 24);
            this.porFechaToolStripMenuItem1.Text = "Por fecha";
            // 
            // porRangoDeFechaToolStripMenuItem1
            // 
            this.porRangoDeFechaToolStripMenuItem1.Name = "porRangoDeFechaToolStripMenuItem1";
            this.porRangoDeFechaToolStripMenuItem1.Size = new System.Drawing.Size(210, 24);
            this.porRangoDeFechaToolStripMenuItem1.Text = "Por rango de fecha";
            // 
            // totalDePlatosEsperadosToolStripMenuItem
            // 
            this.totalDePlatosEsperadosToolStripMenuItem.Name = "totalDePlatosEsperadosToolStripMenuItem";
            this.totalDePlatosEsperadosToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.totalDePlatosEsperadosToolStripMenuItem.Text = "Total de platos esperados";
            // 
            // regirtroEstudiantesToolStripMenuItem
            // 
            this.regirtroEstudiantesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consultarEstudiantesToolStripMenuItem,
            this.agregarEstudiantesToolStripMenuItem,
            this.actulizarEstudiantesToolStripMenuItem,
            this.eliminarEstudiantesToolStripMenuItem});
            this.regirtroEstudiantesToolStripMenuItem.Name = "regirtroEstudiantesToolStripMenuItem";
            this.regirtroEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(186, 24);
            this.regirtroEstudiantesToolStripMenuItem.Text = "Registro de estudiantes";
            // 
            // consultarEstudiantesToolStripMenuItem
            // 
            this.consultarEstudiantesToolStripMenuItem.Name = "consultarEstudiantesToolStripMenuItem";
            this.consultarEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(230, 24);
            this.consultarEstudiantesToolStripMenuItem.Text = "Consultar estudiantes";
            // 
            // agregarEstudiantesToolStripMenuItem
            // 
            this.agregarEstudiantesToolStripMenuItem.Name = "agregarEstudiantesToolStripMenuItem";
            this.agregarEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(230, 24);
            this.agregarEstudiantesToolStripMenuItem.Text = "Agregar estudiantes";
            // 
            // actulizarEstudiantesToolStripMenuItem
            // 
            this.actulizarEstudiantesToolStripMenuItem.Name = "actulizarEstudiantesToolStripMenuItem";
            this.actulizarEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(230, 24);
            this.actulizarEstudiantesToolStripMenuItem.Text = "Actulizar estudiantes";
            // 
            // eliminarEstudiantesToolStripMenuItem
            // 
            this.eliminarEstudiantesToolStripMenuItem.Name = "eliminarEstudiantesToolStripMenuItem";
            this.eliminarEstudiantesToolStripMenuItem.Size = new System.Drawing.Size(230, 24);
            this.eliminarEstudiantesToolStripMenuItem.Text = "Eliminar estudiantes";
            // 
            // PlatosTotal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AplicacionComedor.Properties.Resources.WhatsApp_Image_2022_08_12_at_5_484;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button19);
            this.Name = "PlatosTotal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Sistema de comedor";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem principalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PasarAsistenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asistenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem porFechaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem porRangoDeFechaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ausenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem porFechaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem porRangoDeFechaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem totalDePlatosEsperadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regirtroEstudiantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarEstudiantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarEstudiantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem actulizarEstudiantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminarEstudiantesToolStripMenuItem;
    }
}