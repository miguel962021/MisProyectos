﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace AplicacionComedor
{
    public partial class appComedor : Form
    {
        public appComedor()
        {
            InitializeComponent();
            listBox1.Visible = false;
            button15.Visible = false;
            button16.Visible = false;

            button20.Visible = false;
            button21.Visible = false;
            dateTimePicker2.Visible = false;
            label1.Visible = false;




        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Controlador app2 = new Controlador();
                MessageBox.Show(app2.Eliminaralumno(int.Parse(textBox1.Text)).ToString());
                textBox1.Text="";
            }
            catch(Exception ex ) { 
             
                MessageBox.Show("Error al eliminar estudiante");
            }
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try {

                Controlador app2 = new Controlador();
                MessageBox.Show(app2.Actualizaralumno(int.Parse(textBox1.Text), textBox2.Text.ToUpper(), textBox3.Text.ToUpper(), textBox4.Text.ToUpper(), 0).ToString());

            }
            catch (Exception ex) { MessageBox.Show("Error al actulizar datos"); }

            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
            textBox4.Text="";
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            if (textBox1.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                  
                    try
                    {
                        dataGridView1.DataSource = bd.SP_consulta(int.Parse(textBox1.Text)).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consulta(int.Parse(textBox1.Text)).ToList();

                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }


                }
            }
            else if (textBox2.Text!= string.Empty && textBox3.Text!= string.Empty) {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                  
                    try
                    {
                        dataGridView1.DataSource = bd.SP_consultaApellidos3(textBox2.Text.ToUpper(), textBox3.Text.ToUpper()).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consultaApellidos3(textBox2.Text, textBox3.Text).ToList();


                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado o ingreso mal los valores");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }

                }

            }
            else
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    try
                    {
                        dataGridView1.DataSource = bd.SP_todoest().ToList();
                        dataGridView1.Refresh();

                      //  dataGridView1.DataSource = bd.estudiantes.ToList();
                        //dataGridView1.Refresh();
                    }
                    catch (Exception ex) {; }
                }
            }

        
            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
            textBox4.Text="";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try {
                Controlador app2 = new Controlador();
                MessageBox.Show(app2.insertarAlumno(int.Parse(textBox1.Text), textBox2.Text.ToUpper(), textBox3.Text.ToUpper(), textBox4.Text.ToUpper(), 0).ToString());

            }
            catch (Exception ex) { MessageBox.Show("Error al cargar datos"); }
            
            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
            textBox4.Text="";
        }


        public void ExportarDatos(DataGridView datalistado) {

            try { 

            Microsoft.Office.Interop.Excel.Application exportarexcel = new Microsoft.Office.Interop.Excel.Application();

            exportarexcel.Application.Workbooks.Add(true);

            int idicecolumna = 0;
            foreach (DataGridViewColumn columna in datalistado.Columns)
            {
                idicecolumna++;

                exportarexcel.Cells[1, idicecolumna] = columna.Name;
                
            }

            int indicefila = 0;

            foreach(DataGridViewRow fila in datalistado.Rows )
            {
                indicefila++;
                idicecolumna=0;

                foreach (DataGridViewColumn columna in datalistado.Columns)
                {
                    idicecolumna++;
                    exportarexcel.Cells[indicefila+1, idicecolumna] = fila.Cells[columna.Name].Value;

                }
            }

            exportarexcel.Visible=true;
           
            }
            catch (Exception ex) { MessageBox.Show("algun error"); }
        }


        private void button9_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();

            using (DbComedor1Entities bd = new DbComedor1Entities())
            {


                bd.SP_reinicioAsistencia();



            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();





            if (textBox5.Text!= string.Empty)
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {



                    try
                    {
                        listBox1.DataSource = bd.SP_consulta(int.Parse(textBox5.Text)).ToList();
                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("¡El estudiante no está registrado en el área de comedor!");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }




                }
            }



            DateTime date = DateTime.Now;

            if (textBox5.Text == string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    dataGridView1.DataSource = bd.SP_consultafecha(date).ToList();
                    dataGridView1.Refresh();

                }



            }


            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.SP_consultaAsistencia2(int.Parse(textBox5.Text), date).ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se ingresó carnet de estudiante");
                }


                try
                {
                    listBox1.DataSource = bd.SP_consultaAsistencia2(int.Parse(textBox5.Text), date).ToList();
                    string resultado = (string)listBox1.SelectedItem;

                    if (resultado == null)
                    {
                        MessageBox.Show("!El estudiante no ha comido hoy!");
                    }
                    else
                    {
                        MessageBox.Show(resultado);
                    }

                }
                catch (Exception ex) {; }





                textBox5.Text="";


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();
            DateTime date = DateTime.Now;

            try
            {
                string a = (app2.asistencia(int.Parse(textBox5.Text), date, 1).ToString());

                //  MessageBox.Show(app2.asistencia(int.Parse(textBox5.Text), date, 1).ToString());

                if (a.Equals("True"))
                {
                    app2.ActualizaralumnoAsistencia(int.Parse(textBox5.Text)).ToString();
                    MessageBox.Show(a);
                }
                else
                {
                    MessageBox.Show("false");

                }


            }
            catch (Exception ex) { MessageBox.Show("Compruebe los datos de entrada"); }


            textBox5.Text="";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            /*Controlador app2 = new Controlador();



            DateTime date = DateTime.Now;

            using (DbComedor1Entities bd = new DbComedor1Entities())
            {

                dataGridView1.DataSource = bd.SP_consultaFechatotal77(date).ToList();
                dataGridView1.Refresh();


            }*/
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();



            string date = dateTimePicker1.Text;

            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.SP_consultaFechatotal77(DateTime.Parse(date)).ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) { }

            }

            dateTimePicker1.Text="";

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();


            try
            {

                string date = dateTimePicker1.Text;


                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    dataGridView1.DataSource = bd.SP_consultafechaasitencia77(DateTime.Parse(date)).ToList();
                    dataGridView1.Refresh();


                }



            }
            catch (Exception ex) {; }

            dateTimePicker1.Text="";


        }



        private void Form1_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("Si este es su primer arranque del día, presione 'Iniciar' después de este mensaje para comenzar a usar el programa.\n" +
           //" De lo contrario ignora el mensaje");
        }

        private void button9_Click_1(object sender, EventArgs e)
        {

        
        }

        private void button9_Click_2(object sender, EventArgs e)
        {
            
            Controlador app2 = new Controlador();
            MessageBox.Show(app2.reiniciaeAsistencia1().ToString());
            MessageBox.Show("Ya puede Iniciar el programa");
            button9.Visible = false;

        }

        private void button11_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();
       

            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.SP_ausenciasdeldianumeroNombre().ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) { }

            }

            
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();
            DateTime date = DateTime.Now;

            try
            {
                 bool v = (app2.verificarAusencia(int.Parse(textBox5.Text)));
                string a = "";
                if (v== true) {
                     a = (app2.ausentes(int.Parse(textBox5.Text), date, 0).ToString());


                }



                //  MessageBox.Show(app2.asistencia(int.Parse(textBox5.Text), date, 1).ToString());

                if (a.Equals("True"))
                {
                  //  app2.ActualizaralumnoAsistencia(int.Parse(textBox5.Text)).ToString();
                    MessageBox.Show(a);
                }
                else
                {
                    MessageBox.Show("false");

                }


            }
            catch (Exception ex) { MessageBox.Show("Compruebe los datos de entrada"); }


            textBox5.Text="";
        }

        private void button13_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            try
            {

                string date = dateTimePicker1.Text;


                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    dataGridView1.DataSource = bd.SP_ausenciasfecha(DateTime.Parse(date)).ToList();
                    dataGridView1.Refresh();


                }



            }
            catch (Exception ex) {; }
            dateTimePicker1.Text="";

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();



            string date = dateTimePicker1.Text;

            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.SP_consultaFechatotal33(DateTime.Parse(date)).ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) { }

            }

            dateTimePicker1.Text="";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();
            DateTime date = DateTime.Now;


           // using (DbComedor1Entities bd = new DbComedor1Entities())
           // {
                try
                {
                // dataGridView1.DataSource = bd.SP_consultacarnetAusentes().ToList();
                //dataGridView1.Refresh();

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    var registro = bd.SP_consultacarnetAusentes().ToList();

                    foreach (var people in registro)
                    {

                       int v = people.GetValueOrDefault();
                      
                        String b = app2.ausentes(v, date, 0).ToString();
                   
                    }
                    bd.SaveChanges();

                }

                MessageBox.Show("Ya puede finalizar el programa");

            }
            catch (Exception ex) { }

            button14.Visible = false;
            //}
        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();
            DateTime date = DateTime.Now;

            try
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {


                    var r = bd.SP_ausenciasfechaId(date, int.Parse(textBox5.Text)).ToList();

                  //  dataGridView1.DataSource =r;

                    int v = 0;
                    foreach (var people in r)
                    {

                        v= people.GetValueOrDefault();
                        bd.SP_tardia3(v);

                    }
                    bd.SaveChanges();
                    
                    app2.ActualizaralumnoAsistencia(int.Parse(textBox5.Text)).ToString();
                    MessageBox.Show("Estudiante Agregado");
                }



            }
            catch (Exception ex) { MessageBox.Show("Compruebe los datos de entrada"); }


           textBox5.Text="";

            


              



            


        }

        private void button15_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            try
            {

                string date = dateTimePicker1.Text;

                string date2 = dateTimePicker2.Text;


                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    dataGridView1.DataSource = bd.SP_consultaAusenciasRango2(DateTime.Parse(date), DateTime.Parse(date2)).ToList();
                    dataGridView1.Refresh();


                }



            }
            catch (Exception ex) {; }

            dateTimePicker1.Text="";
            dateTimePicker2.Text="";

        }

        private void button17_Click(object sender, EventArgs e)
        {
            button15.Visible = true;
            button16.Visible = true;
            button20.Visible = true;
            button21.Visible = true;
            dateTimePicker2.Visible = true;
            label1.Visible = true;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();


            try
            {

                string date = dateTimePicker1.Text;
                string date2 = dateTimePicker2.Text;


                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    dataGridView1.DataSource = bd.SP_consultafechaasitenciaRango2(DateTime.Parse(date), DateTime.Parse(date2)).ToList();
                    dataGridView1.Refresh();


                }



            }
            catch (Exception ex) {; }


            dateTimePicker1.Text="";
            dateTimePicker2.Text="";
        }

        private void button18_Click(object sender, EventArgs e)
        {
            ExportarDatos(dataGridView1);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Controlador app2 = new Controlador();


            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.SP_Hoy().ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) { }






                
                string mensase = "";

                try
                {
                    using (DbComedor1Entities bd3 = new DbComedor1Entities())
                    {
                        var registro = bd3.SP_Hoy().ToList();

                        foreach (var people in registro)
                        {

                            mensase = people.GetValueOrDefault().ToString();

                        }

                        MessageBox.Show(mensase);


                    }
                }
                catch(Exception ex) { mensase="Error"; }





            }
        }

        private void button20_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            try
            {

                string date = dateTimePicker1.Text;

                string date2 = dateTimePicker2.Text;


                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    dataGridView1.DataSource = bd.SP_consultaAusenciasRangoID2(DateTime.Parse(date), DateTime.Parse(date2)).ToList();
                    dataGridView1.Refresh();


                }



            }
            catch (Exception ex) {; }

            dateTimePicker1.Text="";
            dateTimePicker2.Text="";
        }

        private void button21_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            try
            {

                string date = dateTimePicker1.Text;

                string date2 = dateTimePicker2.Text;


                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    dataGridView1.DataSource = bd.SP_consultafechaasitenciaRangoId2(DateTime.Parse(date), DateTime.Parse(date2)).ToList();
                    dataGridView1.Refresh();


                }



            }
            catch (Exception ex) {; }

            dateTimePicker1.Text="";
            dateTimePicker2.Text="";
        }

        private void button22_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegistroEst v3 = new RegistroEst();
            v3.Show();

        }

        private void regirtrasNuevoEstudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegistroEst v3 = new RegistroEst();
            v3.Show();
        }

        private void pasarAsistenciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void consultasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void pasarAsistenciaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
        }

        private void consultasToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void regirtrasNuevoEstudianteToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void regirtrarNuevoEstudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegistroEst v3 = new RegistroEst();
            v3.Show();
        }
    }
}
