﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class ActualizarUsuario : Form
    {
        public ActualizarUsuario()
        {
            InitializeComponent();
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegisroUsr v3 = new RegisroUsr();
            v3.Show();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrearUsuario v3 = new CrearUsuario();
            v3.Show();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrearUsuarioAdmin v3 = new CrearUsuarioAdmin();
            v3.Show();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarUsuarios v3 = new ConsultarUsuarios();
            v3.Show();
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            this.Hide();
            EliminarUsuario v3 = new EliminarUsuario();
            v3.Show();
        }

        private void regresarAlInicioDeSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            principal v3 = new principal();
            v3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.loginicios.ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) {; }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text!= string.Empty && textBox2.Text!= string.Empty && textBox3.Text!= string.Empty)
            {

                int usuario = 0;
                string num = "";
                int numero = 0;


                try
                {
                    string usuari = textBox3.Text;
                    usuario = Convert.ToInt32(usuari);
                }
                catch(Exception ex)
                {
                    MessageBox.Show("No ingreso un valor numérico en el ID");
                }
               
                



                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    try
                    {
                        var registro = bd.SP_confirmarUsrID2(usuario).ToList();

                        foreach (var people in registro)
                        {

                            numero = people.GetValueOrDefault();

                            //num = people.ToString();

                        }
                        //numero = Convert.ToInt32(Convert.ToString(num));

                      

                        if (numero >0)
                        {
                            //AQYUUU
                            try
                            {

                                Controlador app2 = new Controlador();
                                MessageBox.Show(app2.ActualizarUsuario(int.Parse(textBox3.Text), textBox1.Text, textBox2.Text, 2).ToString());

                            }
                            catch (Exception ex) { MessageBox.Show("Error al actulizar datos."); }

                          
                        }
                        else
                        {
                            MessageBox.Show("El usuario no existe.");

                        }
                    }
                    catch (Exception ex) {; }
                }


//AA


               
            }

            //ZZ
            else
            {
                MessageBox.Show("Error al actualizar usuario.  No pueden quedar campos vacíos.");
            }

            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
        }

        private void confiToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void nombreDeColegioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            upNombreColegio v3 = new upNombreColegio();
            v3.Show();
        }

        private void ActualizarUsuario_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
