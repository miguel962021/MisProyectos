﻿namespace AplicacionComedor
{
    partial class upNombreColegio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.principalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crearUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crearUsuarioToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.usuarioComunToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usuarioAdministradorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.actualizarUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regresarAlInicioDeSessionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuracionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nombreDeColegioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelMensaje = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.DarkBlue;
            this.label9.Location = new System.Drawing.Point(246, 288);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 31);
            this.label9.TabIndex = 171;
            this.label9.Text = "Nombre";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei", 21.75F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.DarkBlue;
            this.label7.Location = new System.Drawing.Point(191, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(442, 39);
            this.label7.TabIndex = 170;
            this.label7.Text = "Registrar nombre del colegio";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button5.BackgroundImage = global::AplicacionComedor.Properties.Resources.WhatsApp_Image_2022_08_12_at_5_484;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Image = global::AplicacionComedor.Properties.Resources.crear;
            this.button5.Location = new System.Drawing.Point(417, 344);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 56);
            this.button5.TabIndex = 169;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.textBox1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(392, 298);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 165;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.principalToolStripMenuItem,
            this.crearUsuarioToolStripMenuItem,
            this.regresarAlInicioDeSessionToolStripMenuItem,
            this.configuracionesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 173;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // principalToolStripMenuItem
            // 
            this.principalToolStripMenuItem.Name = "principalToolStripMenuItem";
            this.principalToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.principalToolStripMenuItem.Text = "Principal";
            this.principalToolStripMenuItem.Click += new System.EventHandler(this.principalToolStripMenuItem_Click);
            // 
            // crearUsuarioToolStripMenuItem
            // 
            this.crearUsuarioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.crearUsuarioToolStripMenuItem1,
            this.consultarUsuariosToolStripMenuItem,
            this.actualizarUsuarioToolStripMenuItem,
            this.eliminarUsuarioToolStripMenuItem});
            this.crearUsuarioToolStripMenuItem.Name = "crearUsuarioToolStripMenuItem";
            this.crearUsuarioToolStripMenuItem.Size = new System.Drawing.Size(80, 24);
            this.crearUsuarioToolStripMenuItem.Text = "Registro";
            // 
            // crearUsuarioToolStripMenuItem1
            // 
            this.crearUsuarioToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usuarioComunToolStripMenuItem,
            this.usuarioAdministradorToolStripMenuItem});
            this.crearUsuarioToolStripMenuItem1.Name = "crearUsuarioToolStripMenuItem1";
            this.crearUsuarioToolStripMenuItem1.Size = new System.Drawing.Size(206, 24);
            this.crearUsuarioToolStripMenuItem1.Text = "Crear Usuario";
            // 
            // usuarioComunToolStripMenuItem
            // 
            this.usuarioComunToolStripMenuItem.Name = "usuarioComunToolStripMenuItem";
            this.usuarioComunToolStripMenuItem.Size = new System.Drawing.Size(235, 24);
            this.usuarioComunToolStripMenuItem.Text = "Usuario Comun";
            this.usuarioComunToolStripMenuItem.Click += new System.EventHandler(this.usuarioComunToolStripMenuItem_Click);
            // 
            // usuarioAdministradorToolStripMenuItem
            // 
            this.usuarioAdministradorToolStripMenuItem.Name = "usuarioAdministradorToolStripMenuItem";
            this.usuarioAdministradorToolStripMenuItem.Size = new System.Drawing.Size(235, 24);
            this.usuarioAdministradorToolStripMenuItem.Text = "Usuario administrador";
            this.usuarioAdministradorToolStripMenuItem.Click += new System.EventHandler(this.usuarioAdministradorToolStripMenuItem_Click);
            // 
            // consultarUsuariosToolStripMenuItem
            // 
            this.consultarUsuariosToolStripMenuItem.Name = "consultarUsuariosToolStripMenuItem";
            this.consultarUsuariosToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.consultarUsuariosToolStripMenuItem.Text = "Consultar Usuario";
            this.consultarUsuariosToolStripMenuItem.Click += new System.EventHandler(this.consultarUsuariosToolStripMenuItem_Click);
            // 
            // actualizarUsuarioToolStripMenuItem
            // 
            this.actualizarUsuarioToolStripMenuItem.Name = "actualizarUsuarioToolStripMenuItem";
            this.actualizarUsuarioToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.actualizarUsuarioToolStripMenuItem.Text = "Actualizar Usuario";
            this.actualizarUsuarioToolStripMenuItem.Click += new System.EventHandler(this.actualizarUsuarioToolStripMenuItem_Click);
            // 
            // eliminarUsuarioToolStripMenuItem
            // 
            this.eliminarUsuarioToolStripMenuItem.Name = "eliminarUsuarioToolStripMenuItem";
            this.eliminarUsuarioToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.eliminarUsuarioToolStripMenuItem.Text = "Eliminar Usuario";
            this.eliminarUsuarioToolStripMenuItem.Click += new System.EventHandler(this.eliminarUsuarioToolStripMenuItem_Click);
            // 
            // regresarAlInicioDeSessionToolStripMenuItem
            // 
            this.regresarAlInicioDeSessionToolStripMenuItem.Name = "regresarAlInicioDeSessionToolStripMenuItem";
            this.regresarAlInicioDeSessionToolStripMenuItem.Size = new System.Drawing.Size(209, 24);
            this.regresarAlInicioDeSessionToolStripMenuItem.Text = "Regresar al inicio de sesión";
            this.regresarAlInicioDeSessionToolStripMenuItem.Click += new System.EventHandler(this.regresarAlInicioDeSessionToolStripMenuItem_Click);
            // 
            // configuracionesToolStripMenuItem
            // 
            this.configuracionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nombreDeColegioToolStripMenuItem});
            this.configuracionesToolStripMenuItem.Name = "configuracionesToolStripMenuItem";
            this.configuracionesToolStripMenuItem.Size = new System.Drawing.Size(134, 24);
            this.configuracionesToolStripMenuItem.Text = "Configuraciones";
            // 
            // nombreDeColegioToolStripMenuItem
            // 
            this.nombreDeColegioToolStripMenuItem.Name = "nombreDeColegioToolStripMenuItem";
            this.nombreDeColegioToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.nombreDeColegioToolStripMenuItem.Text = "Nombre de colegio";
            this.nombreDeColegioToolStripMenuItem.Click += new System.EventHandler(this.nombreDeColegioToolStripMenuItem_Click);
            // 
            // labelMensaje
            // 
            this.labelMensaje.AutoSize = true;
            this.labelMensaje.BackColor = System.Drawing.Color.Transparent;
            this.labelMensaje.Font = new System.Drawing.Font("Microsoft YaHei", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMensaje.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelMensaje.Location = new System.Drawing.Point(184, 111);
            this.labelMensaje.Name = "labelMensaje";
            this.labelMensaje.Size = new System.Drawing.Size(31, 39);
            this.labelMensaje.TabIndex = 196;
            this.labelMensaje.Text = "*";
            // 
            // upNombreColegio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AplicacionComedor.Properties.Resources.WhatsApp_Image_2022_08_12_at_5_484;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelMensaje);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.textBox1);
            this.Name = "upNombreColegio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Sistema de comedor";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.upNombreColegio_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem principalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crearUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crearUsuarioToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem usuarioComunToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuarioAdministradorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem actualizarUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminarUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regresarAlInicioDeSessionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuracionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nombreDeColegioToolStripMenuItem;
        private System.Windows.Forms.Label labelMensaje;
    }
}