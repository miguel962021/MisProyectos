﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class ActualizarEst : Form
    {
        public ActualizarEst()
        {
            InitializeComponent();
            listBox1.Visible = false;
            labelIDr.Visible = false;
            labelnombr.Visible = false;
            labelapellido1.Visible=false;
            labelapellido2.Visible=false;
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void PasarAsistenciasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {


            this.Hide();
            VentanaPrincipal v3 = new VentanaPrincipal();
            v3.Show();
        }

        private void porFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            rangoasistencias2 v3 = new rangoasistencias2();
            v3.Show();

        }

        private void porFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Inasistencias v3 = new Inasistencias();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            RangoInAsistencias v3 = new RangoInAsistencias();
            v3.Show();
        }

        private void totalDePlatosEsperadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void consultarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarEst v3 = new ConsultarEst();
            v3.Show();
        }

        private void agregarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AgregarEst v3 = new AgregarEst();
            v3.Show();
        }

        private void eliminarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EliminarEst v3 = new EliminarEst();
            v3.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string idR = textBox1.Text;
                string apellido1R = textBox2.Text;
                string apellido2R = textBox3.Text;
                string nombreR = textBox4.Text;

                if (idR == string.Empty)
                {
                  
                    if (idR== string.Empty)
                    {
                        //MessageBox.Show(resultado.Value);
                        // labelapellido2.Text=("*");
                        labelIDr.Visible=true;
                    }
                    else
                    {
                        labelIDr.Visible = false;
                    }


                    //MessageBox.Show(resultado.Value);

                    //MessageBox.Show(resultado.Value);
                    MessageBox.Show("¡No puede dejar espacios en blanco en este campo!");


                  


                }
                else
                {
                    labelIDr.Visible = false;
                    labelnombr.Visible = false;
                    labelapellido1.Visible=false;
                    labelapellido2.Visible=false;
                   // MessageBox.Show("True");





                    //aa


                    string id = "0";
                    string nombre = "";
                    string apellido1 = "";
                    string apellido2 = "";


                    using (DbComedor1Entities bd = new DbComedor1Entities())
                    {




                        try
                        {
                            if (textBox1.Text!= string.Empty)
                            {
                                var registro = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();


                                if (registro == null)
                                {
                                    MessageBox.Show("El estudiante no está registrado.");
                                }
                                else
                                {


                                    foreach (var people in registro)
                                    {

                                        id = people.Carnet.ToString();
                                        nombre = people.Nombre.ToString();
                                        apellido1 = people.Apellido1.ToString();
                                        apellido2 = people.Apellido2.ToString();

                                    }


                                }

                            }

                        }
                        catch (Exception ex) {; }

                    }




                    try
                    {
                        int idH = 0;
                        string nombreH = "";
                        string apellido1H = "";
                        string apellido2H = "";



                        if (textBox2.Text == String.Empty)
                        {
                            apellido1H=apellido1;
                        }
                        else
                        {
                            apellido1H=textBox2.Text;
                        }





                        if (textBox3.Text == String.Empty)
                        {
                            apellido2H=apellido2;
                        }
                        else
                        {
                            apellido2H=textBox3.Text;
                        }




                        if (textBox4.Text == String.Empty)
                        {
                            nombreH=nombre;
                        }
                        else
                        {
                            nombreH=textBox4.Text;
                        }

                        idH = Convert.ToInt32(id);


                        if (idH == 0)
                        {
                            MessageBox.Show("Error al actualizar estudiante.");
                        }
                        else
                        {
                            Controlador app2 = new Controlador();
                            MessageBox.Show(app2.Actualizaralumno(int.Parse(textBox1.Text), apellido1H.ToUpper(), apellido2H.ToUpper(), nombreH.ToUpper(), 0).ToString());


                            textBox1.Text="";
                            textBox2.Text="";
                            textBox3.Text="";
                            textBox4.Text="";
                        }


                    }
                    catch (Exception ex) 
                    {
                        MessageBox.Show("Error al actulizar datos.");
                        textBox1.Text="";
                    }

                    //zz


                }

                // MessageBox.Show(resultado.Value);

            }
            catch (Exception ex) { MessageBox.Show("Error al cargar datos"); }



           
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            if (textBox1.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    try
                    {
                        dataGridView1.DataSource = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();

                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }


                }
            }
            else if (textBox2.Text!= string.Empty && textBox3.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    try
                    {
                        dataGridView1.DataSource = bd.SP_consultaApellidos3R(textBox2.Text.ToUpper(), textBox3.Text.ToUpper()).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consultaApellidos3R(textBox2.Text, textBox3.Text).ToList();


                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado o ingreso mal los valores.");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }

                }

            }
            else
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    try
                    {
                        dataGridView1.DataSource = bd.SP_todoest33R().ToList();
                        dataGridView1.Refresh();

                        //  dataGridView1.DataSource = bd.estudiantes.ToList();
                        //dataGridView1.Refresh();
                    }
                    catch (Exception ex) {; }
                }
            }


            //textBox1.Text="";
            //textBox2.Text="";
            //textBox3.Text="";
           // textBox4.Text="";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ActualizarEst_Load(object sender, EventArgs e)
        {
            listBox1.Visible = false;
        }

        private void actulizarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string apellido1R = textBox2.Text;
                string apellido2R = textBox3.Text;
                string nombreR = textBox4.Text;

                Match rnOMBRE = Regex.Match(nombreR, @"[ \d ] *");
                Match rApellido1 = Regex.Match(apellido1R, @"[ \d ] *");
                Match rApellido2 = Regex.Match(apellido2R, @"[ \d] *");

                if (rnOMBRE.Success == true || rApellido1.Success == true || rApellido2.Success == true)
                {

                    if (rnOMBRE.Success == true)
                    {
                        //MessageBox.Show(resultado.Value);
                        //labelnombr.Text=("¡No se puede ingresar números en este campo!");
                        labelnombr.Visible=true;
                    }
                    else
                    {
                        labelnombr.Visible = false;
                    }
                    if (rApellido1.Success == true)
                    {
                        //MessageBox.Show(resultado.Value);
                        //  labelapellido1.Text=("¡No se puede ingresar números en este campo!");
                        labelapellido1.Visible=true;
                    }
                    else
                    {
                        labelapellido1.Visible = false;
                    }
                    if (rApellido2.Success == true)
                    {
                        //MessageBox.Show(resultado.Value);
                        // labelapellido2.Text=("*");
                        labelapellido2.Visible=true;
                    }
                    else
                    {
                        labelapellido2.Visible = false;
                    }
                    //MessageBox.Show(resultado.Value);
                    MessageBox.Show("¡No puede ingresar números ni dejar espacios en blanco en este campo!");

                }
                else
                {
                    labelnombr.Visible = false;
                    labelapellido1.Visible=false;
                    labelapellido2.Visible=false;
                    // MessageBox.Show("True");





                    //aa


                    string id = "0";
                    string nombre = "";
                    string apellido1 = "";
                    string apellido2 = "";


                    using (DbComedor1Entities bd = new DbComedor1Entities())
                    {




                        try
                        {
                            if (textBox1.Text!= string.Empty)
                            {
                                var registro = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();


                                if (registro == null)
                                {
                                    MessageBox.Show("El estudiante no está registrado.");
                                }
                                else
                                {


                                    foreach (var people in registro)
                                    {

                                        id = people.Carnet.ToString();
                                        nombre = people.Nombre.ToString();
                                        apellido1 = people.Apellido1.ToString();
                                        apellido2 = people.Apellido2.ToString();

                                    }


                                }

                            }

                        }
                        catch (Exception ex) {; }

                    }




                    try
                    {
                        int idH = 0;
                        string nombreH = "";
                        string apellido1H = "";
                        string apellido2H = "";



                        if (textBox2.Text == String.Empty)
                        {
                            apellido1H=apellido1;
                        }
                        else
                        {
                            apellido1H=textBox2.Text;
                        }





                        if (textBox3.Text == String.Empty)
                        {
                            apellido2H=apellido2;
                        }
                        else
                        {
                            apellido2H=textBox3.Text;
                        }




                        if (textBox4.Text == String.Empty)
                        {
                            nombreH=nombre;
                        }
                        else
                        {
                            nombreH=textBox4.Text;
                        }

                        idH = Convert.ToInt32(id);


                        if (idH == 0)
                        {
                            MessageBox.Show("Error al actualizar estudiante.");
                        }
                        else
                        {
                            Controlador app2 = new Controlador();
                            MessageBox.Show(app2.Actualizaralumno(int.Parse(textBox1.Text), apellido1H.ToUpper(), apellido2H.ToUpper(), nombreH.ToUpper(), 0).ToString());


                            textBox1.Text="";
                            textBox2.Text="";
                            textBox3.Text="";
                            textBox4.Text="";
                        }


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al actulizar datos.");
                        textBox1.Text="";
                    }

                    //zz


                }

                // MessageBox.Show(resultado.Value);

            }
            catch (Exception ex) { MessageBox.Show("Error al cargar datos"); }


        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo letras y espacios en blanco
            if ((e.KeyChar >=33  && e.KeyChar <=64) || (e.KeyChar>=91 && e.KeyChar<=96)|| (e.KeyChar>=123 && e.KeyChar<=255))

            {
                MessageBox.Show("¡No se puede ingresar números en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo letras y espacios en blanco
            if ((e.KeyChar >=33  && e.KeyChar <=64) || (e.KeyChar>=91 && e.KeyChar<=96)|| (e.KeyChar>=123 && e.KeyChar<=255))

            {
                MessageBox.Show("¡No se puede ingresar números en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo letras y espacios en blanco
            if ((e.KeyChar >=33  && e.KeyChar <=64) || (e.KeyChar>=91 && e.KeyChar<=96)|| (e.KeyChar>=123 && e.KeyChar<=255))

            {
                MessageBox.Show("¡No se puede ingresar números en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo numeros
            if ((e.KeyChar >=32  && e.KeyChar <=47) || (e.KeyChar>=58 && e.KeyChar<=255))
            {
                MessageBox.Show("¡No se puede ingresar letras en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }
    }
}
