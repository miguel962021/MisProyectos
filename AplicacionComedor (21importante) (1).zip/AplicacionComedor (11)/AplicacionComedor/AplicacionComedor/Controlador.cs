﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Linq;

namespace AplicacionComedor
{
    internal class Controlador
    {


        public Boolean insertarAlumno(int id, string apellido1, string apellido2, string nombre, int bit)
        {

            try
            {

                using (var contexto = new DbComedor1Entities())
                {

                    var nuevo_cambio = new estudiante()
                    {
                        id = id,
                        apellido1 = apellido1,
                        apellido2 = apellido2,
                        nombre = nombre,
                        asistenciabit= bit

                    };

                    contexto.estudiantes.Add(nuevo_cambio);
                    contexto.SaveChanges();

                };

                return true;
            }
            catch (Exception e)
            {
                return false;
            }

        }



        public Boolean Actualizaralumno(int id, string apellido1, string apellido2, string nombre, int bit)
        {
          try
            {
                using (var contexto = new DbComedor1Entities())
                {
                    var registro = contexto.estudiantes.Find(id);
                    {
                        registro.apellido1 = apellido1;
                        registro.apellido2 = apellido2;
                        registro.nombre= nombre;
                        registro.asistenciabit= bit;
                        contexto.SaveChanges();
                    };
                    return true;
                };


            }
            catch (Exception e)
            {
                return false;
            }

        }




        public Boolean Eliminaralumno(int id)
        {

            try
            {

                using (var contexto = new DbComedor1Entities())
                {

                    var registro = contexto.estudiantes.Find(id);
                    contexto.estudiantes.Remove(registro);
                    contexto.SaveChanges();

                };


                return true;

            }
            catch (Exception e)
            {
                return false;
            }

        }













        //asistencia al comedor
        public Boolean asistencia(int idcarnet, DateTime date, int asistenciabit)
        {
            try
            {
                using (var contexto = new DbComedor1Entities())
                {
                    var nuevo_cambio = new asistencia()
                    {
                        idcarnet = idcarnet,
                        fecha =  date,
                        asistenciabit = asistenciabit
                    };
                    
                    contexto.asistencias.Add(nuevo_cambio);
                    contexto.SaveChanges();

                };

                return true;
            }
            catch (Exception e)
            {
                return false;
            }

        }


        

        public Boolean asistencia2(int idcarnet)
        {
            try
            {
                using (var contexto = new DbComedor1Entities())
                {
                    var registro = contexto.asistencias.Find(idcarnet);
                    {
                        registro.asistenciabit= 2;
                        contexto.SaveChanges();
                    };
                    return true;
                };


            }
            catch (Exception e)
            {
                return false;
            }

        }


        


        public Boolean ActualizaralumnoAsistencia(int id)
        {

            try
            {


                using (var contexto = new DbComedor1Entities())
                {

                    var registro = contexto.estudiantes.Find(id);
                    {
                        if (registro==null)
                        {
                            return false;
                        }
                        else {
                            registro.asistenciabit= 1;
                            contexto.SaveChanges();


                        }



                    };
                    return true;
                };


            }
            catch (Exception e)
            {
                return false;
            }

        }



        public Boolean reiniciaeAsistencia()
        {
      
            try
            {
               
                using (var contexto = new DbComedor1Entities())
                {
                    estudiante c = (from x in contexto.estudiantes
                                    where x.asistenciabit == 1
                                    select x).Last();
                    c.asistenciabit = 0;
                    contexto.SaveChanges();

                }

    

                return true;

            }
            catch (Exception e)
            {
                return false;
            }

        }


        public Boolean reiniciaeAsistencia1()
        {

            try
            {

                using (var contexto = new DbComedor1Entities())
                {
                    var registro = contexto.estudiantes;

                    foreach(var people in registro)
                    {
                        people.asistenciabit=0;
                    }
                    contexto.SaveChanges();
                
                }


                return true;

            }
            catch (Exception e)
            {
                return false;
            }

        }




        public Boolean ausentes(int idcarnet, DateTime date, int asistenciabit)
        {

            try
            {

                using (var contexto = new DbComedor1Entities())
                {


                    var nuevo_cambio = new asistencia()
                    {


                        idcarnet = idcarnet,
                        fecha =  date,
                        asistenciabit = asistenciabit


                    };

                    contexto.asistencias.Add(nuevo_cambio);
                    contexto.SaveChanges();

                };

                return true;
            }
            catch (Exception e)
            {
                return false;
            }

        }




        public Boolean verificarAusencia(int id)
        {
            try
            {

                int n = 0;
                using (var contexto = new DbComedor1Entities())
                {
                    var registro = (from x in contexto.estudiantes
                                    where x.asistenciabit == 0 && x.id == id
                                    select x).First();

                    if (registro != null)
                    {
                        n=1;
                    }
                }

                if (n==1) { return true; } else { return false; }

                //return true;

            }
            catch (Exception e)
            {
                return false;
            }

        }



      




        public List<asistencia> ausenciasFecha(DateTime date)
        {
            try {
                using (var contexto = new DbComedor1Entities())
                {

                
                    return contexto.asistencias.Where(x => x.asistenciabit == 0 && x.fecha==date).ToList();

                }

            }
            
            catch (Exception e) {
            /*    using (var contexto3 = new DbComedor1Entities())
                {

                    return contexto3.asistencias.ToList();
            */
                }
            
            
                return null;
        }




        public List<asistencia> ausenciasFecha2(DateTime date)
        {
            try
            {

                using (var contexto = new DbComedor1Entities())
                {
                    var registro = (from x in contexto.asistencias
                                    where x.asistenciabit == 0 && x.fecha ==date 
                                    select x ).ToList();
                    return registro;
                 
                }



            }
            catch (Exception e)
            {
                return null;
            }
        }


        //no se usa





        /*
         
         
         create proc SP_consultaAsistencia3
@ID as int,
@FECHA as date
As
select A.asistenciabit, A.idcarnet, E.apellido1,E.apellido2,E.nombre
from asistencia A
join estudiante E on E.id = A.idcarnet
where A.fecha = @FECHA and E.id=@ID and a.asistenciabit=0;

exec SP_consultaAsistencia3 4,'2022-07-16';
         
         
         
         */




        


        public Boolean insertarusuario(int id, string usuario, string contraseña, int bitpar)
        {

            try
            {

                using (var contexto = new DbComedor1Entities())
                {

                    var nuevo_cambio = new loginicio()
                    {
                        id = id,
                        usuario = usuario,
                        contraseña = contraseña,
                        bitpar = bitpar,
                      

                    };

                    contexto.loginicios.Add(nuevo_cambio);
                    contexto.SaveChanges();

                };

                return true;
            }
            catch (Exception e)
            {
                return false;
            }

        }



        public Boolean ActualizarUsuario(int id, string usuario, string contraseña, int bitpar)
        {
            try
            {
                using (var contexto = new DbComedor1Entities())
                {
                    var registro = contexto.loginicios.Find(id);
                    {
                        registro.usuario = usuario;
                        registro.contraseña = contraseña;
                        registro.bitpar= bitpar;
           
                        contexto.SaveChanges();
                    };
                    return true;
                };


            }
            catch (Exception e)
            {
                return false;
            }

        }




        public Boolean EliminarUsuario(int id)
        {

            try
            {

                using (var contexto = new DbComedor1Entities())
                {

                    var registro = contexto.loginicios.Find(id);
                    contexto.loginicios.Remove(registro);
                    contexto.SaveChanges();

                };


                return true;

            }
            catch (Exception e)
            {
                return false;
            }

        }





        public Boolean ActualizarnombreColegio(int id, string nombre)
        {
            try
            {
                using (var contexto = new DbComedor1Entities())
                {
                    var registro = contexto.Colegios.Find(id);
                    {
                       
                        registro.nombre= nombre;
                        contexto.SaveChanges();
                    };
                    return true;
                };


            }
            catch (Exception e)
            {
                return false;
            }

        }





        public Boolean ActualizarfechaBD(DateTime fecha)
        {

            try
            {


                using (var contexto = new DbComedor1Entities())
                {

                    var registro = contexto.tFechas.Find(1);
                    {

                        registro.fecha= fecha;

                        contexto.SaveChanges();


                    };
                    return true;
                };


            }
            catch (Exception e)
            {
                return false;
            }

        }





    }
}
