﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class registro : Form
    {
        public registro()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (DbComedor1Entities bd = new DbComedor1Entities())
            {
                try
                {
                    dataGridView1.DataSource = bd.loginicios.ToList();
                    dataGridView1.Refresh();
                }
                catch (Exception ex) {; }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text!= string.Empty && textBox2.Text!= string.Empty)
            { 

                //insertarusuario(int id, string usuario, string contraseña, int bitpar)
                try
                {
                    Controlador app2 = new Controlador();
                    MessageBox.Show(app2.insertarusuario(0, textBox1.Text, textBox2.Text, 2).ToString());

                }
                catch (Exception ex) { MessageBox.Show("Error al cargar datos"); }

            }
            else
            {
                MessageBox.Show("Error al agregar usuario nuevo.\n" +
                    "Agrege un usuario y contraseña");
            }

            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text!= string.Empty && textBox2.Text!= string.Empty && textBox3.Text!= string.Empty)
            {
                try
                {

                    Controlador app2 = new Controlador();
                    MessageBox.Show(app2.ActualizarUsuario(int.Parse(textBox3.Text), textBox1.Text, textBox2.Text, 2).ToString());

                }
                catch (Exception ex) { MessageBox.Show("Error al actulizar datos"); }

            }
            else
            {
                MessageBox.Show("Error al Actulizar usuario.\n " +
                    "Es nesesario agregar el id del usuario a actualizar, una nueva contraseña y usuario");
            }

            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Controlador app2 = new Controlador();
                MessageBox.Show(app2.EliminarUsuario(int.Parse(textBox3.Text)).ToString());
                textBox1.Text="";
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error al eliminar estudiante");
            }

            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text!= string.Empty && textBox2.Text!= string.Empty)
            {

                //insertarusuario(int id, string usuario, string contraseña, int bitpar)
                try
                {
                    Controlador app2 = new Controlador();
                    MessageBox.Show(app2.insertarusuario(0, textBox1.Text, textBox2.Text, 1).ToString());

                }
                catch (Exception ex) { MessageBox.Show("Error al cargar datos"); }

            }
            else
            {
                MessageBox.Show("Error al agregar usuario Administrador\n" +
                    "Agrege un usuario y contraseña");
            }
            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
        }

        private void registro_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            principal v3 = new principal();
            v3.Show();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
