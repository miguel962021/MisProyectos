﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class EliminarEst : Form
    {
        public EliminarEst()
        {
            InitializeComponent();
            listBox1.Visible = false;
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            VentanaPrincipal v3 = new VentanaPrincipal();
            v3.Show();
        }

        private void PasarAsistenciasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void porFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            rangoasistencias2 v3 = new rangoasistencias2();
            v3.Show();
        }

        private void porFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Inasistencias v3 = new Inasistencias();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            RangoInAsistencias v3 = new RangoInAsistencias();
            v3.Show();
        }

        private void totalDePlatosEsperadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void consultarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarEst v3 = new ConsultarEst();
            v3.Show();
        }

        private void agregarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AgregarEst v3 = new AgregarEst();
            v3.Show();
        }

        private void actulizarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ActualizarEst v3 = new ActualizarEst();
            v3.Show();
        }

        private void EliminarEst_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Controlador app2 = new Controlador();
                MessageBox.Show(app2.Eliminaralumno(int.Parse(textBox1.Text)).ToString());
                textBox1.Text="";
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error al eliminar estudiante.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            if (textBox1.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    try
                    {
                        dataGridView1.DataSource = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();

                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado.");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }


                }
            }

            else
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    try
                    {
                        dataGridView1.DataSource = bd.SP_todoest33R().ToList();
                        dataGridView1.Refresh();

                        //  dataGridView1.DataSource = bd.estudiantes.ToList();
                        //dataGridView1.Refresh();
                    }
                    catch (Exception ex) {; }
                }
            }



            //textBox1.Text="";
         
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo numeros
            if ((e.KeyChar >=32  && e.KeyChar <=47) || (e.KeyChar>=58 && e.KeyChar<=255))
            {
                MessageBox.Show("¡No se puede ingresar letras en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }
    }
}
