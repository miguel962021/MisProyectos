﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class RegisroUsr : Form
    {
        public RegisroUsr()
        {
            InitializeComponent();
        }

        private void usuarioComunToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrearUsuario v3 = new CrearUsuario();
            v3.Show();
        }

        private void usuarioAdministradorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrearUsuarioAdmin v3 = new CrearUsuarioAdmin();
            v3.Show();
        }

        private void consultarUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            ConsultarUsuarios v3 = new ConsultarUsuarios();
            v3.Show();
        }

        private void actualizarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            ActualizarUsuario v3 = new ActualizarUsuario();
            v3.Show();

        }

        private void eliminarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EliminarUsuario v3 = new EliminarUsuario();
            v3.Show();
        }

        private void regresarAlInicioDeSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            principal v3 = new principal();
            v3.Show();
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void nombreDeColegioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            upNombreColegio v3 = new upNombreColegio();
            v3.Show();
        }

        private void configuracionesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
