﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;


namespace AplicacionComedor
{
    public partial class AgregarEst : Form
    {
        public AgregarEst()
        {
            InitializeComponent();
            listBox1.Visible = false;
            labelIDr.Visible = false;
            labelnombr.Visible = false;
            labelapellido1.Visible=false;
            labelapellido2.Visible=false;
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            VentanaPrincipal v3 = new VentanaPrincipal();
            v3.Show();
        }

        private void PasarAsistenciasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void porFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            rangoasistencias2 v3 = new rangoasistencias2();
            v3.Show();
        }

        private void porFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Inasistencias v3 = new Inasistencias();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            RangoInAsistencias v3 = new RangoInAsistencias();
            v3.Show();
        }

        private void totalDePlatosEsperadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void consultasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            if (textBox1.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    try
                    {
                        dataGridView1.DataSource = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consultaR(int.Parse(textBox1.Text)).ToList();

                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado.");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }


                }
            }
            else if (textBox2.Text!= string.Empty && textBox3.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    try
                    {
                        dataGridView1.DataSource = bd.SP_consultaApellidos3R(textBox2.Text.ToUpper(), textBox3.Text.ToUpper()).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consultaApellidos3R(textBox2.Text, textBox3.Text).ToList();


                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado o ingreso mal los valores.");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }

                }

            }
            else
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    try
                    {
                        dataGridView1.DataSource = bd.SP_todoest33R().ToList();
                        dataGridView1.Refresh();

                       
                        

                        //  dataGridView1.DataSource = bd.estudiantes.ToList();
                        //dataGridView1.Refresh();
                    }
                    catch (Exception ex) {; }
                }
            }


            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
            textBox4.Text="";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string apellido1 = textBox2.Text;
                string apellido2 = textBox3.Text;
                string nombre = textBox4.Text;
               
                Match rnOMBRE = Regex.Match(nombre, @"[ \d ] *");
                Match rApellido1 = Regex.Match(apellido1, @"[ \d ] *");
                Match rApellido2 = Regex.Match(apellido2, @"[ \d ] *");

                if (rnOMBRE.Success == true || rApellido1.Success == true || rApellido2.Success == true)
                {

                    if (rnOMBRE.Success == true )
                    {
                        //MessageBox.Show(resultado.Value);
                        //labelnombr.Text=("¡No se puede ingresar números en este campo!");
                        labelnombr.Visible=true;
                    }
                    else
                    {
                        labelnombr.Visible=false;
                    }
                    if ( rApellido1.Success == true )
                    {
                        //MessageBox.Show(resultado.Value);
                      //  labelapellido1.Text=("¡No se puede ingresar números en este campo!");
                        labelapellido1.Visible=true;
                    }
                    else
                    {
                        labelapellido1.Visible=false;
                    }
                    if ( rApellido2.Success == true)
                    {
                        //MessageBox.Show(resultado.Value);
                       // labelapellido2.Text=("*");
                        labelapellido2.Visible=true;
                    }
                    else
                    {
                        labelapellido2.Visible = false;
                    }


                    //MessageBox.Show(resultado.Value);
                      MessageBox.Show("¡No puede ingresar números ni dejar espacios en blanco en este campo!");

                }
                else
                {
                    //  MessageBox.Show("True");
                    labelnombr.Visible = false;
                    labelapellido1.Visible=false;
                    labelapellido2.Visible=false;

                    Controlador app2 = new Controlador();
                    MessageBox.Show(app2.insertarAlumno(int.Parse(textBox1.Text), textBox2.Text.ToUpper(), textBox3.Text.ToUpper(), textBox4.Text.ToUpper(), 0).ToString());




                    textBox1.Text="";
                    textBox2.Text="";
                    textBox3.Text="";
                    textBox4.Text="";
                }

                // MessageBox.Show(resultado.Value);

            }
            catch (Exception ex) 
            { 
                MessageBox.Show("Error al cargar datos.");
                textBox1.Text="";
            }

            
        }

        private void consultarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarEst v3 = new ConsultarEst();
            v3.Show();
        }

        private void actulizarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            ActualizarEst v3 = new ActualizarEst();
            v3.Show();
        }

        private void eliminarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            EliminarEst v3 = new EliminarEst();
            v3.Show();
        }

        private void AgregarEst_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo numeros
            if ((e.KeyChar >=32  && e.KeyChar <=47) || (e.KeyChar>=58 && e.KeyChar<=255))
            {
                MessageBox.Show("¡No se puede ingresar letras en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo letras y espacios en blanco
            if ((e.KeyChar >=33  && e.KeyChar <=64) || (e.KeyChar>=91 && e.KeyChar<=96)|| (e.KeyChar>=123 && e.KeyChar<=255))
           
            {
                MessageBox.Show("¡No se puede ingresar números en este campo!","Alerta",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string idR = textBox1.Text;
                string apellido1 = textBox2.Text;
                string apellido2 = textBox3.Text;
                string nombre = textBox4.Text;

        

                if (nombre== string.Empty || apellido1== string.Empty || apellido2== string.Empty || idR== string.Empty)
                {

                    if (nombre== string.Empty)
                    {
                        //MessageBox.Show(resultado.Value);
                        //labelnombr.Text=("¡No se puede ingresar números en este campo!");
                        labelnombr.Visible=true;
                    }
                    else
                    {
                        labelnombr.Visible=false;
                    }
                    if  (apellido1== string.Empty)
                    {
                        //MessageBox.Show(resultado.Value);
                        //  labelapellido1.Text=("¡No se puede ingresar números en este campo!");
                        labelapellido1.Visible=true;
                    }
                    else
                    {
                        labelapellido1.Visible=false;
                    }
                    if (apellido2== string.Empty)
                    {
                        //MessageBox.Show(resultado.Value);
                        // labelapellido2.Text=("*");
                        labelapellido2.Visible=true;
                    }
                    else
                    {
                        labelapellido2.Visible = false;
                    }
                    if (idR== string.Empty)
                    {
                        //MessageBox.Show(resultado.Value);
                        // labelapellido2.Text=("*");
                        labelIDr.Visible=true;
                    }
                    else
                    {
                        labelIDr.Visible = false;
                    }


                    //MessageBox.Show(resultado.Value);
                    MessageBox.Show("¡No puede dejar espacios en blanco en este campo!");

                }
                else
                {
                    //  MessageBox.Show("True");
                    labelIDr.Visible = false;
                    labelnombr.Visible = false;
                    labelapellido1.Visible=false;
                    labelapellido2.Visible=false;

                    Controlador app2 = new Controlador();
                    MessageBox.Show(app2.insertarAlumno(int.Parse(textBox1.Text), textBox2.Text.ToUpper(), textBox3.Text.ToUpper(), textBox4.Text.ToUpper(), 0).ToString());




                    textBox1.Text="";
                    textBox2.Text="";
                    textBox3.Text="";
                    textBox4.Text="";
                }

                // MessageBox.Show(resultado.Value);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos.");
                textBox1.Text="";
            }

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo letras y espacios en blanco
            if ((e.KeyChar >=33  && e.KeyChar <=64) || (e.KeyChar>=91 && e.KeyChar<=96)|| (e.KeyChar>=123 && e.KeyChar<=255))

            {
                MessageBox.Show("¡No se puede ingresar números en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            //solo letras y espacios en blanco
            if ((e.KeyChar >=33  && e.KeyChar <=64) || (e.KeyChar>=91 && e.KeyChar<=96)|| (e.KeyChar>=123 && e.KeyChar<=255))

            {
                MessageBox.Show("¡No se puede ingresar números en este campo!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }
    }
}
