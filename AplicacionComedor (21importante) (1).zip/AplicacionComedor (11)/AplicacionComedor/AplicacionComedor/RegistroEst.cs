﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class RegistroEst : Form
    {
        public RegistroEst()
        {
            InitializeComponent();
            listBox1.Visible = false;
        }

        private void RegistroEst_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                Controlador app2 = new Controlador();
                MessageBox.Show(app2.insertarAlumno(int.Parse(textBox1.Text), textBox2.Text.ToUpper(), textBox3.Text.ToUpper(), textBox4.Text.ToUpper(), 0).ToString());

            }
            catch (Exception ex) { MessageBox.Show("Error al cargar datos"); }

            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
            textBox4.Text="";
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            Controlador app2 = new Controlador();


            if (textBox1.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    try
                    {
                        dataGridView1.DataSource = bd.SP_consulta(int.Parse(textBox1.Text)).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consulta(int.Parse(textBox1.Text)).ToList();

                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }


                }
            }
            else if (textBox2.Text!= string.Empty && textBox3.Text!= string.Empty)
            {

                using (DbComedor1Entities bd = new DbComedor1Entities())
                {

                    try
                    {
                        dataGridView1.DataSource = bd.SP_consultaApellidos3(textBox2.Text.ToUpper(), textBox3.Text.ToUpper()).ToList();
                        dataGridView1.Refresh();


                        listBox1.DataSource = bd.SP_consultaApellidos3(textBox2.Text, textBox3.Text).ToList();


                        string resultado = (string)listBox1.SelectedItem;

                        if (resultado == null)
                        {
                            MessageBox.Show("El estudiante no está registrado o ingreso mal los valores");
                        }
                        else
                        {
                            MessageBox.Show(resultado);
                        }
                    }
                    catch (Exception ex) {; }

                }

            }
            else
            {
                using (DbComedor1Entities bd = new DbComedor1Entities())
                {
                    try
                    {
                        dataGridView1.DataSource = bd.SP_todoest().ToList();
                        dataGridView1.Refresh();

                        //  dataGridView1.DataSource = bd.estudiantes.ToList();
                        //dataGridView1.Refresh();
                    }
                    catch (Exception ex) {; }
                }
            }


            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
            textBox4.Text="";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                Controlador app2 = new Controlador();
                MessageBox.Show(app2.Actualizaralumno(int.Parse(textBox1.Text), textBox2.Text.ToUpper(), textBox3.Text.ToUpper(), textBox4.Text.ToUpper(), 0).ToString());

            }
            catch (Exception ex) { MessageBox.Show("Error al actulizar datos"); }

            textBox1.Text="";
            textBox2.Text="";
            textBox3.Text="";
            textBox4.Text="";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Controlador app2 = new Controlador();
                MessageBox.Show(app2.Eliminaralumno(int.Parse(textBox1.Text)).ToString());
                textBox1.Text="";
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error al eliminar estudiante");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ExportarDatos(dataGridView1);
        }



        public void ExportarDatos(DataGridView datalistado)
        {

            try
            {

                Microsoft.Office.Interop.Excel.Application exportarexcel = new Microsoft.Office.Interop.Excel.Application();

                exportarexcel.Application.Workbooks.Add(true);

                int idicecolumna = 0;
                foreach (DataGridViewColumn columna in datalistado.Columns)
                {
                    idicecolumna++;

                    exportarexcel.Cells[1, idicecolumna] = columna.Name;

                }

                int indicefila = 0;

                foreach (DataGridViewRow fila in datalistado.Rows)
                {
                    indicefila++;
                    idicecolumna=0;

                    foreach (DataGridViewColumn columna in datalistado.Columns)
                    {
                        idicecolumna++;
                        exportarexcel.Cells[indicefila+1, idicecolumna] = fila.Cells[columna.Name].Value;

                    }
                }

                exportarexcel.Visible=true;

            }
            catch (Exception ex) { MessageBox.Show("algun error"); }
        }

        private void pasarAsistenciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            appComedor v3 = new appComedor();
            v3.Show();
        }

        private void consultasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void regirtrasNuevoEstudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void regirtrarNuevoEstudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
    }
}
