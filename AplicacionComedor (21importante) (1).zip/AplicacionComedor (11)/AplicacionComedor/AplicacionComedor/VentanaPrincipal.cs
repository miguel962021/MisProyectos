﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionComedor
{
    public partial class VentanaPrincipal : Form
    {
        public VentanaPrincipal()
        {
            InitializeComponent();
        }

        private void consultasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void porFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            RangoAsistencias v3 = new RangoAsistencias();
            v3.Show();
            
        }

        private void totalDePlatosEsperadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            PlatosTotal v3 = new PlatosTotal();
            v3.Show();
        }

        private void consultarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarEst v3 = new ConsultarEst();
            v3.Show();
        }

        private void agregarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AgregarEst v3 = new AgregarEst();
            v3.Show();

        }

        private void actulizarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            ActualizarEst v3 = new ActualizarEst();
            v3.Show();
        }

        private void eliminarEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            EliminarEst v3 = new EliminarEst();
            v3.Show();
        }

        private void pasarAsistenciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            VentanaPrincipal v3 = new VentanaPrincipal();
            v3.Show();
            
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void consultasToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void porFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Inasistencias v3 = new Inasistencias();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            RangoInAsistencias v3 = new RangoInAsistencias();
            v3.Show();
        }

        private void regirtroEstudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void PasarAsistenciasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            PasarAsistencia v3 = new PasarAsistencia();
            v3.Show();
        }

        private void porFechaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

            this.Hide();
            Consultas v3 = new Consultas();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            rangoasistencias2 v3 = new rangoasistencias2();
            v3.Show();
        }

        private void porFechaToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Inasistencias v3 = new Inasistencias();
            v3.Show();
        }

        private void porRangoDeFechaToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            RangoInAsistencias v3 = new RangoInAsistencias();
            v3.Show();
        }

        private void totalDePlatosEsperadosToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
           
        }

        private void consultarEstudiantesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            ConsultarEst v3 = new ConsultarEst();
            v3.Show();
        }

        private void agregarEstudiantesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AgregarEst v3 = new AgregarEst();
            v3.Show();
        }

        private void actulizarEstudiantesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

            this.Hide();
            ActualizarEst v3 = new ActualizarEst();
            v3.Show();
        }

        private void eliminarEstudiantesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

            this.Hide();
            EliminarEst v3 = new EliminarEst();
            v3.Show();
        }

        private void VentanaPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void prToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            rangoasistencias2 v3 = new rangoasistencias2();
            v3.Show();
            
        }
    }
}
