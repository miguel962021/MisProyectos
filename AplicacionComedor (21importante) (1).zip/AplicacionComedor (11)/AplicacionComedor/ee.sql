﻿--reinicio
create proc SP_tardia
@ID as int,
@FECHA as date
As
update asistencia
set asistenciabit=2
where id =@ID and fecha= @FECHA;

exec SP_tardia 1,'2022-07-17';


create proc SP_tardia2
@ID as int
As
update asistencia
set asistenciabit=2
where id =@ID ;

exec SP_tardia2 1;