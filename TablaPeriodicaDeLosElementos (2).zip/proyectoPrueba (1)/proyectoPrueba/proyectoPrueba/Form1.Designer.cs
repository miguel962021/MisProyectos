﻿namespace proyectoPrueba
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnCargar = new System.Windows.Forms.Button();
            this.btnHe = new System.Windows.Forms.Button();
            this.btnH = new System.Windows.Forms.Button();
            this.btnLi = new System.Windows.Forms.Button();
            this.btnBe = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnO = new System.Windows.Forms.Button();
            this.btnN = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnNe = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnS = new System.Windows.Forms.Button();
            this.btnP = new System.Windows.Forms.Button();
            this.btnSi = new System.Windows.Forms.Button();
            this.btnAl = new System.Windows.Forms.Button();
            this.btnMg = new System.Windows.Forms.Button();
            this.btnNa = new System.Windows.Forms.Button();
            this.btnSe = new System.Windows.Forms.Button();
            this.btnAs = new System.Windows.Forms.Button();
            this.btnGe = new System.Windows.Forms.Button();
            this.btnGa = new System.Windows.Forms.Button();
            this.btnZn = new System.Windows.Forms.Button();
            this.btnCu = new System.Windows.Forms.Button();
            this.btnNi = new System.Windows.Forms.Button();
            this.btnCo = new System.Windows.Forms.Button();
            this.btnFe = new System.Windows.Forms.Button();
            this.btnMn = new System.Windows.Forms.Button();
            this.btnCr = new System.Windows.Forms.Button();
            this.btnV = new System.Windows.Forms.Button();
            this.btnTi = new System.Windows.Forms.Button();
            this.btnSc = new System.Windows.Forms.Button();
            this.btnCa = new System.Windows.Forms.Button();
            this.btnK = new System.Windows.Forms.Button();
            this.btnTe = new System.Windows.Forms.Button();
            this.btnSb = new System.Windows.Forms.Button();
            this.btnSn = new System.Windows.Forms.Button();
            this.btnIn = new System.Windows.Forms.Button();
            this.btnCd = new System.Windows.Forms.Button();
            this.btnAg = new System.Windows.Forms.Button();
            this.btnPd = new System.Windows.Forms.Button();
            this.btnRh = new System.Windows.Forms.Button();
            this.btnRu = new System.Windows.Forms.Button();
            this.btnTc = new System.Windows.Forms.Button();
            this.btnMo = new System.Windows.Forms.Button();
            this.btnNb = new System.Windows.Forms.Button();
            this.btnZr = new System.Windows.Forms.Button();
            this.btnY = new System.Windows.Forms.Button();
            this.btnSr = new System.Windows.Forms.Button();
            this.btnRb = new System.Windows.Forms.Button();
            this.btnPo = new System.Windows.Forms.Button();
            this.btnBi = new System.Windows.Forms.Button();
            this.btnPb = new System.Windows.Forms.Button();
            this.btnTl = new System.Windows.Forms.Button();
            this.btnHg = new System.Windows.Forms.Button();
            this.btnAu = new System.Windows.Forms.Button();
            this.btnPt = new System.Windows.Forms.Button();
            this.btnIr = new System.Windows.Forms.Button();
            this.btnOs = new System.Windows.Forms.Button();
            this.btnRe = new System.Windows.Forms.Button();
            this.btnW = new System.Windows.Forms.Button();
            this.btnTa = new System.Windows.Forms.Button();
            this.btnHf = new System.Windows.Forms.Button();
            this.btnX0 = new System.Windows.Forms.Button();
            this.btnBa = new System.Windows.Forms.Button();
            this.btnCs = new System.Windows.Forms.Button();
            this.btnLv = new System.Windows.Forms.Button();
            this.btnMc = new System.Windows.Forms.Button();
            this.btnFl = new System.Windows.Forms.Button();
            this.btnNh = new System.Windows.Forms.Button();
            this.btnCn = new System.Windows.Forms.Button();
            this.btnRg = new System.Windows.Forms.Button();
            this.btnDs = new System.Windows.Forms.Button();
            this.btnMt = new System.Windows.Forms.Button();
            this.btnHs = new System.Windows.Forms.Button();
            this.btnBh = new System.Windows.Forms.Button();
            this.btnSg = new System.Windows.Forms.Button();
            this.btnDb = new System.Windows.Forms.Button();
            this.btnRf = new System.Windows.Forms.Button();
            this.btnX1 = new System.Windows.Forms.Button();
            this.btnRa = new System.Windows.Forms.Button();
            this.btnFr = new System.Windows.Forms.Button();
            this.btnOg = new System.Windows.Forms.Button();
            this.btnTs = new System.Windows.Forms.Button();
            this.btnRn = new System.Windows.Forms.Button();
            this.btnAt = new System.Windows.Forms.Button();
            this.btnXe = new System.Windows.Forms.Button();
            this.btnI = new System.Windows.Forms.Button();
            this.btnKr = new System.Windows.Forms.Button();
            this.btnBr = new System.Windows.Forms.Button();
            this.btnAr = new System.Windows.Forms.Button();
            this.btnCl = new System.Windows.Forms.Button();
            this.btnLr = new System.Windows.Forms.Button();
            this.btnNo = new System.Windows.Forms.Button();
            this.btnLu = new System.Windows.Forms.Button();
            this.btnYb = new System.Windows.Forms.Button();
            this.btnMd = new System.Windows.Forms.Button();
            this.btnFm = new System.Windows.Forms.Button();
            this.btnEs = new System.Windows.Forms.Button();
            this.btnCf = new System.Windows.Forms.Button();
            this.btnBk = new System.Windows.Forms.Button();
            this.btnA = new System.Windows.Forms.Button();
            this.btnAm = new System.Windows.Forms.Button();
            this.btnPu = new System.Windows.Forms.Button();
            this.btnNp = new System.Windows.Forms.Button();
            this.btnU = new System.Windows.Forms.Button();
            this.btnPa = new System.Windows.Forms.Button();
            this.btnTh = new System.Windows.Forms.Button();
            this.btnAc = new System.Windows.Forms.Button();
            this.btnTm = new System.Windows.Forms.Button();
            this.btnEr = new System.Windows.Forms.Button();
            this.btnHo = new System.Windows.Forms.Button();
            this.btnDy = new System.Windows.Forms.Button();
            this.btnTb = new System.Windows.Forms.Button();
            this.btnGd = new System.Windows.Forms.Button();
            this.btnEu = new System.Windows.Forms.Button();
            this.btnSm = new System.Windows.Forms.Button();
            this.btnPm = new System.Windows.Forms.Button();
            this.btnNd = new System.Windows.Forms.Button();
            this.btnPr = new System.Windows.Forms.Button();
            this.btnCe = new System.Windows.Forms.Button();
            this.btnLa = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.btnNometales = new System.Windows.Forms.Button();
            this.btnMetaloides = new System.Windows.Forms.Button();
            this.siglaA = new System.Windows.Forms.TextBox();
            this.siglaB = new System.Windows.Forms.TextBox();
            this.valenciaA = new System.Windows.Forms.TextBox();
            this.valenciaB = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.labelResultado = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.Oxidosmetalicos = new System.Windows.Forms.RadioButton();
            this.OxidosNometalicos = new System.Windows.Forms.RadioButton();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.btnPeróxidos = new System.Windows.Forms.RadioButton();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.btnGasesNobles = new System.Windows.Forms.Button();
            this.labelCategoria = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.Ozonidos = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.Hidruros = new System.Windows.Forms.RadioButton();
            this.ValPeroxido = new System.Windows.Forms.TextBox();
            this.gaseosos = new System.Windows.Forms.CheckBox();
            this.acidos = new System.Windows.Forms.CheckBox();
            this.Hidracidos = new System.Windows.Forms.RadioButton();
            this.button5 = new System.Windows.Forms.Button();
            this.Hidroxidos = new System.Windows.Forms.RadioButton();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.Valencia3 = new System.Windows.Forms.TextBox();
            this.Sigla3 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.sigla4 = new System.Windows.Forms.TextBox();
            this.btnTioacidos = new System.Windows.Forms.RadioButton();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.btnSuperOxidos = new System.Windows.Forms.RadioButton();
            this.btnOxacidos = new System.Windows.Forms.RadioButton();
            this.btnSalesNeutras = new System.Windows.Forms.RadioButton();
            this.btnSalesAcidas = new System.Windows.Forms.RadioButton();
            this.btnSalesBasiscas = new System.Windows.Forms.RadioButton();
            this.btnPeroxoacidos = new System.Windows.Forms.RadioButton();
            this.label29 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.valencia4 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 28;
            this.listBox1.Location = new System.Drawing.Point(110, 29);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(28, 4);
            this.listBox1.TabIndex = 1;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // btnCargar
            // 
            this.btnCargar.AccessibleName = "";
            this.btnCargar.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.btnCargar.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.btnCargar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.btnCargar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCargar.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCargar.Location = new System.Drawing.Point(12, 550);
            this.btnCargar.Name = "btnCargar";
            this.btnCargar.Size = new System.Drawing.Size(95, 28);
            this.btnCargar.TabIndex = 2;
            this.btnCargar.Text = "Metales";
            this.btnCargar.UseVisualStyleBackColor = true;
            this.btnCargar.Click += new System.EventHandler(this.btnCargar_Click);
            // 
            // btnHe
            // 
            this.btnHe.BackColor = System.Drawing.Color.SkyBlue;
            this.btnHe.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnHe.ForeColor = System.Drawing.Color.Black;
            this.btnHe.Location = new System.Drawing.Point(1300, 36);
            this.btnHe.Name = "btnHe";
            this.btnHe.Size = new System.Drawing.Size(69, 51);
            this.btnHe.TabIndex = 4;
            this.btnHe.Text = "He";
            this.btnHe.UseVisualStyleBackColor = false;
            this.btnHe.Click += new System.EventHandler(this.btnHe_Click);
            // 
            // btnH
            // 
            this.btnH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnH.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnH.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnH.Location = new System.Drawing.Point(24, 36);
            this.btnH.Margin = new System.Windows.Forms.Padding(1);
            this.btnH.Name = "btnH";
            this.btnH.Size = new System.Drawing.Size(69, 51);
            this.btnH.TabIndex = 5;
            this.btnH.Text = "H";
            this.btnH.UseVisualStyleBackColor = false;
            this.btnH.Click += new System.EventHandler(this.btnH_Click);
            // 
            // btnLi
            // 
            this.btnLi.BackColor = System.Drawing.Color.Gold;
            this.btnLi.Location = new System.Drawing.Point(24, 93);
            this.btnLi.Name = "btnLi";
            this.btnLi.Size = new System.Drawing.Size(69, 51);
            this.btnLi.TabIndex = 6;
            this.btnLi.Text = "Li";
            this.btnLi.UseVisualStyleBackColor = false;
            this.btnLi.Click += new System.EventHandler(this.btnLi_Click);
            // 
            // btnBe
            // 
            this.btnBe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnBe.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBe.Location = new System.Drawing.Point(96, 94);
            this.btnBe.Name = "btnBe";
            this.btnBe.Size = new System.Drawing.Size(69, 51);
            this.btnBe.TabIndex = 7;
            this.btnBe.Text = "Be";
            this.btnBe.UseVisualStyleBackColor = false;
            this.btnBe.Click += new System.EventHandler(this.btnBe_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(74, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "1";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(2, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 19);
            this.label3.TabIndex = 9;
            this.label3.Text = "1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(2, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 19);
            this.label4.TabIndex = 10;
            this.label4.Text = "2";
            // 
            // btnO
            // 
            this.btnO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnO.Location = new System.Drawing.Point(1149, 93);
            this.btnO.Name = "btnO";
            this.btnO.Size = new System.Drawing.Size(69, 51);
            this.btnO.TabIndex = 24;
            this.btnO.Text = "O";
            this.btnO.UseVisualStyleBackColor = false;
            this.btnO.Click += new System.EventHandler(this.btnO_Click);
            // 
            // btnN
            // 
            this.btnN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnN.Location = new System.Drawing.Point(1074, 93);
            this.btnN.Name = "btnN";
            this.btnN.Size = new System.Drawing.Size(69, 51);
            this.btnN.TabIndex = 23;
            this.btnN.Text = "N";
            this.btnN.UseVisualStyleBackColor = false;
            this.btnN.Click += new System.EventHandler(this.btnN_Click);
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnC.Location = new System.Drawing.Point(999, 93);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(69, 51);
            this.btnC.TabIndex = 22;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnB
            // 
            this.btnB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnB.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnB.Location = new System.Drawing.Point(924, 93);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(69, 51);
            this.btnB.TabIndex = 21;
            this.btnB.Text = "B";
            this.btnB.UseVisualStyleBackColor = false;
            this.btnB.Click += new System.EventHandler(this.button10_Click);
            // 
            // btnNe
            // 
            this.btnNe.BackColor = System.Drawing.Color.SkyBlue;
            this.btnNe.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNe.Location = new System.Drawing.Point(1300, 93);
            this.btnNe.Name = "btnNe";
            this.btnNe.Size = new System.Drawing.Size(69, 51);
            this.btnNe.TabIndex = 26;
            this.btnNe.Text = "Ne";
            this.btnNe.UseVisualStyleBackColor = false;
            this.btnNe.Click += new System.EventHandler(this.btnNe_Click);
            // 
            // btnF
            // 
            this.btnF.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnF.Location = new System.Drawing.Point(1224, 93);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(69, 51);
            this.btnF.TabIndex = 25;
            this.btnF.Text = "F";
            this.btnF.UseVisualStyleBackColor = false;
            this.btnF.Click += new System.EventHandler(this.btnF_Click);
            // 
            // btnS
            // 
            this.btnS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnS.Location = new System.Drawing.Point(1149, 150);
            this.btnS.Name = "btnS";
            this.btnS.Size = new System.Drawing.Size(69, 51);
            this.btnS.TabIndex = 42;
            this.btnS.Text = "S";
            this.btnS.UseVisualStyleBackColor = false;
            this.btnS.Click += new System.EventHandler(this.btnS_Click);
            // 
            // btnP
            // 
            this.btnP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnP.Location = new System.Drawing.Point(1074, 150);
            this.btnP.Name = "btnP";
            this.btnP.Size = new System.Drawing.Size(69, 51);
            this.btnP.TabIndex = 41;
            this.btnP.Text = "P";
            this.btnP.UseVisualStyleBackColor = false;
            this.btnP.Click += new System.EventHandler(this.btnP_Click);
            // 
            // btnSi
            // 
            this.btnSi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSi.Location = new System.Drawing.Point(999, 150);
            this.btnSi.Name = "btnSi";
            this.btnSi.Size = new System.Drawing.Size(69, 51);
            this.btnSi.TabIndex = 40;
            this.btnSi.Text = "Si";
            this.btnSi.UseVisualStyleBackColor = false;
            this.btnSi.Click += new System.EventHandler(this.btnSi_Click);
            // 
            // btnAl
            // 
            this.btnAl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAl.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAl.Location = new System.Drawing.Point(924, 150);
            this.btnAl.Name = "btnAl";
            this.btnAl.Size = new System.Drawing.Size(71, 51);
            this.btnAl.TabIndex = 39;
            this.btnAl.Text = "Al";
            this.btnAl.UseVisualStyleBackColor = false;
            this.btnAl.Click += new System.EventHandler(this.btnAl_Click);
            // 
            // btnMg
            // 
            this.btnMg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnMg.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnMg.Location = new System.Drawing.Point(99, 150);
            this.btnMg.Name = "btnMg";
            this.btnMg.Size = new System.Drawing.Size(69, 51);
            this.btnMg.TabIndex = 28;
            this.btnMg.Text = "Mg";
            this.btnMg.UseVisualStyleBackColor = false;
            this.btnMg.Click += new System.EventHandler(this.btnM_Click);
            // 
            // btnNa
            // 
            this.btnNa.BackColor = System.Drawing.Color.Gold;
            this.btnNa.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNa.Location = new System.Drawing.Point(24, 150);
            this.btnNa.Name = "btnNa";
            this.btnNa.Size = new System.Drawing.Size(69, 51);
            this.btnNa.TabIndex = 27;
            this.btnNa.Text = "Na";
            this.btnNa.UseVisualStyleBackColor = false;
            this.btnNa.Click += new System.EventHandler(this.btnNa_Click);
            // 
            // btnSe
            // 
            this.btnSe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSe.Location = new System.Drawing.Point(1149, 207);
            this.btnSe.Name = "btnSe";
            this.btnSe.Size = new System.Drawing.Size(69, 51);
            this.btnSe.TabIndex = 58;
            this.btnSe.Text = "Se";
            this.btnSe.UseVisualStyleBackColor = false;
            this.btnSe.Click += new System.EventHandler(this.btnSe_Click);
            // 
            // btnAs
            // 
            this.btnAs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAs.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAs.Location = new System.Drawing.Point(1074, 207);
            this.btnAs.Name = "btnAs";
            this.btnAs.Size = new System.Drawing.Size(69, 51);
            this.btnAs.TabIndex = 57;
            this.btnAs.Text = "As";
            this.btnAs.UseVisualStyleBackColor = false;
            this.btnAs.Click += new System.EventHandler(this.btnAs_Click);
            // 
            // btnGe
            // 
            this.btnGe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGe.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnGe.Location = new System.Drawing.Point(999, 207);
            this.btnGe.Name = "btnGe";
            this.btnGe.Size = new System.Drawing.Size(69, 51);
            this.btnGe.TabIndex = 56;
            this.btnGe.Text = "Ge";
            this.btnGe.UseVisualStyleBackColor = false;
            this.btnGe.Click += new System.EventHandler(this.btnGe_Click);
            // 
            // btnGa
            // 
            this.btnGa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnGa.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnGa.Location = new System.Drawing.Point(924, 207);
            this.btnGa.Name = "btnGa";
            this.btnGa.Size = new System.Drawing.Size(69, 51);
            this.btnGa.TabIndex = 55;
            this.btnGa.Text = "Ga";
            this.btnGa.UseVisualStyleBackColor = false;
            this.btnGa.Click += new System.EventHandler(this.btnGa_Click);
            // 
            // btnZn
            // 
            this.btnZn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnZn.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnZn.Location = new System.Drawing.Point(849, 205);
            this.btnZn.Name = "btnZn";
            this.btnZn.Size = new System.Drawing.Size(73, 51);
            this.btnZn.TabIndex = 54;
            this.btnZn.Text = "Zn";
            this.btnZn.UseVisualStyleBackColor = false;
            this.btnZn.Click += new System.EventHandler(this.btnZn_Click);
            // 
            // btnCu
            // 
            this.btnCu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCu.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCu.Location = new System.Drawing.Point(774, 207);
            this.btnCu.Name = "btnCu";
            this.btnCu.Size = new System.Drawing.Size(69, 51);
            this.btnCu.TabIndex = 53;
            this.btnCu.Text = "Cu";
            this.btnCu.UseVisualStyleBackColor = false;
            this.btnCu.Click += new System.EventHandler(this.btnCu_Click);
            // 
            // btnNi
            // 
            this.btnNi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNi.Location = new System.Drawing.Point(699, 207);
            this.btnNi.Name = "btnNi";
            this.btnNi.Size = new System.Drawing.Size(69, 51);
            this.btnNi.TabIndex = 52;
            this.btnNi.Text = "Ni";
            this.btnNi.UseVisualStyleBackColor = false;
            this.btnNi.Click += new System.EventHandler(this.btnNi_Click);
            // 
            // btnCo
            // 
            this.btnCo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCo.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCo.Location = new System.Drawing.Point(624, 207);
            this.btnCo.Name = "btnCo";
            this.btnCo.Size = new System.Drawing.Size(69, 51);
            this.btnCo.TabIndex = 51;
            this.btnCo.Text = "Co";
            this.btnCo.UseVisualStyleBackColor = false;
            this.btnCo.Click += new System.EventHandler(this.btnCo_Click);
            // 
            // btnFe
            // 
            this.btnFe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFe.Location = new System.Drawing.Point(549, 207);
            this.btnFe.Name = "btnFe";
            this.btnFe.Size = new System.Drawing.Size(69, 51);
            this.btnFe.TabIndex = 50;
            this.btnFe.Text = "Fe";
            this.btnFe.UseVisualStyleBackColor = false;
            this.btnFe.Click += new System.EventHandler(this.btnFe_Click);
            // 
            // btnMn
            // 
            this.btnMn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnMn.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnMn.Location = new System.Drawing.Point(474, 207);
            this.btnMn.Name = "btnMn";
            this.btnMn.Size = new System.Drawing.Size(69, 51);
            this.btnMn.TabIndex = 49;
            this.btnMn.Text = "Mn";
            this.btnMn.UseVisualStyleBackColor = false;
            this.btnMn.Click += new System.EventHandler(this.btnMn_Click);
            // 
            // btnCr
            // 
            this.btnCr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCr.Location = new System.Drawing.Point(399, 207);
            this.btnCr.Name = "btnCr";
            this.btnCr.Size = new System.Drawing.Size(69, 51);
            this.btnCr.TabIndex = 48;
            this.btnCr.Text = "Cr";
            this.btnCr.UseVisualStyleBackColor = false;
            this.btnCr.Click += new System.EventHandler(this.btnCr_Click);
            // 
            // btnV
            // 
            this.btnV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnV.Location = new System.Drawing.Point(324, 207);
            this.btnV.Name = "btnV";
            this.btnV.Size = new System.Drawing.Size(69, 51);
            this.btnV.TabIndex = 47;
            this.btnV.Text = "V";
            this.btnV.UseVisualStyleBackColor = false;
            this.btnV.Click += new System.EventHandler(this.btnV_Click);
            // 
            // btnTi
            // 
            this.btnTi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnTi.Location = new System.Drawing.Point(249, 207);
            this.btnTi.Name = "btnTi";
            this.btnTi.Size = new System.Drawing.Size(69, 51);
            this.btnTi.TabIndex = 46;
            this.btnTi.Text = "Ti";
            this.btnTi.UseVisualStyleBackColor = false;
            this.btnTi.Click += new System.EventHandler(this.btnTi_Click);
            // 
            // btnSc
            // 
            this.btnSc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSc.Location = new System.Drawing.Point(174, 207);
            this.btnSc.Name = "btnSc";
            this.btnSc.Size = new System.Drawing.Size(69, 51);
            this.btnSc.TabIndex = 45;
            this.btnSc.Text = "Sc";
            this.btnSc.UseVisualStyleBackColor = false;
            this.btnSc.Click += new System.EventHandler(this.btnSc_Click);
            // 
            // btnCa
            // 
            this.btnCa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnCa.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCa.Location = new System.Drawing.Point(99, 207);
            this.btnCa.Name = "btnCa";
            this.btnCa.Size = new System.Drawing.Size(69, 51);
            this.btnCa.TabIndex = 44;
            this.btnCa.Text = "Ca";
            this.btnCa.UseVisualStyleBackColor = false;
            this.btnCa.Click += new System.EventHandler(this.btnCa_Click);
            // 
            // btnK
            // 
            this.btnK.BackColor = System.Drawing.Color.Gold;
            this.btnK.Location = new System.Drawing.Point(24, 207);
            this.btnK.Name = "btnK";
            this.btnK.Size = new System.Drawing.Size(69, 51);
            this.btnK.TabIndex = 43;
            this.btnK.Text = "K";
            this.btnK.UseVisualStyleBackColor = false;
            this.btnK.Click += new System.EventHandler(this.btnK_Click);
            // 
            // btnTe
            // 
            this.btnTe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnTe.Location = new System.Drawing.Point(1149, 264);
            this.btnTe.Name = "btnTe";
            this.btnTe.Size = new System.Drawing.Size(69, 51);
            this.btnTe.TabIndex = 74;
            this.btnTe.Text = "Te";
            this.btnTe.UseVisualStyleBackColor = false;
            this.btnTe.Click += new System.EventHandler(this.button49_Click);
            // 
            // btnSb
            // 
            this.btnSb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSb.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSb.Location = new System.Drawing.Point(1074, 264);
            this.btnSb.Name = "btnSb";
            this.btnSb.Size = new System.Drawing.Size(69, 51);
            this.btnSb.TabIndex = 73;
            this.btnSb.Text = "Sb";
            this.btnSb.UseVisualStyleBackColor = false;
            this.btnSb.Click += new System.EventHandler(this.button50_Click);
            // 
            // btnSn
            // 
            this.btnSn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSn.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSn.Location = new System.Drawing.Point(999, 264);
            this.btnSn.Name = "btnSn";
            this.btnSn.Size = new System.Drawing.Size(69, 51);
            this.btnSn.TabIndex = 72;
            this.btnSn.Text = "Sn";
            this.btnSn.UseVisualStyleBackColor = false;
            this.btnSn.Click += new System.EventHandler(this.btnSn_Click);
            // 
            // btnIn
            // 
            this.btnIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnIn.Location = new System.Drawing.Point(924, 264);
            this.btnIn.Name = "btnIn";
            this.btnIn.Size = new System.Drawing.Size(69, 51);
            this.btnIn.TabIndex = 71;
            this.btnIn.Text = "In";
            this.btnIn.UseVisualStyleBackColor = false;
            this.btnIn.Click += new System.EventHandler(this.btnIn_Click);
            // 
            // btnCd
            // 
            this.btnCd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCd.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCd.Location = new System.Drawing.Point(849, 264);
            this.btnCd.Name = "btnCd";
            this.btnCd.Size = new System.Drawing.Size(73, 51);
            this.btnCd.TabIndex = 70;
            this.btnCd.Text = "Cd";
            this.btnCd.UseVisualStyleBackColor = false;
            this.btnCd.Click += new System.EventHandler(this.btnCd_Click);
            // 
            // btnAg
            // 
            this.btnAg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAg.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAg.Location = new System.Drawing.Point(774, 264);
            this.btnAg.Name = "btnAg";
            this.btnAg.Size = new System.Drawing.Size(69, 51);
            this.btnAg.TabIndex = 69;
            this.btnAg.Text = "Ag";
            this.btnAg.UseVisualStyleBackColor = false;
            this.btnAg.Click += new System.EventHandler(this.btnAg_Click);
            // 
            // btnPd
            // 
            this.btnPd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnPd.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPd.Location = new System.Drawing.Point(699, 264);
            this.btnPd.Name = "btnPd";
            this.btnPd.Size = new System.Drawing.Size(69, 51);
            this.btnPd.TabIndex = 68;
            this.btnPd.Text = "Pd";
            this.btnPd.UseVisualStyleBackColor = false;
            this.btnPd.Click += new System.EventHandler(this.btnPd_Click);
            // 
            // btnRh
            // 
            this.btnRh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRh.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRh.Location = new System.Drawing.Point(624, 264);
            this.btnRh.Name = "btnRh";
            this.btnRh.Size = new System.Drawing.Size(69, 51);
            this.btnRh.TabIndex = 67;
            this.btnRh.Text = "Rh";
            this.btnRh.UseVisualStyleBackColor = false;
            this.btnRh.Click += new System.EventHandler(this.btnRh_Click);
            // 
            // btnRu
            // 
            this.btnRu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRu.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRu.Location = new System.Drawing.Point(549, 264);
            this.btnRu.Name = "btnRu";
            this.btnRu.Size = new System.Drawing.Size(69, 51);
            this.btnRu.TabIndex = 66;
            this.btnRu.Text = "Ru";
            this.btnRu.UseVisualStyleBackColor = false;
            this.btnRu.Click += new System.EventHandler(this.btnRu_Click);
            // 
            // btnTc
            // 
            this.btnTc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnTc.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnTc.Location = new System.Drawing.Point(474, 264);
            this.btnTc.Name = "btnTc";
            this.btnTc.Size = new System.Drawing.Size(69, 51);
            this.btnTc.TabIndex = 65;
            this.btnTc.Text = "Tc";
            this.btnTc.UseVisualStyleBackColor = false;
            this.btnTc.Click += new System.EventHandler(this.btnTc_Click);
            // 
            // btnMo
            // 
            this.btnMo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnMo.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnMo.Location = new System.Drawing.Point(399, 264);
            this.btnMo.Name = "btnMo";
            this.btnMo.Size = new System.Drawing.Size(69, 51);
            this.btnMo.TabIndex = 64;
            this.btnMo.Text = "Mo";
            this.btnMo.UseVisualStyleBackColor = false;
            this.btnMo.Click += new System.EventHandler(this.btnMo_Click);
            // 
            // btnNb
            // 
            this.btnNb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNb.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNb.Location = new System.Drawing.Point(324, 264);
            this.btnNb.Name = "btnNb";
            this.btnNb.Size = new System.Drawing.Size(69, 51);
            this.btnNb.TabIndex = 63;
            this.btnNb.Text = "Nb";
            this.btnNb.UseVisualStyleBackColor = false;
            this.btnNb.Click += new System.EventHandler(this.btnNb_Click);
            // 
            // btnZr
            // 
            this.btnZr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnZr.Location = new System.Drawing.Point(249, 264);
            this.btnZr.Name = "btnZr";
            this.btnZr.Size = new System.Drawing.Size(69, 51);
            this.btnZr.TabIndex = 62;
            this.btnZr.Text = "Zr";
            this.btnZr.UseVisualStyleBackColor = false;
            this.btnZr.Click += new System.EventHandler(this.btnZr_Click);
            // 
            // btnY
            // 
            this.btnY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnY.Location = new System.Drawing.Point(174, 264);
            this.btnY.Name = "btnY";
            this.btnY.Size = new System.Drawing.Size(69, 51);
            this.btnY.TabIndex = 61;
            this.btnY.Text = "Y";
            this.btnY.UseVisualStyleBackColor = false;
            this.btnY.Click += new System.EventHandler(this.btnY_Click);
            // 
            // btnSr
            // 
            this.btnSr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnSr.Location = new System.Drawing.Point(99, 266);
            this.btnSr.Name = "btnSr";
            this.btnSr.Size = new System.Drawing.Size(69, 51);
            this.btnSr.TabIndex = 60;
            this.btnSr.Text = "Sr";
            this.btnSr.UseVisualStyleBackColor = false;
            this.btnSr.Click += new System.EventHandler(this.btnSr_Click);
            // 
            // btnRb
            // 
            this.btnRb.BackColor = System.Drawing.Color.Gold;
            this.btnRb.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRb.Location = new System.Drawing.Point(24, 264);
            this.btnRb.Name = "btnRb";
            this.btnRb.Size = new System.Drawing.Size(69, 51);
            this.btnRb.TabIndex = 59;
            this.btnRb.Text = "Rb";
            this.btnRb.UseVisualStyleBackColor = false;
            this.btnRb.Click += new System.EventHandler(this.btnRb_Click);
            // 
            // btnPo
            // 
            this.btnPo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnPo.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPo.Location = new System.Drawing.Point(1149, 321);
            this.btnPo.Name = "btnPo";
            this.btnPo.Size = new System.Drawing.Size(69, 51);
            this.btnPo.TabIndex = 90;
            this.btnPo.Text = "Po";
            this.btnPo.UseVisualStyleBackColor = false;
            this.btnPo.Click += new System.EventHandler(this.button65_Click);
            // 
            // btnBi
            // 
            this.btnBi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBi.Location = new System.Drawing.Point(1074, 321);
            this.btnBi.Name = "btnBi";
            this.btnBi.Size = new System.Drawing.Size(69, 51);
            this.btnBi.TabIndex = 89;
            this.btnBi.Text = "Bi";
            this.btnBi.UseVisualStyleBackColor = false;
            this.btnBi.Click += new System.EventHandler(this.button66_Click);
            // 
            // btnPb
            // 
            this.btnPb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnPb.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPb.Location = new System.Drawing.Point(999, 321);
            this.btnPb.Name = "btnPb";
            this.btnPb.Size = new System.Drawing.Size(69, 51);
            this.btnPb.TabIndex = 88;
            this.btnPb.Text = "Pb";
            this.btnPb.UseVisualStyleBackColor = false;
            this.btnPb.Click += new System.EventHandler(this.button67_Click);
            // 
            // btnTl
            // 
            this.btnTl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnTl.Location = new System.Drawing.Point(924, 321);
            this.btnTl.Name = "btnTl";
            this.btnTl.Size = new System.Drawing.Size(69, 51);
            this.btnTl.TabIndex = 87;
            this.btnTl.Text = "Tl";
            this.btnTl.UseVisualStyleBackColor = false;
            this.btnTl.Click += new System.EventHandler(this.button68_Click);
            // 
            // btnHg
            // 
            this.btnHg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnHg.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnHg.Location = new System.Drawing.Point(849, 321);
            this.btnHg.Name = "btnHg";
            this.btnHg.Size = new System.Drawing.Size(73, 51);
            this.btnHg.TabIndex = 86;
            this.btnHg.Text = "Hg";
            this.btnHg.UseVisualStyleBackColor = false;
            this.btnHg.Click += new System.EventHandler(this.button69_Click);
            // 
            // btnAu
            // 
            this.btnAu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAu.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAu.Location = new System.Drawing.Point(774, 321);
            this.btnAu.Name = "btnAu";
            this.btnAu.Size = new System.Drawing.Size(69, 51);
            this.btnAu.TabIndex = 85;
            this.btnAu.Text = "Au";
            this.btnAu.UseVisualStyleBackColor = false;
            this.btnAu.Click += new System.EventHandler(this.button70_Click);
            // 
            // btnPt
            // 
            this.btnPt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnPt.Location = new System.Drawing.Point(699, 321);
            this.btnPt.Name = "btnPt";
            this.btnPt.Size = new System.Drawing.Size(69, 51);
            this.btnPt.TabIndex = 84;
            this.btnPt.Text = "Pt";
            this.btnPt.UseVisualStyleBackColor = false;
            this.btnPt.Click += new System.EventHandler(this.button71_Click);
            // 
            // btnIr
            // 
            this.btnIr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnIr.Location = new System.Drawing.Point(624, 321);
            this.btnIr.Name = "btnIr";
            this.btnIr.Size = new System.Drawing.Size(69, 51);
            this.btnIr.TabIndex = 83;
            this.btnIr.Text = "Ir";
            this.btnIr.UseVisualStyleBackColor = false;
            this.btnIr.Click += new System.EventHandler(this.button72_Click);
            // 
            // btnOs
            // 
            this.btnOs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnOs.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnOs.Location = new System.Drawing.Point(549, 321);
            this.btnOs.Name = "btnOs";
            this.btnOs.Size = new System.Drawing.Size(69, 51);
            this.btnOs.TabIndex = 82;
            this.btnOs.Text = "Os";
            this.btnOs.UseVisualStyleBackColor = false;
            this.btnOs.Click += new System.EventHandler(this.button73_Click);
            // 
            // btnRe
            // 
            this.btnRe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRe.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRe.Location = new System.Drawing.Point(474, 321);
            this.btnRe.Name = "btnRe";
            this.btnRe.Size = new System.Drawing.Size(69, 51);
            this.btnRe.TabIndex = 81;
            this.btnRe.Text = "Re";
            this.btnRe.UseVisualStyleBackColor = false;
            this.btnRe.Click += new System.EventHandler(this.button74_Click);
            // 
            // btnW
            // 
            this.btnW.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnW.Location = new System.Drawing.Point(399, 321);
            this.btnW.Name = "btnW";
            this.btnW.Size = new System.Drawing.Size(69, 51);
            this.btnW.TabIndex = 80;
            this.btnW.Text = "W";
            this.btnW.UseVisualStyleBackColor = false;
            this.btnW.Click += new System.EventHandler(this.button75_Click);
            // 
            // btnTa
            // 
            this.btnTa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnTa.Location = new System.Drawing.Point(324, 321);
            this.btnTa.Name = "btnTa";
            this.btnTa.Size = new System.Drawing.Size(69, 51);
            this.btnTa.TabIndex = 79;
            this.btnTa.Text = "Ta";
            this.btnTa.UseVisualStyleBackColor = false;
            this.btnTa.Click += new System.EventHandler(this.button76_Click);
            // 
            // btnHf
            // 
            this.btnHf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnHf.Location = new System.Drawing.Point(249, 321);
            this.btnHf.Name = "btnHf";
            this.btnHf.Size = new System.Drawing.Size(69, 51);
            this.btnHf.TabIndex = 78;
            this.btnHf.Text = "Hf";
            this.btnHf.UseVisualStyleBackColor = false;
            this.btnHf.Click += new System.EventHandler(this.btnHf_Click);
            // 
            // btnX0
            // 
            this.btnX0.BackColor = System.Drawing.Color.Violet;
            this.btnX0.Location = new System.Drawing.Point(174, 321);
            this.btnX0.Name = "btnX0";
            this.btnX0.Size = new System.Drawing.Size(69, 51);
            this.btnX0.TabIndex = 77;
            this.btnX0.Text = "x";
            this.btnX0.UseVisualStyleBackColor = false;
            this.btnX0.Click += new System.EventHandler(this.button78_Click);
            // 
            // btnBa
            // 
            this.btnBa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnBa.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBa.Location = new System.Drawing.Point(99, 321);
            this.btnBa.Name = "btnBa";
            this.btnBa.Size = new System.Drawing.Size(69, 51);
            this.btnBa.TabIndex = 76;
            this.btnBa.Text = "Ba";
            this.btnBa.UseVisualStyleBackColor = false;
            this.btnBa.Click += new System.EventHandler(this.btnBa_Click);
            // 
            // btnCs
            // 
            this.btnCs.BackColor = System.Drawing.Color.Gold;
            this.btnCs.Location = new System.Drawing.Point(24, 321);
            this.btnCs.Name = "btnCs";
            this.btnCs.Size = new System.Drawing.Size(69, 51);
            this.btnCs.TabIndex = 75;
            this.btnCs.Text = "Cs";
            this.btnCs.UseVisualStyleBackColor = false;
            this.btnCs.Click += new System.EventHandler(this.btnCs_Click);
            // 
            // btnLv
            // 
            this.btnLv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLv.Location = new System.Drawing.Point(1149, 378);
            this.btnLv.Name = "btnLv";
            this.btnLv.Size = new System.Drawing.Size(69, 51);
            this.btnLv.TabIndex = 106;
            this.btnLv.Text = "Lv";
            this.btnLv.UseVisualStyleBackColor = false;
            this.btnLv.Click += new System.EventHandler(this.button81_Click);
            // 
            // btnMc
            // 
            this.btnMc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnMc.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnMc.Location = new System.Drawing.Point(1074, 378);
            this.btnMc.Name = "btnMc";
            this.btnMc.Size = new System.Drawing.Size(69, 51);
            this.btnMc.TabIndex = 105;
            this.btnMc.Text = "Mc";
            this.btnMc.UseVisualStyleBackColor = false;
            this.btnMc.Click += new System.EventHandler(this.button82_Click);
            // 
            // btnFl
            // 
            this.btnFl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnFl.Location = new System.Drawing.Point(999, 378);
            this.btnFl.Name = "btnFl";
            this.btnFl.Size = new System.Drawing.Size(69, 51);
            this.btnFl.TabIndex = 104;
            this.btnFl.Text = "Fl";
            this.btnFl.UseVisualStyleBackColor = false;
            this.btnFl.Click += new System.EventHandler(this.button83_Click);
            // 
            // btnNh
            // 
            this.btnNh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnNh.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNh.Location = new System.Drawing.Point(924, 378);
            this.btnNh.Name = "btnNh";
            this.btnNh.Size = new System.Drawing.Size(69, 51);
            this.btnNh.TabIndex = 103;
            this.btnNh.Text = "Nh";
            this.btnNh.UseVisualStyleBackColor = false;
            this.btnNh.Click += new System.EventHandler(this.button84_Click);
            // 
            // btnCn
            // 
            this.btnCn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCn.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCn.Location = new System.Drawing.Point(849, 378);
            this.btnCn.Name = "btnCn";
            this.btnCn.Size = new System.Drawing.Size(73, 51);
            this.btnCn.TabIndex = 102;
            this.btnCn.Text = "Cn";
            this.btnCn.UseVisualStyleBackColor = false;
            this.btnCn.Click += new System.EventHandler(this.button85_Click_1);
            // 
            // btnRg
            // 
            this.btnRg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRg.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRg.Location = new System.Drawing.Point(774, 378);
            this.btnRg.Name = "btnRg";
            this.btnRg.Size = new System.Drawing.Size(69, 51);
            this.btnRg.TabIndex = 101;
            this.btnRg.Text = "Rg";
            this.btnRg.UseVisualStyleBackColor = false;
            this.btnRg.Click += new System.EventHandler(this.button86_Click);
            // 
            // btnDs
            // 
            this.btnDs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDs.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDs.Location = new System.Drawing.Point(699, 379);
            this.btnDs.Name = "btnDs";
            this.btnDs.Size = new System.Drawing.Size(69, 51);
            this.btnDs.TabIndex = 100;
            this.btnDs.Text = "Ds";
            this.btnDs.UseVisualStyleBackColor = false;
            this.btnDs.Click += new System.EventHandler(this.button87_Click);
            // 
            // btnMt
            // 
            this.btnMt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnMt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnMt.Location = new System.Drawing.Point(624, 378);
            this.btnMt.Name = "btnMt";
            this.btnMt.Size = new System.Drawing.Size(69, 51);
            this.btnMt.TabIndex = 99;
            this.btnMt.Text = "Mt";
            this.btnMt.UseVisualStyleBackColor = false;
            this.btnMt.Click += new System.EventHandler(this.button88_Click);
            // 
            // btnHs
            // 
            this.btnHs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnHs.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnHs.Location = new System.Drawing.Point(549, 378);
            this.btnHs.Name = "btnHs";
            this.btnHs.Size = new System.Drawing.Size(69, 51);
            this.btnHs.TabIndex = 98;
            this.btnHs.Text = "Hs";
            this.btnHs.UseVisualStyleBackColor = false;
            this.btnHs.Click += new System.EventHandler(this.button89_Click);
            // 
            // btnBh
            // 
            this.btnBh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBh.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBh.Location = new System.Drawing.Point(474, 378);
            this.btnBh.Name = "btnBh";
            this.btnBh.Size = new System.Drawing.Size(69, 51);
            this.btnBh.TabIndex = 97;
            this.btnBh.Text = "Bh";
            this.btnBh.UseVisualStyleBackColor = false;
            this.btnBh.Click += new System.EventHandler(this.button90_Click);
            // 
            // btnSg
            // 
            this.btnSg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSg.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSg.Location = new System.Drawing.Point(399, 378);
            this.btnSg.Name = "btnSg";
            this.btnSg.Size = new System.Drawing.Size(69, 51);
            this.btnSg.TabIndex = 96;
            this.btnSg.Text = "Sg";
            this.btnSg.UseVisualStyleBackColor = false;
            this.btnSg.Click += new System.EventHandler(this.button91_Click);
            // 
            // btnDb
            // 
            this.btnDb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDb.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDb.Location = new System.Drawing.Point(324, 378);
            this.btnDb.Name = "btnDb";
            this.btnDb.Size = new System.Drawing.Size(69, 51);
            this.btnDb.TabIndex = 95;
            this.btnDb.Text = "Db";
            this.btnDb.UseVisualStyleBackColor = false;
            this.btnDb.Click += new System.EventHandler(this.button92_Click);
            // 
            // btnRf
            // 
            this.btnRf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRf.Location = new System.Drawing.Point(249, 378);
            this.btnRf.Name = "btnRf";
            this.btnRf.Size = new System.Drawing.Size(69, 51);
            this.btnRf.TabIndex = 94;
            this.btnRf.Text = "Rf";
            this.btnRf.UseVisualStyleBackColor = false;
            this.btnRf.Click += new System.EventHandler(this.btnRf_Click);
            // 
            // btnX1
            // 
            this.btnX1.BackColor = System.Drawing.Color.Purple;
            this.btnX1.Location = new System.Drawing.Point(174, 378);
            this.btnX1.Name = "btnX1";
            this.btnX1.Size = new System.Drawing.Size(69, 51);
            this.btnX1.TabIndex = 93;
            this.btnX1.Text = "x";
            this.btnX1.UseVisualStyleBackColor = false;
            // 
            // btnRa
            // 
            this.btnRa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnRa.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRa.Location = new System.Drawing.Point(99, 377);
            this.btnRa.Name = "btnRa";
            this.btnRa.Size = new System.Drawing.Size(69, 51);
            this.btnRa.TabIndex = 92;
            this.btnRa.Text = "Ra";
            this.btnRa.UseVisualStyleBackColor = false;
            this.btnRa.Click += new System.EventHandler(this.btnRa_Click);
            // 
            // btnFr
            // 
            this.btnFr.BackColor = System.Drawing.Color.Gold;
            this.btnFr.Location = new System.Drawing.Point(24, 378);
            this.btnFr.Name = "btnFr";
            this.btnFr.Size = new System.Drawing.Size(69, 51);
            this.btnFr.TabIndex = 91;
            this.btnFr.Text = "Fr";
            this.btnFr.UseVisualStyleBackColor = false;
            this.btnFr.Click += new System.EventHandler(this.btnFr_Click);
            // 
            // btnOg
            // 
            this.btnOg.BackColor = System.Drawing.Color.SkyBlue;
            this.btnOg.Font = new System.Drawing.Font("Bahnschrift Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnOg.Location = new System.Drawing.Point(1299, 378);
            this.btnOg.Name = "btnOg";
            this.btnOg.Size = new System.Drawing.Size(69, 51);
            this.btnOg.TabIndex = 116;
            this.btnOg.Text = "Og";
            this.btnOg.UseVisualStyleBackColor = false;
            this.btnOg.Click += new System.EventHandler(this.button97_Click);
            // 
            // btnTs
            // 
            this.btnTs.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnTs.Location = new System.Drawing.Point(1224, 378);
            this.btnTs.Name = "btnTs";
            this.btnTs.Size = new System.Drawing.Size(69, 51);
            this.btnTs.TabIndex = 115;
            this.btnTs.Text = "Ts";
            this.btnTs.UseVisualStyleBackColor = false;
            this.btnTs.Click += new System.EventHandler(this.button98_Click);
            // 
            // btnRn
            // 
            this.btnRn.BackColor = System.Drawing.Color.SkyBlue;
            this.btnRn.Font = new System.Drawing.Font("Bahnschrift Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRn.Location = new System.Drawing.Point(1299, 321);
            this.btnRn.Name = "btnRn";
            this.btnRn.Size = new System.Drawing.Size(69, 51);
            this.btnRn.TabIndex = 114;
            this.btnRn.Text = "Rn";
            this.btnRn.UseVisualStyleBackColor = false;
            this.btnRn.Click += new System.EventHandler(this.button99_Click);
            // 
            // btnAt
            // 
            this.btnAt.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnAt.Location = new System.Drawing.Point(1224, 321);
            this.btnAt.Name = "btnAt";
            this.btnAt.Size = new System.Drawing.Size(69, 51);
            this.btnAt.TabIndex = 113;
            this.btnAt.Text = "At";
            this.btnAt.UseVisualStyleBackColor = false;
            this.btnAt.Click += new System.EventHandler(this.button100_Click);
            // 
            // btnXe
            // 
            this.btnXe.BackColor = System.Drawing.Color.SkyBlue;
            this.btnXe.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnXe.Location = new System.Drawing.Point(1299, 264);
            this.btnXe.Name = "btnXe";
            this.btnXe.Size = new System.Drawing.Size(69, 51);
            this.btnXe.TabIndex = 112;
            this.btnXe.Text = "Xe";
            this.btnXe.UseVisualStyleBackColor = false;
            this.btnXe.Click += new System.EventHandler(this.button101_Click);
            // 
            // btnI
            // 
            this.btnI.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnI.Location = new System.Drawing.Point(1224, 264);
            this.btnI.Name = "btnI";
            this.btnI.Size = new System.Drawing.Size(69, 51);
            this.btnI.TabIndex = 111;
            this.btnI.Text = "I";
            this.btnI.UseVisualStyleBackColor = false;
            this.btnI.Click += new System.EventHandler(this.button102_Click);
            // 
            // btnKr
            // 
            this.btnKr.BackColor = System.Drawing.Color.SkyBlue;
            this.btnKr.Location = new System.Drawing.Point(1299, 207);
            this.btnKr.Name = "btnKr";
            this.btnKr.Size = new System.Drawing.Size(69, 51);
            this.btnKr.TabIndex = 110;
            this.btnKr.Text = "Kr";
            this.btnKr.UseVisualStyleBackColor = false;
            this.btnKr.Click += new System.EventHandler(this.btnKr_Click);
            // 
            // btnBr
            // 
            this.btnBr.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnBr.Font = new System.Drawing.Font("Bahnschrift Condensed", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBr.Location = new System.Drawing.Point(1224, 207);
            this.btnBr.Name = "btnBr";
            this.btnBr.Size = new System.Drawing.Size(69, 51);
            this.btnBr.TabIndex = 109;
            this.btnBr.Text = "Br";
            this.btnBr.UseVisualStyleBackColor = false;
            this.btnBr.Click += new System.EventHandler(this.btnBr_Click);
            // 
            // btnAr
            // 
            this.btnAr.BackColor = System.Drawing.Color.SkyBlue;
            this.btnAr.Location = new System.Drawing.Point(1299, 150);
            this.btnAr.Name = "btnAr";
            this.btnAr.Size = new System.Drawing.Size(69, 51);
            this.btnAr.TabIndex = 108;
            this.btnAr.Text = "Ar";
            this.btnAr.UseVisualStyleBackColor = false;
            this.btnAr.Click += new System.EventHandler(this.btnAr_Click);
            // 
            // btnCl
            // 
            this.btnCl.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnCl.Font = new System.Drawing.Font("Bahnschrift Condensed", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCl.Location = new System.Drawing.Point(1224, 150);
            this.btnCl.Name = "btnCl";
            this.btnCl.Size = new System.Drawing.Size(69, 51);
            this.btnCl.TabIndex = 107;
            this.btnCl.Text = "Cl";
            this.btnCl.UseVisualStyleBackColor = false;
            this.btnCl.Click += new System.EventHandler(this.btnCl_Click);
            // 
            // btnLr
            // 
            this.btnLr.BackColor = System.Drawing.Color.Purple;
            this.btnLr.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLr.Location = new System.Drawing.Point(1299, 502);
            this.btnLr.Name = "btnLr";
            this.btnLr.Size = new System.Drawing.Size(69, 51);
            this.btnLr.TabIndex = 146;
            this.btnLr.Text = "Lr";
            this.btnLr.UseVisualStyleBackColor = false;
            this.btnLr.Click += new System.EventHandler(this.button107_Click);
            // 
            // btnNo
            // 
            this.btnNo.BackColor = System.Drawing.Color.Purple;
            this.btnNo.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNo.Location = new System.Drawing.Point(1224, 502);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new System.Drawing.Size(69, 51);
            this.btnNo.TabIndex = 145;
            this.btnNo.Text = "No";
            this.btnNo.UseVisualStyleBackColor = false;
            this.btnNo.Click += new System.EventHandler(this.button108_Click);
            // 
            // btnLu
            // 
            this.btnLu.BackColor = System.Drawing.Color.Violet;
            this.btnLu.Location = new System.Drawing.Point(1299, 444);
            this.btnLu.Name = "btnLu";
            this.btnLu.Size = new System.Drawing.Size(69, 51);
            this.btnLu.TabIndex = 144;
            this.btnLu.Text = "Lu";
            this.btnLu.UseVisualStyleBackColor = false;
            this.btnLu.Click += new System.EventHandler(this.button109_Click);
            // 
            // btnYb
            // 
            this.btnYb.BackColor = System.Drawing.Color.Violet;
            this.btnYb.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnYb.Location = new System.Drawing.Point(1224, 444);
            this.btnYb.Name = "btnYb";
            this.btnYb.Size = new System.Drawing.Size(69, 51);
            this.btnYb.TabIndex = 143;
            this.btnYb.Text = "Yb";
            this.btnYb.UseVisualStyleBackColor = false;
            this.btnYb.Click += new System.EventHandler(this.button110_Click);
            // 
            // btnMd
            // 
            this.btnMd.BackColor = System.Drawing.Color.Purple;
            this.btnMd.Font = new System.Drawing.Font("Bahnschrift Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnMd.Location = new System.Drawing.Point(1149, 505);
            this.btnMd.Name = "btnMd";
            this.btnMd.Size = new System.Drawing.Size(69, 48);
            this.btnMd.TabIndex = 142;
            this.btnMd.Text = "Md";
            this.btnMd.UseVisualStyleBackColor = false;
            this.btnMd.Click += new System.EventHandler(this.button111_Click);
            // 
            // btnFm
            // 
            this.btnFm.BackColor = System.Drawing.Color.Purple;
            this.btnFm.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnFm.Location = new System.Drawing.Point(1074, 502);
            this.btnFm.Name = "btnFm";
            this.btnFm.Size = new System.Drawing.Size(69, 51);
            this.btnFm.TabIndex = 141;
            this.btnFm.Text = "Fm";
            this.btnFm.UseVisualStyleBackColor = false;
            this.btnFm.Click += new System.EventHandler(this.button112_Click);
            // 
            // btnEs
            // 
            this.btnEs.BackColor = System.Drawing.Color.Purple;
            this.btnEs.Location = new System.Drawing.Point(999, 502);
            this.btnEs.Name = "btnEs";
            this.btnEs.Size = new System.Drawing.Size(69, 51);
            this.btnEs.TabIndex = 140;
            this.btnEs.Text = "Es";
            this.btnEs.UseVisualStyleBackColor = false;
            this.btnEs.Click += new System.EventHandler(this.button113_Click);
            // 
            // btnCf
            // 
            this.btnCf.BackColor = System.Drawing.Color.Purple;
            this.btnCf.Font = new System.Drawing.Font("Bahnschrift Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCf.Location = new System.Drawing.Point(924, 502);
            this.btnCf.Name = "btnCf";
            this.btnCf.Size = new System.Drawing.Size(69, 51);
            this.btnCf.TabIndex = 139;
            this.btnCf.Text = "Cf";
            this.btnCf.UseVisualStyleBackColor = false;
            this.btnCf.Click += new System.EventHandler(this.button114_Click);
            // 
            // btnBk
            // 
            this.btnBk.BackColor = System.Drawing.Color.Purple;
            this.btnBk.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBk.Location = new System.Drawing.Point(849, 502);
            this.btnBk.Name = "btnBk";
            this.btnBk.Size = new System.Drawing.Size(69, 51);
            this.btnBk.TabIndex = 138;
            this.btnBk.Text = "Bk";
            this.btnBk.UseVisualStyleBackColor = false;
            this.btnBk.Click += new System.EventHandler(this.button115_Click);
            // 
            // btnA
            // 
            this.btnA.BackColor = System.Drawing.Color.Purple;
            this.btnA.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA.Location = new System.Drawing.Point(774, 502);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(69, 51);
            this.btnA.TabIndex = 137;
            this.btnA.Text = "A";
            this.btnA.UseVisualStyleBackColor = false;
            this.btnA.Click += new System.EventHandler(this.button116_Click);
            // 
            // btnAm
            // 
            this.btnAm.BackColor = System.Drawing.Color.Purple;
            this.btnAm.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAm.Location = new System.Drawing.Point(699, 502);
            this.btnAm.Name = "btnAm";
            this.btnAm.Size = new System.Drawing.Size(69, 51);
            this.btnAm.TabIndex = 136;
            this.btnAm.Text = "Am";
            this.btnAm.UseVisualStyleBackColor = false;
            this.btnAm.Click += new System.EventHandler(this.button117_Click);
            // 
            // btnPu
            // 
            this.btnPu.BackColor = System.Drawing.Color.Purple;
            this.btnPu.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPu.Location = new System.Drawing.Point(624, 502);
            this.btnPu.Name = "btnPu";
            this.btnPu.Size = new System.Drawing.Size(69, 51);
            this.btnPu.TabIndex = 135;
            this.btnPu.Text = "Pu";
            this.btnPu.UseVisualStyleBackColor = false;
            this.btnPu.Click += new System.EventHandler(this.button118_Click);
            // 
            // btnNp
            // 
            this.btnNp.BackColor = System.Drawing.Color.Purple;
            this.btnNp.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNp.Location = new System.Drawing.Point(549, 502);
            this.btnNp.Name = "btnNp";
            this.btnNp.Size = new System.Drawing.Size(69, 51);
            this.btnNp.TabIndex = 134;
            this.btnNp.Text = "Np";
            this.btnNp.UseVisualStyleBackColor = false;
            this.btnNp.Click += new System.EventHandler(this.button119_Click);
            // 
            // btnU
            // 
            this.btnU.BackColor = System.Drawing.Color.Purple;
            this.btnU.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnU.Location = new System.Drawing.Point(474, 502);
            this.btnU.Name = "btnU";
            this.btnU.Size = new System.Drawing.Size(69, 51);
            this.btnU.TabIndex = 133;
            this.btnU.Text = "U";
            this.btnU.UseVisualStyleBackColor = false;
            this.btnU.Click += new System.EventHandler(this.button120_Click);
            // 
            // btnPa
            // 
            this.btnPa.BackColor = System.Drawing.Color.Purple;
            this.btnPa.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPa.Location = new System.Drawing.Point(399, 502);
            this.btnPa.Name = "btnPa";
            this.btnPa.Size = new System.Drawing.Size(69, 51);
            this.btnPa.TabIndex = 132;
            this.btnPa.Text = "Pa";
            this.btnPa.UseVisualStyleBackColor = false;
            this.btnPa.Click += new System.EventHandler(this.button121_Click);
            // 
            // btnTh
            // 
            this.btnTh.BackColor = System.Drawing.Color.Purple;
            this.btnTh.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnTh.Location = new System.Drawing.Point(324, 502);
            this.btnTh.Name = "btnTh";
            this.btnTh.Size = new System.Drawing.Size(69, 51);
            this.btnTh.TabIndex = 131;
            this.btnTh.Text = "Th";
            this.btnTh.UseVisualStyleBackColor = false;
            this.btnTh.Click += new System.EventHandler(this.button122_Click);
            // 
            // btnAc
            // 
            this.btnAc.BackColor = System.Drawing.Color.Purple;
            this.btnAc.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAc.Location = new System.Drawing.Point(249, 502);
            this.btnAc.Name = "btnAc";
            this.btnAc.Size = new System.Drawing.Size(69, 51);
            this.btnAc.TabIndex = 130;
            this.btnAc.Text = "Ac";
            this.btnAc.UseVisualStyleBackColor = false;
            this.btnAc.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnTm
            // 
            this.btnTm.BackColor = System.Drawing.Color.Violet;
            this.btnTm.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnTm.Location = new System.Drawing.Point(1149, 444);
            this.btnTm.Name = "btnTm";
            this.btnTm.Size = new System.Drawing.Size(69, 51);
            this.btnTm.TabIndex = 129;
            this.btnTm.Text = "Tm";
            this.btnTm.UseVisualStyleBackColor = false;
            this.btnTm.Click += new System.EventHandler(this.button124_Click);
            // 
            // btnEr
            // 
            this.btnEr.BackColor = System.Drawing.Color.Violet;
            this.btnEr.Location = new System.Drawing.Point(1074, 444);
            this.btnEr.Name = "btnEr";
            this.btnEr.Size = new System.Drawing.Size(69, 51);
            this.btnEr.TabIndex = 128;
            this.btnEr.Text = "Er";
            this.btnEr.UseVisualStyleBackColor = false;
            this.btnEr.Click += new System.EventHandler(this.button125_Click);
            // 
            // btnHo
            // 
            this.btnHo.BackColor = System.Drawing.Color.Violet;
            this.btnHo.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnHo.Location = new System.Drawing.Point(999, 444);
            this.btnHo.Name = "btnHo";
            this.btnHo.Size = new System.Drawing.Size(69, 51);
            this.btnHo.TabIndex = 127;
            this.btnHo.Text = "Ho";
            this.btnHo.UseVisualStyleBackColor = false;
            this.btnHo.Click += new System.EventHandler(this.button126_Click);
            // 
            // btnDy
            // 
            this.btnDy.BackColor = System.Drawing.Color.Violet;
            this.btnDy.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDy.Location = new System.Drawing.Point(924, 444);
            this.btnDy.Name = "btnDy";
            this.btnDy.Size = new System.Drawing.Size(69, 51);
            this.btnDy.TabIndex = 126;
            this.btnDy.Text = "Dy";
            this.btnDy.UseVisualStyleBackColor = false;
            this.btnDy.Click += new System.EventHandler(this.button127_Click);
            // 
            // btnTb
            // 
            this.btnTb.BackColor = System.Drawing.Color.Violet;
            this.btnTb.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnTb.Location = new System.Drawing.Point(849, 444);
            this.btnTb.Name = "btnTb";
            this.btnTb.Size = new System.Drawing.Size(69, 51);
            this.btnTb.TabIndex = 125;
            this.btnTb.Text = "Tb";
            this.btnTb.UseVisualStyleBackColor = false;
            this.btnTb.Click += new System.EventHandler(this.button128_Click);
            // 
            // btnGd
            // 
            this.btnGd.BackColor = System.Drawing.Color.Violet;
            this.btnGd.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnGd.Location = new System.Drawing.Point(774, 444);
            this.btnGd.Name = "btnGd";
            this.btnGd.Size = new System.Drawing.Size(69, 51);
            this.btnGd.TabIndex = 124;
            this.btnGd.Text = "Gd";
            this.btnGd.UseVisualStyleBackColor = false;
            this.btnGd.Click += new System.EventHandler(this.button129_Click);
            // 
            // btnEu
            // 
            this.btnEu.BackColor = System.Drawing.Color.Violet;
            this.btnEu.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnEu.Location = new System.Drawing.Point(699, 444);
            this.btnEu.Name = "btnEu";
            this.btnEu.Size = new System.Drawing.Size(69, 51);
            this.btnEu.TabIndex = 123;
            this.btnEu.Text = "Eu";
            this.btnEu.UseVisualStyleBackColor = false;
            this.btnEu.Click += new System.EventHandler(this.button130_Click);
            // 
            // btnSm
            // 
            this.btnSm.BackColor = System.Drawing.Color.Violet;
            this.btnSm.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSm.Location = new System.Drawing.Point(624, 444);
            this.btnSm.Name = "btnSm";
            this.btnSm.Size = new System.Drawing.Size(69, 51);
            this.btnSm.TabIndex = 122;
            this.btnSm.Text = "Sm";
            this.btnSm.UseVisualStyleBackColor = false;
            this.btnSm.Click += new System.EventHandler(this.button131_Click);
            // 
            // btnPm
            // 
            this.btnPm.BackColor = System.Drawing.Color.Violet;
            this.btnPm.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPm.Location = new System.Drawing.Point(549, 444);
            this.btnPm.Name = "btnPm";
            this.btnPm.Size = new System.Drawing.Size(69, 51);
            this.btnPm.TabIndex = 121;
            this.btnPm.Text = "Pm";
            this.btnPm.UseVisualStyleBackColor = false;
            this.btnPm.Click += new System.EventHandler(this.button132_Click);
            // 
            // btnNd
            // 
            this.btnNd.BackColor = System.Drawing.Color.Violet;
            this.btnNd.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNd.Location = new System.Drawing.Point(474, 444);
            this.btnNd.Name = "btnNd";
            this.btnNd.Size = new System.Drawing.Size(69, 51);
            this.btnNd.TabIndex = 120;
            this.btnNd.Text = "Nd";
            this.btnNd.UseVisualStyleBackColor = false;
            this.btnNd.Click += new System.EventHandler(this.button133_Click);
            // 
            // btnPr
            // 
            this.btnPr.BackColor = System.Drawing.Color.Violet;
            this.btnPr.Location = new System.Drawing.Point(399, 444);
            this.btnPr.Name = "btnPr";
            this.btnPr.Size = new System.Drawing.Size(69, 51);
            this.btnPr.TabIndex = 119;
            this.btnPr.Text = "Pr";
            this.btnPr.UseVisualStyleBackColor = false;
            this.btnPr.Click += new System.EventHandler(this.button134_Click);
            // 
            // btnCe
            // 
            this.btnCe.BackColor = System.Drawing.Color.Violet;
            this.btnCe.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCe.Location = new System.Drawing.Point(324, 444);
            this.btnCe.Name = "btnCe";
            this.btnCe.Size = new System.Drawing.Size(69, 51);
            this.btnCe.TabIndex = 118;
            this.btnCe.Text = "Ce";
            this.btnCe.UseVisualStyleBackColor = false;
            this.btnCe.Click += new System.EventHandler(this.button135_Click);
            // 
            // btnLa
            // 
            this.btnLa.BackColor = System.Drawing.Color.Violet;
            this.btnLa.Location = new System.Drawing.Point(249, 444);
            this.btnLa.Name = "btnLa";
            this.btnLa.Size = new System.Drawing.Size(69, 51);
            this.btnLa.TabIndex = 117;
            this.btnLa.Text = "La";
            this.btnLa.UseVisualStyleBackColor = false;
            this.btnLa.Click += new System.EventHandler(this.btnLa_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(2, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 19);
            this.label5.TabIndex = 147;
            this.label5.Text = "3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(2, 207);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 19);
            this.label6.TabIndex = 148;
            this.label6.Text = "4";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(2, 264);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 19);
            this.label7.TabIndex = 149;
            this.label7.Text = "5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(2, 321);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 19);
            this.label8.TabIndex = 150;
            this.label8.Text = "6";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(2, 378);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 19);
            this.label9.TabIndex = 151;
            this.label9.Text = "7";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(150, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(17, 19);
            this.label10.TabIndex = 152;
            this.label10.Text = "2";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(226, 188);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(17, 19);
            this.label11.TabIndex = 153;
            this.label11.Text = "3";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(299, 188);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 19);
            this.label12.TabIndex = 154;
            this.label12.Text = "4";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(374, 188);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 19);
            this.label13.TabIndex = 155;
            this.label13.Text = "5";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(449, 188);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 19);
            this.label14.TabIndex = 156;
            this.label14.Text = "6";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(524, 188);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(17, 19);
            this.label15.TabIndex = 157;
            this.label15.Text = "7";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(604, 188);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(17, 19);
            this.label16.TabIndex = 158;
            this.label16.Text = "8";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(676, 188);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(17, 19);
            this.label17.TabIndex = 159;
            this.label17.Text = "9";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(749, 188);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(25, 19);
            this.label18.TabIndex = 160;
            this.label18.Text = "10";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(821, 188);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(25, 19);
            this.label19.TabIndex = 161;
            this.label19.Text = "11";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(897, 188);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(25, 19);
            this.label20.TabIndex = 162;
            this.label20.Text = "12";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(963, 64);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(25, 19);
            this.label21.TabIndex = 163;
            this.label21.Text = "13";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(1042, 64);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(25, 19);
            this.label22.TabIndex = 164;
            this.label22.Text = "14";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label23.Location = new System.Drawing.Point(1117, 67);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(25, 19);
            this.label23.TabIndex = 165;
            this.label23.Text = "15";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(1190, 67);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(25, 19);
            this.label24.TabIndex = 166;
            this.label24.Text = "16";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label25.Location = new System.Drawing.Point(1266, 67);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(25, 19);
            this.label25.TabIndex = 167;
            this.label25.Text = "17";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(1341, 10);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(25, 19);
            this.label26.TabIndex = 168;
            this.label26.Text = "18";
            // 
            // btnNometales
            // 
            this.btnNometales.AccessibleName = "";
            this.btnNometales.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.btnNometales.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnNometales.Location = new System.Drawing.Point(125, 550);
            this.btnNometales.Name = "btnNometales";
            this.btnNometales.Size = new System.Drawing.Size(95, 28);
            this.btnNometales.TabIndex = 169;
            this.btnNometales.Text = "No Metales";
            this.btnNometales.UseVisualStyleBackColor = true;
            this.btnNometales.Click += new System.EventHandler(this.btnNometales_Click);
            // 
            // btnMetaloides
            // 
            this.btnMetaloides.AccessibleName = "";
            this.btnMetaloides.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.btnMetaloides.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMetaloides.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMetaloides.Location = new System.Drawing.Point(12, 584);
            this.btnMetaloides.Name = "btnMetaloides";
            this.btnMetaloides.Size = new System.Drawing.Size(95, 26);
            this.btnMetaloides.TabIndex = 170;
            this.btnMetaloides.Text = "Metaloides";
            this.btnMetaloides.UseVisualStyleBackColor = true;
            this.btnMetaloides.Click += new System.EventHandler(this.btnOtros_Click);
            // 
            // siglaA
            // 
            this.siglaA.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.siglaA.ForeColor = System.Drawing.SystemColors.WindowText;
            this.siglaA.Location = new System.Drawing.Point(216, 93);
            this.siglaA.Name = "siglaA";
            this.siglaA.Size = new System.Drawing.Size(54, 47);
            this.siglaA.TabIndex = 172;
            this.siglaA.TextChanged += new System.EventHandler(this.siglaA_TextChanged);
            // 
            // siglaB
            // 
            this.siglaB.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.siglaB.ForeColor = System.Drawing.SystemColors.WindowText;
            this.siglaB.Location = new System.Drawing.Point(367, 97);
            this.siglaB.Name = "siglaB";
            this.siglaB.Size = new System.Drawing.Size(54, 47);
            this.siglaB.TabIndex = 173;
            // 
            // valenciaA
            // 
            this.valenciaA.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.valenciaA.ForeColor = System.Drawing.SystemColors.WindowText;
            this.valenciaA.Location = new System.Drawing.Point(293, 93);
            this.valenciaA.Name = "valenciaA";
            this.valenciaA.Size = new System.Drawing.Size(44, 47);
            this.valenciaA.TabIndex = 174;
            // 
            // valenciaB
            // 
            this.valenciaB.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.valenciaB.Location = new System.Drawing.Point(441, 93);
            this.valenciaB.Name = "valenciaB";
            this.valenciaB.Size = new System.Drawing.Size(59, 47);
            this.valenciaB.TabIndex = 175;
            this.valenciaB.TextChanged += new System.EventHandler(this.valenciaB_TextChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial Black", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label27.Location = new System.Drawing.Point(218, 71);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 19);
            this.label27.TabIndex = 176;
            this.label27.Text = "Sigla";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(275, 71);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(65, 16);
            this.label28.TabIndex = 177;
            this.label28.Text = "Valencia";
            // 
            // labelResultado
            // 
            this.labelResultado.AutoSize = true;
            this.labelResultado.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResultado.Location = new System.Drawing.Point(821, 30);
            this.labelResultado.Name = "labelResultado";
            this.labelResultado.Size = new System.Drawing.Size(52, 28);
            this.labelResultado.TabIndex = 179;
            this.labelResultado.Text = "*****";
            this.labelResultado.Click += new System.EventHandler(this.labelResultado_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.button1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(110, 64);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(24, 27);
            this.button1.TabIndex = 180;
            this.button1.Text = "Resultado";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label30.Location = new System.Drawing.Point(367, 75);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 16);
            this.label30.TabIndex = 181;
            this.label30.Text = "Sigla";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label31.Location = new System.Drawing.Point(427, 75);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 16);
            this.label31.TabIndex = 182;
            this.label31.Text = "Valencia";
            // 
            // listBox3
            // 
            this.listBox3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 28;
            this.listBox3.Location = new System.Drawing.Point(110, 44);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(24, 4);
            this.listBox3.TabIndex = 183;
            // 
            // Oxidosmetalicos
            // 
            this.Oxidosmetalicos.AutoSize = true;
            this.Oxidosmetalicos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Oxidosmetalicos.ForeColor = System.Drawing.SystemColors.InfoText;
            this.Oxidosmetalicos.Location = new System.Drawing.Point(405, 618);
            this.Oxidosmetalicos.Name = "Oxidosmetalicos";
            this.Oxidosmetalicos.Size = new System.Drawing.Size(143, 21);
            this.Oxidosmetalicos.TabIndex = 184;
            this.Oxidosmetalicos.TabStop = true;
            this.Oxidosmetalicos.Text = " Óxidos metálicos";
            this.Oxidosmetalicos.UseVisualStyleBackColor = true;
            this.Oxidosmetalicos.CheckedChanged += new System.EventHandler(this.Oxidosmetalicos_CheckedChanged);
            // 
            // OxidosNometalicos
            // 
            this.OxidosNometalicos.AutoSize = true;
            this.OxidosNometalicos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.OxidosNometalicos.Location = new System.Drawing.Point(582, 618);
            this.OxidosNometalicos.Name = "OxidosNometalicos";
            this.OxidosNometalicos.Size = new System.Drawing.Size(163, 21);
            this.OxidosNometalicos.TabIndex = 185;
            this.OxidosNometalicos.TabStop = true;
            this.OxidosNometalicos.Text = " Óxidos no metálicos";
            this.OxidosNometalicos.UseVisualStyleBackColor = true;
            this.OxidosNometalicos.CheckedChanged += new System.EventHandler(this.OxidosNometalicos_CheckedChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label36.Location = new System.Drawing.Point(226, 444);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(17, 19);
            this.label36.TabIndex = 190;
            this.label36.Text = "6";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label37.Location = new System.Drawing.Point(226, 502);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(17, 19);
            this.label37.TabIndex = 191;
            this.label37.Text = "7";
            // 
            // btnPeróxidos
            // 
            this.btnPeróxidos.AutoSize = true;
            this.btnPeróxidos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPeróxidos.Location = new System.Drawing.Point(779, 618);
            this.btnPeróxidos.Name = "btnPeróxidos";
            this.btnPeróxidos.Size = new System.Drawing.Size(91, 21);
            this.btnPeróxidos.TabIndex = 192;
            this.btnPeróxidos.TabStop = true;
            this.btnPeróxidos.Text = "Peróxidos";
            this.btnPeróxidos.UseVisualStyleBackColor = true;
            this.btnPeróxidos.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label38.Location = new System.Drawing.Point(74, 93);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(0, 19);
            this.label38.TabIndex = 193;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label39.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(1050, 98);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(13, 14);
            this.label39.TabIndex = 194;
            this.label39.Text = "6";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label40.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label40.ForeColor = System.Drawing.Color.Black;
            this.label40.Location = new System.Drawing.Point(1114, 157);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(19, 14);
            this.label40.TabIndex = 195;
            this.label40.Text = "15";
            this.label40.Click += new System.EventHandler(this.label40_Click_1);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label41.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label41.ForeColor = System.Drawing.Color.Red;
            this.label41.Location = new System.Drawing.Point(1196, 100);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(13, 14);
            this.label41.TabIndex = 196;
            this.label41.Text = "8";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label42.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label42.ForeColor = System.Drawing.Color.Red;
            this.label42.Location = new System.Drawing.Point(1120, 98);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(14, 15);
            this.label42.TabIndex = 197;
            this.label42.Text = "7";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label43.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label43.ForeColor = System.Drawing.Color.Black;
            this.label43.Location = new System.Drawing.Point(1189, 157);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(19, 14);
            this.label43.TabIndex = 198;
            this.label43.Text = "16";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label44.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label44.ForeColor = System.Drawing.Color.Black;
            this.label44.Location = new System.Drawing.Point(1189, 212);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(19, 14);
            this.label44.TabIndex = 199;
            this.label44.Text = "34";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Gold;
            this.label45.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(74, 98);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(14, 15);
            this.label45.TabIndex = 200;
            this.label45.Text = "3";
            this.label45.Click += new System.EventHandler(this.label45_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Gold;
            this.label46.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label46.Location = new System.Drawing.Point(69, 383);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(19, 14);
            this.label46.TabIndex = 201;
            this.label46.Text = "87";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.Gold;
            this.label47.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label47.ForeColor = System.Drawing.Color.Black;
            this.label47.Location = new System.Drawing.Point(69, 212);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(19, 14);
            this.label47.TabIndex = 202;
            this.label47.Text = "19";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Gold;
            this.label49.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label49.Location = new System.Drawing.Point(69, 326);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(19, 14);
            this.label49.TabIndex = 204;
            this.label49.Text = "55";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Gold;
            this.label50.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label50.ForeColor = System.Drawing.Color.Black;
            this.label50.Location = new System.Drawing.Point(69, 269);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(19, 14);
            this.label50.TabIndex = 205;
            this.label50.Text = "37";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Gold;
            this.label51.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label51.ForeColor = System.Drawing.Color.Black;
            this.label51.Location = new System.Drawing.Point(70, 157);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(18, 14);
            this.label51.TabIndex = 206;
            this.label51.Text = "11";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label48.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label48.ForeColor = System.Drawing.Color.Black;
            this.label48.Location = new System.Drawing.Point(149, 98);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(14, 15);
            this.label48.TabIndex = 207;
            this.label48.Text = "4";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label52.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label52.ForeColor = System.Drawing.Color.Black;
            this.label52.Location = new System.Drawing.Point(144, 157);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(19, 14);
            this.label52.TabIndex = 208;
            this.label52.Text = "12";
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label53.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label53.ForeColor = System.Drawing.Color.Black;
            this.label53.Location = new System.Drawing.Point(144, 326);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(19, 14);
            this.label53.TabIndex = 209;
            this.label53.Text = "56";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label54.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label54.ForeColor = System.Drawing.Color.Black;
            this.label54.Location = new System.Drawing.Point(144, 271);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(19, 14);
            this.label54.TabIndex = 210;
            this.label54.Text = "38";
            this.label54.Click += new System.EventHandler(this.label54_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label55.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label55.ForeColor = System.Drawing.Color.Black;
            this.label55.Location = new System.Drawing.Point(144, 211);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(19, 14);
            this.label55.TabIndex = 211;
            this.label55.Text = "20";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label56.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label56.ForeColor = System.Drawing.Color.Black;
            this.label56.Location = new System.Drawing.Point(144, 383);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(19, 14);
            this.label56.TabIndex = 212;
            this.label56.Text = "88";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label57.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label57.ForeColor = System.Drawing.Color.Black;
            this.label57.Location = new System.Drawing.Point(441, 212);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(19, 14);
            this.label57.TabIndex = 213;
            this.label57.Text = "24";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label58.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label58.ForeColor = System.Drawing.Color.Black;
            this.label58.Location = new System.Drawing.Point(295, 212);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(19, 14);
            this.label58.TabIndex = 214;
            this.label58.Text = "22";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label59.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label59.ForeColor = System.Drawing.Color.Black;
            this.label59.Location = new System.Drawing.Point(369, 212);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(19, 14);
            this.label59.TabIndex = 215;
            this.label59.Text = "23";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label60.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(520, 211);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(19, 14);
            this.label60.TabIndex = 216;
            this.label60.Text = "25";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label61.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label61.ForeColor = System.Drawing.Color.Black;
            this.label61.Location = new System.Drawing.Point(220, 211);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(19, 14);
            this.label61.TabIndex = 217;
            this.label61.Text = "21";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label62.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label62.ForeColor = System.Drawing.Color.Black;
            this.label62.Location = new System.Drawing.Point(818, 327);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(19, 14);
            this.label62.TabIndex = 218;
            this.label62.Text = "79";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label63.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label63.ForeColor = System.Drawing.Color.Black;
            this.label63.Location = new System.Drawing.Point(590, 211);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(19, 14);
            this.label63.TabIndex = 219;
            this.label63.Text = "26";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label64.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label64.ForeColor = System.Drawing.Color.White;
            this.label64.Location = new System.Drawing.Point(891, 385);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(24, 14);
            this.label64.TabIndex = 220;
            this.label64.Text = "112";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label65.Font = new System.Drawing.Font("Arial Black", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label65.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label65.Location = new System.Drawing.Point(892, 326);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(21, 15);
            this.label65.TabIndex = 221;
            this.label65.Text = "80";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label66.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label66.ForeColor = System.Drawing.Color.White;
            this.label66.Location = new System.Drawing.Point(813, 384);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(23, 14);
            this.label66.TabIndex = 222;
            this.label66.Text = "111";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label67.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label67.ForeColor = System.Drawing.Color.Black;
            this.label67.Location = new System.Drawing.Point(897, 271);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(19, 14);
            this.label67.TabIndex = 223;
            this.label67.Text = "48";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label68.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label68.ForeColor = System.Drawing.Color.Black;
            this.label68.Location = new System.Drawing.Point(665, 212);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(19, 14);
            this.label68.TabIndex = 224;
            this.label68.Text = "27";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label69.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label69.ForeColor = System.Drawing.Color.Black;
            this.label69.Location = new System.Drawing.Point(897, 212);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(19, 14);
            this.label69.TabIndex = 225;
            this.label69.Text = "30";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label70.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label70.ForeColor = System.Drawing.Color.Black;
            this.label70.Location = new System.Drawing.Point(818, 212);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(19, 14);
            this.label70.TabIndex = 226;
            this.label70.Text = "29";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label71.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label71.ForeColor = System.Drawing.Color.Black;
            this.label71.Location = new System.Drawing.Point(745, 211);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(19, 14);
            this.label71.TabIndex = 227;
            this.label71.Text = "28";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label72.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label72.ForeColor = System.Drawing.Color.Black;
            this.label72.Location = new System.Drawing.Point(590, 268);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(19, 14);
            this.label72.TabIndex = 228;
            this.label72.Text = "44";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label73.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label73.ForeColor = System.Drawing.Color.Black;
            this.label73.Location = new System.Drawing.Point(667, 269);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(19, 14);
            this.label73.TabIndex = 229;
            this.label73.Text = "45";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label74.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label74.ForeColor = System.Drawing.Color.Black;
            this.label74.Location = new System.Drawing.Point(818, 271);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(19, 14);
            this.label74.TabIndex = 230;
            this.label74.Text = "47";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label75.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label75.ForeColor = System.Drawing.Color.Black;
            this.label75.Location = new System.Drawing.Point(747, 271);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(15, 11);
            this.label75.TabIndex = 231;
            this.label75.Text = "46";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label76.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label76.ForeColor = System.Drawing.Color.White;
            this.label76.Location = new System.Drawing.Point(514, 385);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(25, 14);
            this.label76.TabIndex = 232;
            this.label76.Text = "107";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label77.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label77.ForeColor = System.Drawing.Color.White;
            this.label77.Location = new System.Drawing.Point(589, 383);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(25, 14);
            this.label77.TabIndex = 233;
            this.label77.Text = "108";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label78.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label78.ForeColor = System.Drawing.Color.Black;
            this.label78.Location = new System.Drawing.Point(294, 327);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(19, 14);
            this.label78.TabIndex = 234;
            this.label78.Text = "72";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label79.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label79.ForeColor = System.Drawing.Color.Black;
            this.label79.Location = new System.Drawing.Point(369, 327);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(19, 14);
            this.label79.TabIndex = 235;
            this.label79.Text = "73";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label80.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label80.ForeColor = System.Drawing.Color.Black;
            this.label80.Location = new System.Drawing.Point(444, 326);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(19, 14);
            this.label80.TabIndex = 236;
            this.label80.Text = "74";
            this.label80.Click += new System.EventHandler(this.label80_Click);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label81.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label81.ForeColor = System.Drawing.Color.Black;
            this.label81.Location = new System.Drawing.Point(519, 325);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(19, 14);
            this.label81.TabIndex = 237;
            this.label81.Text = "75";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label82.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label82.ForeColor = System.Drawing.Color.Black;
            this.label82.Location = new System.Drawing.Point(590, 325);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(19, 14);
            this.label82.TabIndex = 238;
            this.label82.Text = "76";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label83.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label83.ForeColor = System.Drawing.Color.Black;
            this.label83.Location = new System.Drawing.Point(670, 325);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(19, 14);
            this.label83.TabIndex = 239;
            this.label83.Text = "77";
            this.label83.Click += new System.EventHandler(this.label83_Click);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label84.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label84.ForeColor = System.Drawing.Color.Black;
            this.label84.Location = new System.Drawing.Point(745, 326);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(19, 14);
            this.label84.TabIndex = 240;
            this.label84.Text = "78";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label85.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label85.ForeColor = System.Drawing.Color.White;
            this.label85.Location = new System.Drawing.Point(667, 383);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(20, 11);
            this.label85.TabIndex = 241;
            this.label85.Text = "109";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label86.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label86.ForeColor = System.Drawing.Color.Black;
            this.label86.Location = new System.Drawing.Point(369, 268);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(19, 14);
            this.label86.TabIndex = 242;
            this.label86.Text = "41";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label87.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label87.ForeColor = System.Drawing.Color.Black;
            this.label87.Location = new System.Drawing.Point(444, 271);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(19, 14);
            this.label87.TabIndex = 243;
            this.label87.Text = "42";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label88.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label88.ForeColor = System.Drawing.Color.White;
            this.label88.Location = new System.Drawing.Point(437, 384);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(25, 14);
            this.label88.TabIndex = 244;
            this.label88.Text = "106";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label89.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label89.ForeColor = System.Drawing.Color.White;
            this.label89.Location = new System.Drawing.Point(737, 383);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(24, 14);
            this.label89.TabIndex = 245;
            this.label89.Text = "110";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label90.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label90.ForeColor = System.Drawing.Color.White;
            this.label90.Location = new System.Drawing.Point(367, 382);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(20, 11);
            this.label90.TabIndex = 246;
            this.label90.Text = "105";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label91.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label91.ForeColor = System.Drawing.Color.Black;
            this.label91.Location = new System.Drawing.Point(295, 270);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(19, 14);
            this.label91.TabIndex = 247;
            this.label91.Text = "40";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label92.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label92.ForeColor = System.Drawing.Color.Black;
            this.label92.Location = new System.Drawing.Point(218, 269);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(19, 14);
            this.label92.TabIndex = 248;
            this.label92.Text = "39";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label93.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label93.ForeColor = System.Drawing.Color.White;
            this.label93.Location = new System.Drawing.Point(293, 382);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(20, 11);
            this.label93.TabIndex = 249;
            this.label93.Text = "104";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label94.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label94.ForeColor = System.Drawing.Color.Black;
            this.label94.Location = new System.Drawing.Point(519, 269);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(19, 14);
            this.label94.TabIndex = 250;
            this.label94.Text = "43";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label95.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label95.ForeColor = System.Drawing.Color.Black;
            this.label95.Location = new System.Drawing.Point(975, 99);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(14, 15);
            this.label95.TabIndex = 251;
            this.label95.Text = "5";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label96.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label96.ForeColor = System.Drawing.Color.Black;
            this.label96.Location = new System.Drawing.Point(1189, 271);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(19, 14);
            this.label96.TabIndex = 252;
            this.label96.Text = "52";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label97.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label97.ForeColor = System.Drawing.Color.Black;
            this.label97.Location = new System.Drawing.Point(1115, 269);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(19, 14);
            this.label97.TabIndex = 253;
            this.label97.Text = "51";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label98.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label98.ForeColor = System.Drawing.Color.Black;
            this.label98.Location = new System.Drawing.Point(1115, 214);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(19, 14);
            this.label98.TabIndex = 254;
            this.label98.Text = "33";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label99.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label99.ForeColor = System.Drawing.Color.Black;
            this.label99.Location = new System.Drawing.Point(1044, 214);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(19, 14);
            this.label99.TabIndex = 255;
            this.label99.Text = "32";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label100.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label100.ForeColor = System.Drawing.Color.Black;
            this.label100.Location = new System.Drawing.Point(1043, 157);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(19, 14);
            this.label100.TabIndex = 256;
            this.label100.Text = "14";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label101.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label101.ForeColor = System.Drawing.Color.Black;
            this.label101.Location = new System.Drawing.Point(1194, 327);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(19, 14);
            this.label101.TabIndex = 257;
            this.label101.Text = "84";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.BackColor = System.Drawing.Color.SkyBlue;
            this.label102.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label102.ForeColor = System.Drawing.Color.Red;
            this.label102.Location = new System.Drawing.Point(1345, 40);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(13, 14);
            this.label102.TabIndex = 258;
            this.label102.Text = "2";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.BackColor = System.Drawing.Color.SkyBlue;
            this.label104.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label104.ForeColor = System.Drawing.Color.Red;
            this.label104.Location = new System.Drawing.Point(1341, 268);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(19, 14);
            this.label104.TabIndex = 260;
            this.label104.Text = "54";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.BackColor = System.Drawing.Color.SkyBlue;
            this.label105.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label105.ForeColor = System.Drawing.Color.White;
            this.label105.Location = new System.Drawing.Point(1335, 383);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(24, 14);
            this.label105.TabIndex = 261;
            this.label105.Text = "118";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.BackColor = System.Drawing.Color.SkyBlue;
            this.label106.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label106.ForeColor = System.Drawing.Color.Red;
            this.label106.Location = new System.Drawing.Point(1341, 326);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(19, 14);
            this.label106.TabIndex = 262;
            this.label106.Text = "86";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.BackColor = System.Drawing.Color.SkyBlue;
            this.label107.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label107.ForeColor = System.Drawing.Color.Red;
            this.label107.Location = new System.Drawing.Point(1341, 211);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(19, 14);
            this.label107.TabIndex = 263;
            this.label107.Text = "36";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.BackColor = System.Drawing.Color.SkyBlue;
            this.label108.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label108.ForeColor = System.Drawing.Color.Red;
            this.label108.Location = new System.Drawing.Point(1341, 155);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(19, 14);
            this.label108.TabIndex = 264;
            this.label108.Text = "18";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.BackColor = System.Drawing.Color.SkyBlue;
            this.label109.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label109.ForeColor = System.Drawing.Color.Red;
            this.label109.Location = new System.Drawing.Point(1345, 101);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(19, 14);
            this.label109.TabIndex = 265;
            this.label109.Text = "10";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.BackColor = System.Drawing.Color.DodgerBlue;
            this.label103.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label103.ForeColor = System.Drawing.Color.Red;
            this.label103.Location = new System.Drawing.Point(1272, 99);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(14, 15);
            this.label103.TabIndex = 266;
            this.label103.Text = "9";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.BackColor = System.Drawing.Color.DodgerBlue;
            this.label110.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label110.ForeColor = System.Drawing.Color.White;
            this.label110.Location = new System.Drawing.Point(1261, 385);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(24, 14);
            this.label110.TabIndex = 267;
            this.label110.Text = "117";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.BackColor = System.Drawing.Color.DodgerBlue;
            this.label111.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label111.ForeColor = System.Drawing.Color.Black;
            this.label111.Location = new System.Drawing.Point(1267, 328);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(19, 14);
            this.label111.TabIndex = 268;
            this.label111.Text = "85";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.BackColor = System.Drawing.Color.DodgerBlue;
            this.label112.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label112.ForeColor = System.Drawing.Color.Black;
            this.label112.Location = new System.Drawing.Point(1267, 271);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(19, 14);
            this.label112.TabIndex = 269;
            this.label112.Text = "53";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.BackColor = System.Drawing.Color.DodgerBlue;
            this.label113.Font = new System.Drawing.Font("Arial Black", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label113.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label113.Location = new System.Drawing.Point(1261, 212);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(21, 15);
            this.label113.TabIndex = 270;
            this.label113.Text = "35";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.BackColor = System.Drawing.Color.DodgerBlue;
            this.label114.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label114.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label114.Location = new System.Drawing.Point(1267, 157);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(19, 14);
            this.label114.TabIndex = 271;
            this.label114.Text = "17";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.BackColor = System.Drawing.Color.Purple;
            this.label115.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label115.ForeColor = System.Drawing.Color.Black;
            this.label115.Location = new System.Drawing.Point(216, 382);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(19, 23);
            this.label115.TabIndex = 272;
            this.label115.Text = "*";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.BackColor = System.Drawing.Color.Violet;
            this.label116.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label116.ForeColor = System.Drawing.Color.Black;
            this.label116.Location = new System.Drawing.Point(218, 327);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(15, 19);
            this.label116.TabIndex = 273;
            this.label116.Text = "*";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.BackColor = System.Drawing.Color.Purple;
            this.label117.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label117.ForeColor = System.Drawing.Color.Black;
            this.label117.Location = new System.Drawing.Point(294, 507);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(19, 14);
            this.label117.TabIndex = 274;
            this.label117.Text = "89";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.BackColor = System.Drawing.Color.Purple;
            this.label118.Font = new System.Drawing.Font("Bahnschrift Condensed", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label118.ForeColor = System.Drawing.Color.Black;
            this.label118.Location = new System.Drawing.Point(1196, 509);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(18, 13);
            this.label118.TabIndex = 275;
            this.label118.Text = "101";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.BackColor = System.Drawing.Color.Purple;
            this.label119.Font = new System.Drawing.Font("Arial", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label119.ForeColor = System.Drawing.Color.Black;
            this.label119.Location = new System.Drawing.Point(1108, 507);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(23, 12);
            this.label119.TabIndex = 276;
            this.label119.Text = "100";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.BackColor = System.Drawing.Color.Purple;
            this.label120.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label120.ForeColor = System.Drawing.Color.Black;
            this.label120.Location = new System.Drawing.Point(1043, 507);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(19, 14);
            this.label120.TabIndex = 277;
            this.label120.Text = "99";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.BackColor = System.Drawing.Color.Purple;
            this.label121.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label121.ForeColor = System.Drawing.Color.Black;
            this.label121.Location = new System.Drawing.Point(969, 507);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(15, 11);
            this.label121.TabIndex = 278;
            this.label121.Text = "98";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.BackColor = System.Drawing.Color.Purple;
            this.label122.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label122.ForeColor = System.Drawing.Color.Black;
            this.label122.Location = new System.Drawing.Point(892, 507);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(19, 14);
            this.label122.TabIndex = 279;
            this.label122.Text = "97";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.BackColor = System.Drawing.Color.Purple;
            this.label123.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label123.ForeColor = System.Drawing.Color.Black;
            this.label123.Location = new System.Drawing.Point(818, 507);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(19, 14);
            this.label123.TabIndex = 280;
            this.label123.Text = "96";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.BackColor = System.Drawing.Color.Purple;
            this.label124.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label124.ForeColor = System.Drawing.Color.Black;
            this.label124.Location = new System.Drawing.Point(743, 509);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(19, 14);
            this.label124.TabIndex = 281;
            this.label124.Text = "95";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.BackColor = System.Drawing.Color.Purple;
            this.label125.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label125.ForeColor = System.Drawing.Color.Black;
            this.label125.Location = new System.Drawing.Point(665, 507);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(19, 14);
            this.label125.TabIndex = 282;
            this.label125.Text = "94";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.BackColor = System.Drawing.Color.Purple;
            this.label126.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label126.ForeColor = System.Drawing.Color.Black;
            this.label126.Location = new System.Drawing.Point(590, 507);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(19, 14);
            this.label126.TabIndex = 283;
            this.label126.Text = "93";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.BackColor = System.Drawing.Color.Purple;
            this.label127.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label127.ForeColor = System.Drawing.Color.Black;
            this.label127.Location = new System.Drawing.Point(514, 507);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(19, 14);
            this.label127.TabIndex = 284;
            this.label127.Text = "92";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.BackColor = System.Drawing.Color.Purple;
            this.label128.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label128.ForeColor = System.Drawing.Color.Black;
            this.label128.Location = new System.Drawing.Point(441, 507);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(19, 14);
            this.label128.TabIndex = 285;
            this.label128.Text = "91";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.BackColor = System.Drawing.Color.Purple;
            this.label129.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label129.ForeColor = System.Drawing.Color.Black;
            this.label129.Location = new System.Drawing.Point(369, 507);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(19, 14);
            this.label129.TabIndex = 286;
            this.label129.Text = "90";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.BackColor = System.Drawing.Color.Purple;
            this.label130.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label130.ForeColor = System.Drawing.Color.Black;
            this.label130.Location = new System.Drawing.Point(1332, 507);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(25, 14);
            this.label130.TabIndex = 287;
            this.label130.Text = "103";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.BackColor = System.Drawing.Color.Purple;
            this.label131.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label131.ForeColor = System.Drawing.Color.Black;
            this.label131.Location = new System.Drawing.Point(1260, 507);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(25, 14);
            this.label131.TabIndex = 288;
            this.label131.Text = "102";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.BackColor = System.Drawing.Color.Violet;
            this.label132.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label132.ForeColor = System.Drawing.Color.Black;
            this.label132.Location = new System.Drawing.Point(369, 449);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(19, 14);
            this.label132.TabIndex = 289;
            this.label132.Text = "58";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.BackColor = System.Drawing.Color.Violet;
            this.label133.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label133.ForeColor = System.Drawing.Color.Black;
            this.label133.Location = new System.Drawing.Point(294, 449);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(19, 14);
            this.label133.TabIndex = 290;
            this.label133.Text = "57";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.BackColor = System.Drawing.Color.Violet;
            this.label134.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label134.ForeColor = System.Drawing.Color.Black;
            this.label134.Location = new System.Drawing.Point(588, 451);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(19, 14);
            this.label134.TabIndex = 291;
            this.label134.Text = "61";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.BackColor = System.Drawing.Color.Violet;
            this.label135.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label135.ForeColor = System.Drawing.Color.Black;
            this.label135.Location = new System.Drawing.Point(1117, 451);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(19, 14);
            this.label135.TabIndex = 292;
            this.label135.Text = "68";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.BackColor = System.Drawing.Color.Violet;
            this.label136.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label136.ForeColor = System.Drawing.Color.Black;
            this.label136.Location = new System.Drawing.Point(441, 451);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(19, 14);
            this.label136.TabIndex = 293;
            this.label136.Text = "59";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.BackColor = System.Drawing.Color.Violet;
            this.label137.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label137.ForeColor = System.Drawing.Color.Black;
            this.label137.Location = new System.Drawing.Point(1339, 449);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(19, 14);
            this.label137.TabIndex = 294;
            this.label137.Text = "71";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.BackColor = System.Drawing.Color.Violet;
            this.label138.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label138.ForeColor = System.Drawing.Color.Black;
            this.label138.Location = new System.Drawing.Point(1266, 451);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(19, 14);
            this.label138.TabIndex = 295;
            this.label138.Text = "70";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.BackColor = System.Drawing.Color.Violet;
            this.label139.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label139.ForeColor = System.Drawing.Color.Black;
            this.label139.Location = new System.Drawing.Point(1189, 449);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(19, 14);
            this.label139.TabIndex = 296;
            this.label139.Text = "69";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.BackColor = System.Drawing.Color.Violet;
            this.label140.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label140.ForeColor = System.Drawing.Color.Black;
            this.label140.Location = new System.Drawing.Point(521, 449);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(15, 11);
            this.label140.TabIndex = 297;
            this.label140.Text = "60";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.BackColor = System.Drawing.Color.Violet;
            this.label141.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label141.ForeColor = System.Drawing.Color.Black;
            this.label141.Location = new System.Drawing.Point(1044, 449);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(19, 14);
            this.label141.TabIndex = 298;
            this.label141.Text = "67";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.BackColor = System.Drawing.Color.Violet;
            this.label142.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label142.ForeColor = System.Drawing.Color.Black;
            this.label142.Location = new System.Drawing.Point(665, 451);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(19, 14);
            this.label142.TabIndex = 299;
            this.label142.Text = "62";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.BackColor = System.Drawing.Color.Violet;
            this.label143.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label143.ForeColor = System.Drawing.Color.Black;
            this.label143.Location = new System.Drawing.Point(821, 451);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(15, 11);
            this.label143.TabIndex = 300;
            this.label143.Text = "64";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.BackColor = System.Drawing.Color.Violet;
            this.label144.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label144.ForeColor = System.Drawing.Color.Black;
            this.label144.Location = new System.Drawing.Point(737, 451);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(19, 14);
            this.label144.TabIndex = 301;
            this.label144.Text = "63";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.BackColor = System.Drawing.Color.Violet;
            this.label145.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label145.ForeColor = System.Drawing.Color.Black;
            this.label145.Location = new System.Drawing.Point(965, 449);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(19, 14);
            this.label145.TabIndex = 302;
            this.label145.Text = "66";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.BackColor = System.Drawing.Color.Violet;
            this.label146.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label146.ForeColor = System.Drawing.Color.Black;
            this.label146.Location = new System.Drawing.Point(895, 449);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(19, 14);
            this.label146.TabIndex = 303;
            this.label146.Text = "65";
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label147.Font = new System.Drawing.Font("Bahnschrift Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label147.ForeColor = System.Drawing.Color.Black;
            this.label147.Location = new System.Drawing.Point(972, 157);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(15, 14);
            this.label147.TabIndex = 304;
            this.label147.Text = "13";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label148.Font = new System.Drawing.Font("Bahnschrift Condensed", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label148.ForeColor = System.Drawing.Color.Black;
            this.label148.Location = new System.Drawing.Point(1120, 326);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(17, 14);
            this.label148.TabIndex = 305;
            this.label148.Text = "83";
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label149.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label149.ForeColor = System.Drawing.Color.Black;
            this.label149.Location = new System.Drawing.Point(1043, 328);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(19, 14);
            this.label149.TabIndex = 306;
            this.label149.Text = "82";
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label150.Font = new System.Drawing.Font("Bahnschrift Condensed", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label150.ForeColor = System.Drawing.Color.Black;
            this.label150.Location = new System.Drawing.Point(969, 327);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(15, 14);
            this.label150.TabIndex = 307;
            this.label150.Text = "81";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label151.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label151.ForeColor = System.Drawing.Color.Black;
            this.label151.Location = new System.Drawing.Point(1043, 271);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(19, 14);
            this.label151.TabIndex = 308;
            this.label151.Text = "50";
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label152.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label152.ForeColor = System.Drawing.Color.Black;
            this.label152.Location = new System.Drawing.Point(969, 268);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(19, 14);
            this.label152.TabIndex = 309;
            this.label152.Text = "49";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label153.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label153.ForeColor = System.Drawing.Color.Black;
            this.label153.Location = new System.Drawing.Point(965, 212);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(19, 14);
            this.label153.TabIndex = 310;
            this.label153.Text = "31";
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label154.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label154.ForeColor = System.Drawing.Color.White;
            this.label154.Location = new System.Drawing.Point(1183, 383);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(24, 14);
            this.label154.TabIndex = 311;
            this.label154.Text = "116";
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label155.Font = new System.Drawing.Font("Bahnschrift SemiBold SemiConden", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label155.ForeColor = System.Drawing.Color.White;
            this.label155.Location = new System.Drawing.Point(1114, 382);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(21, 14);
            this.label155.TabIndex = 312;
            this.label155.Text = "115";
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label156.Font = new System.Drawing.Font("Bahnschrift Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label156.ForeColor = System.Drawing.Color.White;
            this.label156.Location = new System.Drawing.Point(1042, 383);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(18, 14);
            this.label156.TabIndex = 313;
            this.label156.Text = "114";
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label157.Font = new System.Drawing.Font("Bahnschrift Condensed", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label157.ForeColor = System.Drawing.Color.White;
            this.label157.Location = new System.Drawing.Point(965, 383);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(18, 14);
            this.label157.TabIndex = 314;
            this.label157.Text = "113";
            // 
            // btnGasesNobles
            // 
            this.btnGasesNobles.AccessibleName = "";
            this.btnGasesNobles.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.btnGasesNobles.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnGasesNobles.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnGasesNobles.Location = new System.Drawing.Point(125, 616);
            this.btnGasesNobles.Name = "btnGasesNobles";
            this.btnGasesNobles.Size = new System.Drawing.Size(95, 24);
            this.btnGasesNobles.TabIndex = 315;
            this.btnGasesNobles.Text = "Gases nobles";
            this.btnGasesNobles.UseVisualStyleBackColor = true;
            this.btnGasesNobles.Click += new System.EventHandler(this.btnGasesNobles_Click);
            // 
            // labelCategoria
            // 
            this.labelCategoria.AutoSize = true;
            this.labelCategoria.Font = new System.Drawing.Font("Arial", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelCategoria.Location = new System.Drawing.Point(24, 502);
            this.labelCategoria.Name = "labelCategoria";
            this.labelCategoria.Size = new System.Drawing.Size(154, 35);
            this.labelCategoria.TabIndex = 316;
            this.labelCategoria.Text = "Categoria";
            this.labelCategoria.Click += new System.EventHandler(this.labelCategoria_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBox1.Location = new System.Drawing.Point(989, 577);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(136, 33);
            this.checkBox1.TabIndex = 319;
            this.checkBox1.Text = "Aleatorio";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(133, 23);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(15, 10);
            this.button2.TabIndex = 320;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.button3.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button3.Location = new System.Drawing.Point(12, 650);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(95, 27);
            this.button3.TabIndex = 321;
            this.button3.Text = "Todos";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label34.Font = new System.Drawing.Font("Arial Black", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label34.Location = new System.Drawing.Point(180, 4);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(629, 56);
            this.label34.TabIndex = 322;
            this.label34.Text = "Tabla Periódica De Los Elementos";
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // Ozonidos
            // 
            this.Ozonidos.AutoSize = true;
            this.Ozonidos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Ozonidos.Location = new System.Drawing.Point(779, 649);
            this.Ozonidos.Name = "Ozonidos";
            this.Ozonidos.Size = new System.Drawing.Size(89, 21);
            this.Ozonidos.TabIndex = 323;
            this.Ozonidos.TabStop = true;
            this.Ozonidos.Text = "Ozónidos";
            this.Ozonidos.UseVisualStyleBackColor = true;
            this.Ozonidos.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_2);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.button4.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button4.Location = new System.Drawing.Point(12, 616);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(95, 24);
            this.button4.TabIndex = 324;
            this.button4.Text = "Ozónidos";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Hidruros
            // 
            this.Hidruros.AutoSize = true;
            this.Hidruros.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Hidruros.Location = new System.Drawing.Point(779, 679);
            this.Hidruros.Name = "Hidruros";
            this.Hidruros.Size = new System.Drawing.Size(81, 21);
            this.Hidruros.TabIndex = 325;
            this.Hidruros.TabStop = true;
            this.Hidruros.Text = "Hidruros";
            this.Hidruros.UseVisualStyleBackColor = true;
            this.Hidruros.CheckedChanged += new System.EventHandler(this.Hidruros_CheckedChanged);
            // 
            // ValPeroxido
            // 
            this.ValPeroxido.Location = new System.Drawing.Point(474, 129);
            this.ValPeroxido.Name = "ValPeroxido";
            this.ValPeroxido.Size = new System.Drawing.Size(38, 47);
            this.ValPeroxido.TabIndex = 326;
            this.ValPeroxido.TextChanged += new System.EventHandler(this.ValPeroxido_TextChanged);
            // 
            // gaseosos
            // 
            this.gaseosos.AutoSize = true;
            this.gaseosos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.gaseosos.Location = new System.Drawing.Point(1043, 678);
            this.gaseosos.Name = "gaseosos";
            this.gaseosos.Size = new System.Drawing.Size(43, 21);
            this.gaseosos.TabIndex = 331;
            this.gaseosos.Text = "aq";
            this.gaseosos.UseVisualStyleBackColor = true;
            this.gaseosos.CheckedChanged += new System.EventHandler(this.gaseosos_CheckedChanged);
            // 
            // acidos
            // 
            this.acidos.AutoSize = true;
            this.acidos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.acidos.Location = new System.Drawing.Point(1094, 679);
            this.acidos.Name = "acidos";
            this.acidos.Size = new System.Drawing.Size(43, 21);
            this.acidos.TabIndex = 330;
            this.acidos.Text = "ac";
            this.acidos.UseVisualStyleBackColor = true;
            this.acidos.CheckedChanged += new System.EventHandler(this.acidos_CheckedChanged);
            // 
            // Hidracidos
            // 
            this.Hidracidos.AutoSize = true;
            this.Hidracidos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Hidracidos.Location = new System.Drawing.Point(1039, 647);
            this.Hidracidos.Name = "Hidracidos";
            this.Hidracidos.Size = new System.Drawing.Size(95, 21);
            this.Hidracidos.TabIndex = 329;
            this.Hidracidos.TabStop = true;
            this.Hidracidos.Text = "Hidrácidos";
            this.Hidracidos.UseVisualStyleBackColor = true;
            this.Hidracidos.CheckedChanged += new System.EventHandler(this.Hidracidos_CheckedChanged);
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.button5.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button5.Location = new System.Drawing.Point(125, 584);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(95, 24);
            this.button5.TabIndex = 332;
            this.button5.Text = "Hidracidos";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Hidroxidos
            // 
            this.Hidroxidos.AutoSize = true;
            this.Hidroxidos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Hidroxidos.Location = new System.Drawing.Point(902, 618);
            this.Hidroxidos.Name = "Hidroxidos";
            this.Hidroxidos.Size = new System.Drawing.Size(94, 21);
            this.Hidroxidos.TabIndex = 333;
            this.Hidroxidos.TabStop = true;
            this.Hidroxidos.Text = "Hidróxidos";
            this.Hidroxidos.UseVisualStyleBackColor = true;
            this.Hidroxidos.CheckedChanged += new System.EventHandler(this.Hidroxidos_CheckedChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label32.Location = new System.Drawing.Point(688, 75);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 16);
            this.label32.TabIndex = 337;
            this.label32.Text = "Valencia";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label33.Location = new System.Drawing.Point(586, 75);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(41, 16);
            this.label33.TabIndex = 336;
            this.label33.Text = "Sigla";
            // 
            // Valencia3
            // 
            this.Valencia3.Location = new System.Drawing.Point(699, 93);
            this.Valencia3.Name = "Valencia3";
            this.Valencia3.Size = new System.Drawing.Size(59, 47);
            this.Valencia3.TabIndex = 335;
            // 
            // Sigla3
            // 
            this.Sigla3.Location = new System.Drawing.Point(586, 93);
            this.Sigla3.Name = "Sigla3";
            this.Sigla3.Size = new System.Drawing.Size(54, 47);
            this.Sigla3.TabIndex = 334;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label35.Location = new System.Drawing.Point(845, 75);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(65, 16);
            this.label35.TabIndex = 341;
            this.label35.Text = "Valencia";
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label158.Location = new System.Drawing.Point(786, 75);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(41, 16);
            this.label158.TabIndex = 340;
            this.label158.Text = "Sigla";
            // 
            // sigla4
            // 
            this.sigla4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.sigla4.Location = new System.Drawing.Point(786, 97);
            this.sigla4.Name = "sigla4";
            this.sigla4.Size = new System.Drawing.Size(53, 47);
            this.sigla4.TabIndex = 338;
            // 
            // btnTioacidos
            // 
            this.btnTioacidos.AutoSize = true;
            this.btnTioacidos.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTioacidos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnTioacidos.Location = new System.Drawing.Point(582, 649);
            this.btnTioacidos.Name = "btnTioacidos";
            this.btnTioacidos.Size = new System.Drawing.Size(88, 21);
            this.btnTioacidos.TabIndex = 342;
            this.btnTioacidos.TabStop = true;
            this.btnTioacidos.Text = "Tioacidos";
            this.btnTioacidos.UseVisualStyleBackColor = false;
            this.btnTioacidos.CheckedChanged += new System.EventHandler(this.btnTioacidos_CheckedChanged);
            // 
            // listBox2
            // 
            this.listBox2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 28;
            this.listBox2.Location = new System.Drawing.Point(110, 54);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(24, 4);
            this.listBox2.TabIndex = 343;
            // 
            // listBox4
            // 
            this.listBox4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 28;
            this.listBox4.Location = new System.Drawing.Point(150, 56);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(24, 4);
            this.listBox4.TabIndex = 344;
            // 
            // btnSuperOxidos
            // 
            this.btnSuperOxidos.AutoSize = true;
            this.btnSuperOxidos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSuperOxidos.Location = new System.Drawing.Point(405, 679);
            this.btnSuperOxidos.Name = "btnSuperOxidos";
            this.btnSuperOxidos.Size = new System.Drawing.Size(107, 21);
            this.btnSuperOxidos.TabIndex = 345;
            this.btnSuperOxidos.TabStop = true;
            this.btnSuperOxidos.Text = "Superóxidos";
            this.btnSuperOxidos.UseVisualStyleBackColor = true;
            this.btnSuperOxidos.CheckedChanged += new System.EventHandler(this.btnSuperOxidos_CheckedChanged);
            // 
            // btnOxacidos
            // 
            this.btnOxacidos.AutoSize = true;
            this.btnOxacidos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnOxacidos.Location = new System.Drawing.Point(902, 649);
            this.btnOxacidos.Name = "btnOxacidos";
            this.btnOxacidos.Size = new System.Drawing.Size(88, 21);
            this.btnOxacidos.TabIndex = 346;
            this.btnOxacidos.TabStop = true;
            this.btnOxacidos.Text = "Oxácidos";
            this.btnOxacidos.UseVisualStyleBackColor = true;
            this.btnOxacidos.CheckedChanged += new System.EventHandler(this.btnOxacidos_CheckedChanged);
            // 
            // btnSalesNeutras
            // 
            this.btnSalesNeutras.AutoSize = true;
            this.btnSalesNeutras.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSalesNeutras.Location = new System.Drawing.Point(1039, 616);
            this.btnSalesNeutras.Name = "btnSalesNeutras";
            this.btnSalesNeutras.Size = new System.Drawing.Size(116, 21);
            this.btnSalesNeutras.TabIndex = 347;
            this.btnSalesNeutras.TabStop = true;
            this.btnSalesNeutras.Text = "Sales neutras";
            this.btnSalesNeutras.UseVisualStyleBackColor = true;
            this.btnSalesNeutras.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // btnSalesAcidas
            // 
            this.btnSalesAcidas.AutoSize = true;
            this.btnSalesAcidas.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSalesAcidas.Location = new System.Drawing.Point(902, 679);
            this.btnSalesAcidas.Name = "btnSalesAcidas";
            this.btnSalesAcidas.Size = new System.Drawing.Size(110, 21);
            this.btnSalesAcidas.TabIndex = 348;
            this.btnSalesAcidas.TabStop = true;
            this.btnSalesAcidas.Text = "Sales acidas";
            this.btnSalesAcidas.UseVisualStyleBackColor = true;
            this.btnSalesAcidas.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // btnSalesBasiscas
            // 
            this.btnSalesBasiscas.AutoSize = true;
            this.btnSalesBasiscas.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSalesBasiscas.Location = new System.Drawing.Point(582, 679);
            this.btnSalesBasiscas.Name = "btnSalesBasiscas";
            this.btnSalesBasiscas.Size = new System.Drawing.Size(118, 21);
            this.btnSalesBasiscas.TabIndex = 349;
            this.btnSalesBasiscas.TabStop = true;
            this.btnSalesBasiscas.Text = "Sales básicas";
            this.btnSalesBasiscas.UseVisualStyleBackColor = true;
            this.btnSalesBasiscas.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // btnPeroxoacidos
            // 
            this.btnPeroxoacidos.AutoSize = true;
            this.btnPeroxoacidos.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPeroxoacidos.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnPeroxoacidos.Location = new System.Drawing.Point(405, 650);
            this.btnPeroxoacidos.Name = "btnPeroxoacidos";
            this.btnPeroxoacidos.Size = new System.Drawing.Size(115, 21);
            this.btnPeroxoacidos.TabIndex = 350;
            this.btnPeroxoacidos.TabStop = true;
            this.btnPeroxoacidos.Text = "Peroxoácidos";
            this.btnPeroxoacidos.UseVisualStyleBackColor = true;
            this.btnPeroxoacidos.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label29.Location = new System.Drawing.Point(74, 17);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(17, 19);
            this.label29.TabIndex = 351;
            this.label29.Text = "1";
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label159.Font = new System.Drawing.Font("Bahnschrift Condensed", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label159.Location = new System.Drawing.Point(676, 570);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(181, 29);
            this.label159.TabIndex = 352;
            this.label159.Text = "Reacciones químicas";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Location = new System.Drawing.Point(389, 571);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 159);
            this.panel1.TabIndex = 353;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Location = new System.Drawing.Point(1177, 561);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 182);
            this.panel2.TabIndex = 354;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Location = new System.Drawing.Point(390, 561);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(790, 10);
            this.panel3.TabIndex = 354;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel4.Location = new System.Drawing.Point(399, 720);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(781, 10);
            this.panel4.TabIndex = 355;
            // 
            // listBox5
            // 
            this.listBox5.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listBox5.FormattingEnabled = true;
            this.listBox5.ItemHeight = 28;
            this.listBox5.Location = new System.Drawing.Point(152, 23);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(20, 4);
            this.listBox5.TabIndex = 356;
            // 
            // listBox6
            // 
            this.listBox6.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listBox6.FormattingEnabled = true;
            this.listBox6.ItemHeight = 28;
            this.listBox6.Location = new System.Drawing.Point(150, 36);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(22, 4);
            this.listBox6.TabIndex = 357;
            // 
            // listBox7
            // 
            this.listBox7.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listBox7.FormattingEnabled = true;
            this.listBox7.ItemHeight = 28;
            this.listBox7.Location = new System.Drawing.Point(150, 46);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(22, 4);
            this.listBox7.TabIndex = 358;
            // 
            // button6
            // 
            this.button6.AccessibleName = "";
            this.button6.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button6.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button6.Location = new System.Drawing.Point(125, 653);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(95, 24);
            this.button6.TabIndex = 359;
            this.button6.Text = "Peroxoácidos";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.AccessibleName = "";
            this.button7.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button7.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button7.Location = new System.Drawing.Point(242, 585);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(95, 24);
            this.button7.TabIndex = 360;
            this.button7.Text = "SalesBásicas";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.AccessibleName = "";
            this.button8.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button8.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button8.Location = new System.Drawing.Point(245, 617);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(95, 24);
            this.button8.TabIndex = 361;
            this.button8.Text = "SalesNeutras";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // valencia4
            // 
            this.valencia4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.valencia4.Location = new System.Drawing.Point(860, 98);
            this.valencia4.Name = "valencia4";
            this.valencia4.Size = new System.Drawing.Size(53, 47);
            this.valencia4.TabIndex = 363;
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.button9.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button9.Location = new System.Drawing.Point(590, 151);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(137, 34);
            this.button9.TabIndex = 364;
            this.button9.Text = "Resultado";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = global::proyectoPrueba.Properties.Resources.Fondo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 726);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.valencia4);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.listBox7);
            this.Controls.Add(this.listBox6);
            this.Controls.Add(this.listBox5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label159);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.btnPeroxoacidos);
            this.Controls.Add(this.btnSalesBasiscas);
            this.Controls.Add(this.btnSalesAcidas);
            this.Controls.Add(this.btnSalesNeutras);
            this.Controls.Add(this.btnOxacidos);
            this.Controls.Add(this.btnSuperOxidos);
            this.Controls.Add(this.listBox4);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.btnTioacidos);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label158);
            this.Controls.Add(this.sigla4);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.Valencia3);
            this.Controls.Add(this.Sigla3);
            this.Controls.Add(this.Hidroxidos);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.gaseosos);
            this.Controls.Add(this.acidos);
            this.Controls.Add(this.Hidracidos);
            this.Controls.Add(this.ValPeroxido);
            this.Controls.Add(this.Hidruros);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.Ozonidos);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.labelCategoria);
            this.Controls.Add(this.btnGasesNobles);
            this.Controls.Add(this.label157);
            this.Controls.Add(this.label156);
            this.Controls.Add(this.label155);
            this.Controls.Add(this.label154);
            this.Controls.Add(this.label153);
            this.Controls.Add(this.label152);
            this.Controls.Add(this.label151);
            this.Controls.Add(this.label150);
            this.Controls.Add(this.label149);
            this.Controls.Add(this.label148);
            this.Controls.Add(this.label147);
            this.Controls.Add(this.label146);
            this.Controls.Add(this.label145);
            this.Controls.Add(this.label144);
            this.Controls.Add(this.label143);
            this.Controls.Add(this.label142);
            this.Controls.Add(this.label141);
            this.Controls.Add(this.label140);
            this.Controls.Add(this.label139);
            this.Controls.Add(this.label138);
            this.Controls.Add(this.label137);
            this.Controls.Add(this.label136);
            this.Controls.Add(this.label135);
            this.Controls.Add(this.label134);
            this.Controls.Add(this.label133);
            this.Controls.Add(this.label132);
            this.Controls.Add(this.label131);
            this.Controls.Add(this.label130);
            this.Controls.Add(this.label129);
            this.Controls.Add(this.label128);
            this.Controls.Add(this.label127);
            this.Controls.Add(this.label126);
            this.Controls.Add(this.label125);
            this.Controls.Add(this.label124);
            this.Controls.Add(this.label123);
            this.Controls.Add(this.label122);
            this.Controls.Add(this.label121);
            this.Controls.Add(this.label120);
            this.Controls.Add(this.label119);
            this.Controls.Add(this.label118);
            this.Controls.Add(this.label117);
            this.Controls.Add(this.label116);
            this.Controls.Add(this.label115);
            this.Controls.Add(this.label114);
            this.Controls.Add(this.label113);
            this.Controls.Add(this.label112);
            this.Controls.Add(this.label111);
            this.Controls.Add(this.label110);
            this.Controls.Add(this.label103);
            this.Controls.Add(this.label109);
            this.Controls.Add(this.label108);
            this.Controls.Add(this.label107);
            this.Controls.Add(this.label106);
            this.Controls.Add(this.label105);
            this.Controls.Add(this.label104);
            this.Controls.Add(this.label102);
            this.Controls.Add(this.label101);
            this.Controls.Add(this.label100);
            this.Controls.Add(this.label99);
            this.Controls.Add(this.label98);
            this.Controls.Add(this.label97);
            this.Controls.Add(this.label96);
            this.Controls.Add(this.label95);
            this.Controls.Add(this.label94);
            this.Controls.Add(this.label93);
            this.Controls.Add(this.label92);
            this.Controls.Add(this.label91);
            this.Controls.Add(this.label90);
            this.Controls.Add(this.label89);
            this.Controls.Add(this.label88);
            this.Controls.Add(this.label87);
            this.Controls.Add(this.label86);
            this.Controls.Add(this.label85);
            this.Controls.Add(this.label84);
            this.Controls.Add(this.label83);
            this.Controls.Add(this.label82);
            this.Controls.Add(this.label81);
            this.Controls.Add(this.label80);
            this.Controls.Add(this.label79);
            this.Controls.Add(this.label78);
            this.Controls.Add(this.label77);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.btnPeróxidos);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.OxidosNometalicos);
            this.Controls.Add(this.Oxidosmetalicos);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labelResultado);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.valenciaB);
            this.Controls.Add(this.valenciaA);
            this.Controls.Add(this.siglaB);
            this.Controls.Add(this.siglaA);
            this.Controls.Add(this.btnMetaloides);
            this.Controls.Add(this.btnNometales);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnLr);
            this.Controls.Add(this.btnNo);
            this.Controls.Add(this.btnLu);
            this.Controls.Add(this.btnYb);
            this.Controls.Add(this.btnMd);
            this.Controls.Add(this.btnFm);
            this.Controls.Add(this.btnEs);
            this.Controls.Add(this.btnCf);
            this.Controls.Add(this.btnBk);
            this.Controls.Add(this.btnA);
            this.Controls.Add(this.btnAm);
            this.Controls.Add(this.btnPu);
            this.Controls.Add(this.btnNp);
            this.Controls.Add(this.btnU);
            this.Controls.Add(this.btnPa);
            this.Controls.Add(this.btnTh);
            this.Controls.Add(this.btnAc);
            this.Controls.Add(this.btnTm);
            this.Controls.Add(this.btnEr);
            this.Controls.Add(this.btnHo);
            this.Controls.Add(this.btnDy);
            this.Controls.Add(this.btnTb);
            this.Controls.Add(this.btnGd);
            this.Controls.Add(this.btnEu);
            this.Controls.Add(this.btnSm);
            this.Controls.Add(this.btnPm);
            this.Controls.Add(this.btnNd);
            this.Controls.Add(this.btnPr);
            this.Controls.Add(this.btnCe);
            this.Controls.Add(this.btnLa);
            this.Controls.Add(this.btnOg);
            this.Controls.Add(this.btnTs);
            this.Controls.Add(this.btnRn);
            this.Controls.Add(this.btnAt);
            this.Controls.Add(this.btnXe);
            this.Controls.Add(this.btnI);
            this.Controls.Add(this.btnKr);
            this.Controls.Add(this.btnBr);
            this.Controls.Add(this.btnAr);
            this.Controls.Add(this.btnCl);
            this.Controls.Add(this.btnLv);
            this.Controls.Add(this.btnMc);
            this.Controls.Add(this.btnFl);
            this.Controls.Add(this.btnNh);
            this.Controls.Add(this.btnCn);
            this.Controls.Add(this.btnRg);
            this.Controls.Add(this.btnDs);
            this.Controls.Add(this.btnMt);
            this.Controls.Add(this.btnHs);
            this.Controls.Add(this.btnBh);
            this.Controls.Add(this.btnSg);
            this.Controls.Add(this.btnDb);
            this.Controls.Add(this.btnRf);
            this.Controls.Add(this.btnX1);
            this.Controls.Add(this.btnRa);
            this.Controls.Add(this.btnFr);
            this.Controls.Add(this.btnPo);
            this.Controls.Add(this.btnBi);
            this.Controls.Add(this.btnPb);
            this.Controls.Add(this.btnTl);
            this.Controls.Add(this.btnHg);
            this.Controls.Add(this.btnAu);
            this.Controls.Add(this.btnPt);
            this.Controls.Add(this.btnIr);
            this.Controls.Add(this.btnOs);
            this.Controls.Add(this.btnRe);
            this.Controls.Add(this.btnW);
            this.Controls.Add(this.btnTa);
            this.Controls.Add(this.btnHf);
            this.Controls.Add(this.btnX0);
            this.Controls.Add(this.btnBa);
            this.Controls.Add(this.btnCs);
            this.Controls.Add(this.btnTe);
            this.Controls.Add(this.btnSb);
            this.Controls.Add(this.btnSn);
            this.Controls.Add(this.btnIn);
            this.Controls.Add(this.btnCd);
            this.Controls.Add(this.btnAg);
            this.Controls.Add(this.btnPd);
            this.Controls.Add(this.btnRh);
            this.Controls.Add(this.btnRu);
            this.Controls.Add(this.btnTc);
            this.Controls.Add(this.btnMo);
            this.Controls.Add(this.btnNb);
            this.Controls.Add(this.btnZr);
            this.Controls.Add(this.btnY);
            this.Controls.Add(this.btnSr);
            this.Controls.Add(this.btnRb);
            this.Controls.Add(this.btnSe);
            this.Controls.Add(this.btnAs);
            this.Controls.Add(this.btnGe);
            this.Controls.Add(this.btnGa);
            this.Controls.Add(this.btnZn);
            this.Controls.Add(this.btnCu);
            this.Controls.Add(this.btnNi);
            this.Controls.Add(this.btnCo);
            this.Controls.Add(this.btnFe);
            this.Controls.Add(this.btnMn);
            this.Controls.Add(this.btnCr);
            this.Controls.Add(this.btnV);
            this.Controls.Add(this.btnTi);
            this.Controls.Add(this.btnSc);
            this.Controls.Add(this.btnCa);
            this.Controls.Add(this.btnK);
            this.Controls.Add(this.btnS);
            this.Controls.Add(this.btnP);
            this.Controls.Add(this.btnSi);
            this.Controls.Add(this.btnAl);
            this.Controls.Add(this.btnMg);
            this.Controls.Add(this.btnNa);
            this.Controls.Add(this.btnNe);
            this.Controls.Add(this.btnF);
            this.Controls.Add(this.btnO);
            this.Controls.Add(this.btnN);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnBe);
            this.Controls.Add(this.btnLi);
            this.Controls.Add(this.btnH);
            this.Controls.Add(this.btnHe);
            this.Controls.Add(this.btnCargar);
            this.Controls.Add(this.listBox1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tabla Periódica";
            this.TransparencyKey = System.Drawing.Color.DarkGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ListBox listBox1;
        private Button btnCargar;
        private Button btnHe;
        private Button btnH;
        private Button btnLi;
        private Button btnBe;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnO;
        private Button btnN;
        private Button btnC;
        private Button btnB;
        private Button btnNe;
        private Button btnF;
        private Button btnS;
        private Button btnP;
        private Button btnSi;
        private Button btnAl;
        private Button btnMg;
        private Button btnNa;
        private Button btnSe;
        private Button btnAs;
        private Button btnGe;
        private Button btnGa;
        private Button btnZn;
        private Button btnCu;
        private Button btnNi;
        private Button btnCo;
        private Button btnFe;
        private Button btnMn;
        private Button btnCr;
        private Button btnV;
        private Button btnTi;
        private Button btnSc;
        private Button btnCa;
        private Button btnK;
        private Button btnTe;
        private Button btnSb;
        private Button btnSn;
        private Button btnIn;
        private Button btnCd;
        private Button btnAg;
        private Button btnPd;
        private Button btnRh;
        private Button btnRu;
        private Button btnTc;
        private Button btnMo;
        private Button btnNb;
        private Button btnZr;
        private Button btnY;
        private Button btnSr;
        private Button btnRb;
        private Button btnPo;
        private Button btnBi;
        private Button btnPb;
        private Button btnTl;
        private Button btnHg;
        private Button btnAu;
        private Button btnPt;
        private Button btnIr;
        private Button btnOs;
        private Button btnRe;
        private Button btnW;
        private Button btnTa;
        private Button btnHf;
        private Button btnX0;
        private Button btnBa;
        private Button btnCs;
        private Button btnLv;
        private Button btnMc;
        private Button btnFl;
        private Button btnNh;
        private Button btnCn;
        private Button btnRg;
        private Button btnDs;
        private Button btnMt;
        private Button btnHs;
        private Button btnBh;
        private Button btnSg;
        private Button btnDb;
        private Button btnRf;
        private Button btnX1;
        private Button btnRa;
        private Button btnFr;
        private Button btnOg;
        private Button btnTs;
        private Button btnRn;
        private Button btnAt;
        private Button btnXe;
        private Button btnI;
        private Button btnKr;
        private Button btnBr;
        private Button btnAr;
        private Button btnCl;
        private Button btnLr;
        private Button btnNo;
        private Button btnLu;
        private Button btnYb;
        private Button btnMd;
        private Button btnFm;
        private Button btnEs;
        private Button btnCf;
        private Button btnBk;
        private Button btnA;
        private Button btnAm;
        private Button btnPu;
        private Button btnNp;
        private Button btnU;
        private Button btnPa;
        private Button btnTh;
        private Button btnAc;
        private Button btnTm;
        private Button btnEr;
        private Button btnHo;
        private Button btnDy;
        private Button btnTb;
        private Button btnGd;
        private Button btnEu;
        private Button btnSm;
        private Button btnPm;
        private Button btnNd;
        private Button btnPr;
        private Button btnCe;
        private Button btnLa;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
        private Button button1;
        private Button btnGasesNobles;
        private Button btnNometales;
        private Button btnMetaloides;
        private TextBox siglaA;
        private TextBox siglaB;
        private TextBox valenciaA;
        private TextBox valenciaB;
        private Label label27;
        private Label label28;
        private Label labelResultado;
        private Label label30;
        private Label label31;
        private ListBox listBox3;
        private RadioButton Oxidosmetalicos;
        private RadioButton OxidosNometalicos;
        private Label label36;
        private Label label37;
        private RadioButton btnPeróxidos;
        private Label label38;
        private Label label39;
        private Label label40;
        private Label label41;
        private Label label42;
        private Label label43;
        private Label label44;
        private Label label45;
        private Label label46;
        private Label label47;
        private Label label49;
        private Label label50;
        private Label label51;
        private Label label48;
        private Label label52;
        private Label label53;
        private Label label54;
        private Label label55;
        private Label label56;
        private Label label57;
        private Label label58;
        private Label label59;
        private Label label60;
        private Label label61;
        private Label label62;
        private Label label63;
        private Label label64;
        private Label label65;
        private Label label66;
        private Label label67;
        private Label label68;
        private Label label69;
        private Label label70;
        private Label label71;
        private Label label72;
        private Label label73;
        private Label label74;
        private Label label75;
        private Label label76;
        private Label label77;
        private Label label78;
        private Label label79;
        private Label label80;
        private Label label81;
        private Label label82;
        private Label label83;
        private Label label84;
        private Label label85;
        private Label label86;
        private Label label87;
        private Label label88;
        private Label label89;
        private Label label90;
        private Label label91;
        private Label label92;
        private Label label93;
        private Label label94;
        private Label label95;
        private Label label96;
        private Label label97;
        private Label label98;
        private Label label99;
        private Label label100;
        private Label label101;
        private Label label102;
        private Label label104;
        private Label label105;
        private Label label106;
        private Label label107;
        private Label label108;
        private Label label109;
        private Label label103;
        private Label label110;
        private Label label111;
        private Label label112;
        private Label label113;
        private Label label114;
        private Label label115;
        private Label label116;
        private Label label117;
        private Label label118;
        private Label label119;
        private Label label120;
        private Label label121;
        private Label label122;
        private Label label123;
        private Label label124;
        private Label label125;
        private Label label126;
        private Label label127;
        private Label label128;
        private Label label129;
        private Label label130;
        private Label label131;
        private Label label132;
        private Label label133;
        private Label label134;
        private Label label135;
        private Label label136;
        private Label label137;
        private Label label138;
        private Label label139;
        private Label label140;
        private Label label141;
        private Label label142;
        private Label label143;
        private Label label144;
        private Label label145;
        private Label label146;
        private Label label147;
        private Label label148;
        private Label label149;
        private Label label150;
        private Label label151;
        private Label label152;
        private Label label153;
        private Label label154;
        private Label label155;
        private Label label156;
        private Label label157;
        private Label labelCategoria;
        private CheckBox checkBox1;
        private Button button2;
        private Button button3;
        private Label label34;
        private RadioButton Ozonidos;
        private Button button4;
        private RadioButton Hidruros;
        private TextBox ValPeroxido;
        private CheckBox gaseosos;
        private CheckBox acidos;
        private RadioButton Hidracidos;
        private Button button5;
        private RadioButton Hidroxidos;
        private Label label32;
        private Label label33;
        private TextBox Valencia3;
        private TextBox Sigla3;
        private Label label35;
        private Label label158;
        private TextBox sigla4;
        private RadioButton btnTioacidos;
        private ListBox listBox2;
        private ListBox listBox4;
        private RadioButton btnSuperOxidos;
        private RadioButton btnOxacidos;
        private RadioButton btnSalesNeutras;
        private RadioButton btnSalesAcidas;
        private RadioButton btnSalesBasiscas;
        private RadioButton btnPeroxoacidos;
        private Label label29;
        private Label label159;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private ListBox listBox5;
        private ListBox listBox6;
        private ListBox listBox7;
        private Button button6;
        private Button button7;
        private Button button8;
        private TextBox valencia4;
        private Button button9;
    }
}