﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;

namespace proyectoPrueba
{
    internal class Controlador
    {
        private Modelo datos = new Modelo();
        private Modelo2 datos2 = new Modelo2();
        private Modelo3 datos3 = new Modelo3();
        private ModeloAcido acidos = new ModeloAcido();
        private ModeloGas gases = new ModeloGas();
        private tioacidos tio = new tioacidos();
        private Sales sal = new Sales();



        public List<string> informacion()
        {

            List<string> aux = new List<string>();

            foreach (ElementoModelo x in datos.origen)
            {
                aux.Add("\n Nombre: "+x.nombre+"\n Simbolo: "+x.sigla+"\n Peso Atomico:  "+x.pesoAtomico+"\n Tipo:  "+x.tipo);
            }
            return aux;

        }


        public List<string> informacionLinq()
        { 
            return datos.origen.Select(x => "  Nombre: "+ x.nombre+"   Sigla:       "+x.sigla+"  Peso Atomico:  "+x.pesoAtomico+"  Tipo:  "+x.tipo).ToList();
        
        }

        //buscar elemento por numero atomico
        public List<string> filtarElemento(int n)
        {
            
            return datos.origen.Where(x => x.pesoAtomico==n).Select(x => "\nNombre:                    "+ x.nombre
                                                                        +" \nSigla:                         "+x.sigla
                                                                        +" \nPeso Atomico:          "+x.pesoAtomico
                                                                        +" \nTipo:                         "+x.tipo
                                                                        +" \nValencias:                "+x.valencias).ToList(); ;
        }



        public List<string> filtarElemento2(int n)
        {

            return datos.origen.Where(x => x.pesoAtomico==n).Select(x => x.sigla).ToList(); ;
        }



        //filtar categorias
        public List<string> filtarMetalesLinq()
        {
            var resultado = from x in datos.origen
                            where x.tipo.StartsWith("METAL")
                            select x.sigla
                                  +"                 "+x.nombre
                                ;
            return resultado.ToList();

        }

        public List<string> filtar()
        {
            var resultado = from x in datos.origen
                            where x.tipo.StartsWith("METAL")
                            select x.nombre
                                  +x.sigla+
                                 x.pesoAtomico+
                                  x.tipo;
            return resultado.ToList();



        }

        public List<string> filtarNoMetalesLinq()
        {
            var resultado = from x in datos.origen
                            where x.tipo.StartsWith("NO METAL")
                            select x.sigla
                                  +"                  "+x.nombre
                                ;
            return resultado.ToList();



        }

        public List<string> filtarGasesnoblesLinq()
        {
            var resultado = from x in datos.origen
                            where x.tipo.StartsWith("Gases nobles")
                            select x.sigla
                                  +"                  "+x.nombre
                                ;
            return resultado.ToList();

        }

        public List<string> filtarMetaloidesLinq()
        {
            var resultado = from x in datos.origen
                            where x.tipo.StartsWith("Metaloides")
                            select x.sigla
                                    +"                 "+x.nombre
                                ;
            return resultado.ToList();

        }
        //----------------------------------------------------

        //reacciones Quimicas

        public List<string> filtrarSiglaA_OxidosMetalicos(string sigla)
        {
            var resultado = from x in datos.origen
                            where x.sigla.Equals(sigla) && x.tipo.Equals("METAL")
                            select x.nombre;

            return resultado.ToList();

        }

        public List<string> filtrarSiglaA_OxidosNoMetalicos(string sigla)
        {
            var resultado = from x in datos.origen
                            where x.sigla.Equals(sigla) && x.tipo.Equals("NO METAL")
                            select x.nombre;

            return resultado.ToList();

        }


        //----------------------------------------------------
        
        public List<string> filtrarSiglaB(string sigla)
        {
          

            var resultado = from x in datos2.origen
                            where x.sigla.Equals(sigla)
                            select x.nombre;

            return resultado.ToList();
        }

        //ozonidos
        public List<string> filtrarSiglaBOzonidos(string sigla)
        {


            var resultado = from x in datos3.origen
                            where x.sigla.StartsWith(sigla)
                            select x.nombre;

            return resultado.ToList();
        }

        public List<string> filtrarSiglaBSalNeutra(string sigla)
        {


            var resultado = from x in sal.origen
                            where x.sigla.StartsWith(sigla)
                            select x.nombre;

            return resultado.ToList();
        }


        public List<string> filtrarSiglaA_Ozonidos(string sigla)
        {
            var resultado = from x in datos.origen
                            where x.sigla.Equals(sigla) && x.tipo.Equals("METAL")
                            select x.nombre;

            if (sigla == "K" || sigla == "Rb" || sigla == "Cs"|| sigla =="Na") {
                
                
                return resultado.ToList();

            }
            else
            {
                var re = new List<string>();
                return re;

            }
        }



        public List<string> filtrarHidracidosAcidos(string sigla)
        {
            var resultado = from x in acidos.origen
                            where x.sigla.Equals(sigla)
                            select x.nombre;

            return resultado.ToList();
        }



        public List<string> filtrarTioAcidos(string sigla)
        {
            var resultado = from x in tio.origen
                            where x.sigla.Equals(sigla)
                            select x.nombre;

            return resultado.ToList();
        }


        public List<string> filtrarHidracidosGaseosos(string sigla)
        {
            

            var resultado = from x in gases.origen
                            where x.sigla.Equals(sigla)
                            select x.nombre;

            return resultado.ToList();
        }




        public List<string> filtrarSiglaCheck(int num)
        {
            var resultado = from x in datos.origen
                            where x.pesoAtomico==(num)
                            select x.sigla;

            return resultado.ToList();
        }

        public List<string> filtrarHidruros(string sigla)
        {
            var resultado = from x in datos.origen
                            where x.sigla.Equals(sigla)
                            select x.nombre;

            return resultado.ToList();

        }

        //-------------------------------------------------------------

        public string prefijo(int n)
        {
            string resultado = "";

            if (n ==1 || n == -1)
            {
                resultado ="Mono";
            }
            else if (n ==2 || n == -2)
            {
                resultado ="Di";
            }
            else if (n ==3 || n == -3)
            {
                resultado ="Tri";
            }
            else if (n ==4 || n == -4)
            {
                resultado ="Tetra";
            }
            else if (n ==5 || n == -5)
            {
                resultado ="Penta";
            }
            else if (n ==6 || n == -6)
            {
                resultado ="Hexa";
            }
            else if (n==7 || n == -7)
            {
                resultado ="Hepta";
            }
            else if (n ==8 || n == -8)
            {
                resultado ="Octa";
            }
            else if (n ==9 || n == -9)
            {
                resultado ="Nona";
            }
            else if (n ==10 || n == -10)
            {
                resultado ="Deca";
            }


            return resultado;

        }

        public string prefijo2(int n)
        {
            string resultado = "";

         
            if (n ==2 || n == -2)
            {
                resultado ="Di";
            }
            else if (n ==3 || n == -3)
            {
                resultado ="Tri";
            }
            else if (n ==4 || n == -4)
            {
                resultado ="Tetra";
            }
            else if (n ==5 || n == -5)
            {
                resultado ="Penta";
            }
            else if (n ==6 || n == -6)
            {
                resultado ="Hexa";
            }
            else if (n==7 || n == -7)
            {
                resultado ="Hepta";
            }
            else if (n ==8 || n == -8)
            {
                resultado ="Octa";
            }
            else if (n ==9 || n == -9)
            {
                resultado ="Nona";
            }
            else if (n ==10 || n == -10)
            {
                resultado ="Deca";
            }
            else
            {
                resultado ="";
            }


            return resultado;
        }



            public int divisor(int n1,int n2)
        {
            int result = 0;
            if (n1 %2==0 && n2 %2==0)
            {
                n1=n1/2;
                n2=n2/2;
                result = 2;

            }else if (n1 %3==0 && n2 %3==0){
                n1=n1/3;
                n2=n2/3;
                result = 3;
            }
            else if (n1 %5==0 && n2 %5==0)
            {
                n1=n1/3;
                n2=n2/3;
                result = 5;
            }
            else if (n1 %7==0 && n2 %7==0)
            {
                n1=n1/3;
                n2=n2/3;
                result = 7;
            }
            else
            {
                result = 1;
            }


            return result ;
        }

        public string valorAbsoluto(int n) {
            int valor;
            string valor2;
            
            if (n < 0)
            {
                valor = n * -1;
            }
            else if (n > 0)
            {
                valor = n;
            }
            else
            {
                valor = 0;
            }


            if (valor==1)
            {
                valor2="";
            }
            else
            {
                valor2=Convert.ToString(valor);
            }

            return valor2;

        }



       
//reacciones quimicas
        public string oxidosMetalicosR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {
            
          // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarSiglaA_OxidosMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaB(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1  = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA=prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                return resultado = (prefijoA+s1+" de "+prefijoB+s2);
            }

            return resultado;

        }





        public string oxidosNoMetalicosR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarSiglaA_OxidosNoMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaB(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                return resultado = (prefijoA+s1+" de "+prefijoB+s2);
            }

            return resultado;

        }




        public string peroxidosR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarSiglaA_OxidosMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaB(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                return resultado = (prefijoA+"Per"+s1+" de "+prefijoB+s2);
            }

            return resultado;

        }



        public string superOxidosR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {
            

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarSiglaA_OxidosMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaB(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                // resultado +=("super"+s1+" de "+s2);
                return resultado = (prefijoA+"Super"+s1+" de "+prefijoB+s2);
            }

            return resultado;

        }





        public string HidrurosR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {


            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarHidruros(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaB(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                //   resultado += (resultadoV1 + s1 + " de " + resultadoV2 + s2);
                return resultado = (prefijoA+s1+" de "+prefijoB+s2);
            }

            return resultado;

        }

        public string OzonidosR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {


            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarSiglaA_Ozonidos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaBOzonidos(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                //resultado +=(s1+" de "+s2);
                return resultado = (s1+" de "+s2);
            }

            return resultado;

        }



        public string gaseosoR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {


            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarHidracidosGaseosos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaB(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                //resultado +=(s1+" de "+s2);
                return resultado = (s1+" de "+s2);
            }

            return resultado;

        }




        public string acidoR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {


            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarHidracidosAcidos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaB(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                //resultado +=(s1+" de "+s2);
                return resultado = (s1+" de "+s2);
            }

            return resultado;

        }








        public string salesNeutrasR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarSiglaA_OxidosMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaBSalNeutra(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                return resultado = (prefijoA+s1+" de "+prefijoB+s2);
            }

            return resultado;

        }





        public string peroxoacidosR(string siglaA, string SiglaB, int valenciaA, int valenciaB)
        {

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";

            var registro = filtrarSiglaA_OxidosNoMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaBSalNeutra(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
             //   resultado += (resultadoV2 + " oxoperoxo " + variable+" de "+s2);
                return resultado = (prefijoA+" oxoperoxo "+s1+" de "+prefijoB+s2);
            }

            return resultado;

        }



        public string salesBasiscasR(string siglaA, string SiglaB, string SiglaC, int valenciaA, int valenciaB, int valenciaC)
        {

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";
            string s3 = "";

            var registro = filtrarSiglaA_OxidosMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaBSalNeutra(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            var registro3 = filtrarSiglaBSalNeutra(SiglaC).ToList();

            foreach (var people in registro3)
            {
                s3 = people.ToString();
            }




            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;
            int v3 = valenciaC;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v3);
            string prefijoB = prefijo2(v1);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                // resultado += (resultadoV33+t3+" "+s1+" de "+resultadoV112+t1);
                  return resultado = (prefijoA+s3+" "+s1+" de "+prefijoB+s2);
            }

            return resultado;

        }




        public string hidroxidosR(string siglaA, string SiglaB, string SiglaC, int valenciaA, int valenciaB, int valenciaC)
        {

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";
            string s3 = "";

            var registro = filtrarSiglaA_OxidosMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaBSalNeutra(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            var registro3 = filtrarSiglaBSalNeutra(SiglaC).ToList();

            foreach (var people in registro3)
            {
                s3 = people.ToString();
            }




            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;
            int v3 = valenciaC;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
               // resultado += (resultadoV1 + " Hidr" + s1 + " de " + resultadoV2 + s2);
                
                return resultado = (prefijoA+s1+" de "+prefijoB+s2);
            }

            return resultado;

        }




        public string oxacidosR(string siglaA, string SiglaB, string SiglaC, int valenciaA, int valenciaB, int valenciaC)
        {

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";
            string s3 = "";

            var registro = filtrarSiglaA_OxidosNoMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaBSalNeutra(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            var registro3 = filtrarSiglaBSalNeutra(SiglaC).ToList();

            foreach (var people in registro3)
            {
                s3 = people.ToString();
            }




            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;
            int v3 = valenciaC;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
                //  resultado += (resultadoV1 + " ácido de " + resultadoV2 + s2);
                return resultado = (prefijoA+" ácido de "+prefijoB+s2);
            }

            return resultado;

        }



        public string salesAcidasR(string siglaA, string SiglaB, string SiglaC, int valenciaA, int valenciaB, int valenciaC)
        {

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";
            string s3 = "";

            var registro = filtrarSiglaA_OxidosMetalicos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarSiglaBSalNeutra(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            var registro3 = filtrarSiglaBSalNeutra(SiglaC).ToList();

            foreach (var people in registro3)
            {
                s3 = people.ToString();
            }




            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;
            int v3 = valenciaC;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);
            string prefijoC = prefijo2(v3);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";

            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {
             
                return resultado = (prefijoA+s1+" "+prefijoC+s3+ " de "+s2);


            }

            return resultado;

        }




        public string tioacidosR(string siglaA, string SiglaB, string SiglaC, string SiglaD, int valenciaA, int valenciaB, int valenciaC, int valenciaD)
        {

            // var sig =filtrarSiglaA_OxidosMetalicos(siglaA).ToString;
            //var sig2 = filtrarSiglaB(SiglaB).ToList();
            string s1 = "";
            string s2 = "";
            string s3 = "";
            string s4 = "";

            var registro = filtrarTioAcidos(siglaA);

            foreach (var people in registro)
            {
                s1 = people.ToString();
            }



            var registro2 = filtrarTioAcidos(SiglaB).ToList();

            foreach (var people in registro2)
            {
                s2 = people.ToString();
            }



            var registro3 = filtrarTioAcidos(SiglaC).ToList();

            foreach (var people in registro3)
            {
                s3 = people.ToString();
            }


            var registro4 = filtrarTioAcidos(SiglaD).ToList();

            foreach (var people in registro4)
            {
                s4 = people.ToString();
            }


            // mensasef=(mensase);

            int v1 = valenciaA;
            int v2 = valenciaB;
            int v3 = valenciaC;
            int v4 = valenciaC;


            //divisibilidad
            int divisorComun = divisor(v1, v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;



            //asignar prefijo y cambio
            string prefijoA = prefijo(v1);
            string prefijoB = prefijo2(v2);
            string prefijoC = prefijo2(v3);


            //cambio de siglas
            string temp = "";
            temp = s1;
            s1 = s2;
            s2 = temp;


            string resultado = "";






            if (s1 == String.Empty || s2 == String.Empty)
            {
                resultado="";
                return resultado;

            }
            else
            {

                /*  if (s4 != string.Empty)
                  {
                      resultado += (prefijoA+s2+s1+s3+s4+"Azufre");
                  }

                  else
                  {*/
                // resultado += (prefijoA+s2+s1+s3+"Azufre");
                resultado += (prefijoA+s2+s1+s3+s4+"Azufre");
                // }




            }

            return resultado;

        }



        //







    }
}
