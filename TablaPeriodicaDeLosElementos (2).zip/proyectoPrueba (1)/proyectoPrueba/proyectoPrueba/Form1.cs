using System.Windows.Forms;

namespace proyectoPrueba
{
    public partial class Form1 : Form
    {
        private Controlador controler = new Controlador();
        bool repetir = false;
        //verddddddd



        public Form1()
        {
            InitializeComponent();
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
            listBox6.Visible = false;
            listBox7.Visible = false;



            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;
            button1.Visible=false;




            // button2.Visible = false; // ojo si se oculta no funciona ??
        }

        private void Form1_Load(object sender, EventArgs e)
        {
         
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            Color desactivado = Color.Gray;
            Color verde = Color.FromArgb(128, 255, 128);
            Color amarillo = Color.FromArgb(255, 255, 128);
            Color piel = Color.FromArgb(255, 192, 128);
            Color naranja = Color.FromArgb(255, 128, 0);
            Color mostaza = Color.FromArgb(192, 192, 0);
            Color gasesNobles = Color.SkyBlue;
            Color DodgerBlue = Color.DodgerBlue;
            Color gold = Color.Gold;
            Color violet = Color.Violet;
            Color purple = Color.Purple;

           // listBox2.DataSource =controler.filtarMetalesLinq();
            labelCategoria.Text = "Metales";




            //desactivar gases nobles
            btnHe.Enabled=false;
            btnHe.BackColor = desactivado;

            btnNe.Enabled=false;
            btnNe.BackColor = desactivado;

            btnAr.Enabled=false;
            btnAr.BackColor = desactivado;

            btnKr.Enabled=false;
            btnKr.BackColor = desactivado;

            btnXe.Enabled=false;
            btnXe.BackColor = desactivado;

            btnRn.Enabled=false;
            btnRn.BackColor = desactivado;

            btnOg.Enabled=false;
            btnOg.BackColor = desactivado;
            //fin
            //---------------------------------


            //dasactivar No metales
            btnH.Enabled = false;
            btnH.BackColor = desactivado;

            btnC.Enabled = false;
            btnC.BackColor = desactivado;

            btnN.Enabled = false;
            btnN.BackColor = desactivado;

            btnO.Enabled = false;
            btnO.BackColor = desactivado;

            btnP.Enabled = false;
            btnP.BackColor = desactivado;


            btnS.Enabled = false;
            btnS.BackColor = desactivado;

            btnSe.Enabled = false;
            btnSe.BackColor = desactivado;
            //azul
            btnF.Enabled = false;
            btnF.BackColor = desactivado;

            btnCl.Enabled = false;
            btnCl.BackColor = desactivado;

            btnBr.Enabled = false;
            btnBr.BackColor = desactivado;

            btnH.Enabled = false;
            btnH.BackColor = desactivado;

            btnI.Enabled = false;
            btnI.BackColor = desactivado;

            btnTs.Enabled = false;
            btnTs.BackColor = desactivado;

            //descativar metaloides


            btnB.Enabled = false;
            btnB.BackColor = desactivado;

            btnSi.Enabled = false;
            btnSi.BackColor = desactivado;

            btnGe.Enabled = false;
            btnGe.BackColor = desactivado;

            btnAs.Enabled = false;
            btnAs.BackColor = desactivado;

            btnSb.Enabled = false;
            btnSb.BackColor = desactivado;

            btnTe.Enabled = false;
            btnTe.BackColor = desactivado;

            btnPo.Enabled = false;
            btnPo.BackColor = desactivado;

            btnAt.Enabled = false;
            btnAt.BackColor = desactivado;



 





            //activar  metales

            btnLi.Enabled = true;
            btnLi.BackColor = gold;

            btnNa.Enabled = true;
            btnNa.BackColor = gold;

            btnK.Enabled = true;
            btnK.BackColor = gold;

            btnRb.Enabled = true;
            btnRb.BackColor = gold;

            btnCs.Enabled = true;
            btnCs.BackColor = gold;

            btnFr.Enabled = true;
            btnFr.BackColor = gold;

            btnBe.Enabled = true;
            btnBe.BackColor = mostaza;

            btnMg.Enabled = true;
            btnMg.BackColor = mostaza;

            btnCa.Enabled = true;
            btnCa.BackColor = mostaza;

            btnSr.Enabled = true;
            btnSr.BackColor = mostaza;

            btnBa.Enabled = true;
            btnBa.BackColor = mostaza;

            btnRa.Enabled = true;
            btnRa.BackColor = mostaza;

            btnSc.Enabled = true;
            btnSc.BackColor = verde;

            btnY.Enabled = true;
            btnY.BackColor = verde;

            btnTi.Enabled = true;
            btnTi.BackColor = verde;

            btnZr.Enabled = true;
            btnZr.BackColor = verde;

            btnHf.Enabled = true;
            btnHf.BackColor = verde;

            btnRf.Enabled = true;
            btnRf.BackColor = verde;

            btnV.Enabled = true;
            btnV.BackColor = verde;

            btnNb.Enabled = true;
            btnNb.BackColor = verde;

            btnTa.Enabled = true;
            btnTa.BackColor = verde;

            btnDb.Enabled = true;
            btnDb.BackColor = verde;

            btnCr.Enabled = true;
            btnCr.BackColor = verde;

            btnMo.Enabled = true;
            btnMo.BackColor = verde;

            btnW.Enabled = true;
            btnW.BackColor = verde;

            btnSg.Enabled = true;
            btnSg.BackColor = verde;

            btnMn.Enabled = true;
            btnMn.BackColor = verde;

            btnTc.Enabled = true;
            btnTc.BackColor = verde;

            btnRe.Enabled = true;
            btnRe.BackColor = verde;

            btnBh.Enabled = true;
            btnBh.BackColor = verde;

            btnFe.Enabled = true;
            btnFe.BackColor = verde;

            btnRu.Enabled = true;
            btnRu.BackColor = verde;

            btnOs.Enabled = true;
            btnOs.BackColor = verde;

            btnHs.Enabled = true;
            btnHs.BackColor = verde;

            btnCo.Enabled = true;
            btnCo.BackColor = verde;

            btnRh.Enabled = true;
            btnRh.BackColor = verde;

            btnIr.Enabled = true;
            btnIr.BackColor = verde;

            btnMt.Enabled = true;
            btnMt.BackColor = verde;

            btnNi.Enabled = true;
            btnNi.BackColor = verde;

            btnPd.Enabled = true;
            btnPd.BackColor = verde;

            btnPt.Enabled = true;
            btnPt.BackColor = verde;

            btnDs.Enabled = true;
            btnDs.BackColor = verde;

            btnCu.Enabled = true;
            btnCu.BackColor = verde;

            btnAg.Enabled = true;
            btnAg.BackColor = verde;

            btnAu.Enabled = true;
            btnAu.BackColor = verde;

            btnRg.Enabled = true;
            btnRg.BackColor = verde;

            btnZn.Enabled = true;
            btnZn.BackColor = verde;

            btnCd.Enabled = true;
            btnCd.BackColor = verde;

            btnHg.Enabled = true;
            btnHg.BackColor = verde;

            btnCn.Enabled = true;
            btnCn.BackColor = verde;


            btnAl.Enabled = true;
            btnAl.BackColor = naranja;

            btnGa.Enabled = true;
            btnGa.BackColor = naranja;

            btnIn.Enabled = true;
            btnIn.BackColor = naranja;

            btnTl.Enabled = true;
            btnTl.BackColor = naranja;

            btnNh.Enabled = true;
            btnNh.BackColor = naranja;

            btnSn.Enabled = true;
            btnSn.BackColor = naranja;

            btnPb.Enabled = true;
            btnPb.BackColor = naranja;

            btnFl.Enabled = true;
            btnFl.BackColor = naranja;

            btnBi.Enabled = true;
            btnBi.BackColor = naranja;

            btnMc.Enabled = true;
            btnMc.BackColor = naranja;

            btnLv.Enabled = true;
            btnLv.BackColor = naranja;


            //--Linea p�rpura activar 
            btnLa.Enabled = true;
            btnLa.BackColor = violet;

            btnAc.Enabled = true;
            btnAc.BackColor = purple;

            btnCe.Enabled = true;
            btnCe.BackColor = violet;

            btnTh.Enabled = true;
            btnTh.BackColor = purple;

            btnPr.Enabled = true;
            btnPr.BackColor = violet;

            btnPa.Enabled = true;
            btnPa.BackColor = purple;

            btnNd.Enabled = true;
            btnNd.BackColor = violet;

            btnU.Enabled = true;
            btnU.BackColor = purple;

            btnPm.Enabled = true;
            btnPm.BackColor = violet;

            btnNp.Enabled = true;
            btnNp.BackColor = purple;

            btnSm.Enabled = true;
            btnSm.BackColor = violet;

            btnPu.Enabled = true;
            btnPu.BackColor = purple;

            btnEu.Enabled = true;
            btnEu.BackColor = violet;

            btnAm.Enabled = true;
            btnAm.BackColor = purple;

            btnGd.Enabled = true;
            btnGd.BackColor = violet;

            btnA.Enabled = true;
            btnA.BackColor = purple;

            btnTb.Enabled = true;
            btnTb.BackColor = violet;

            btnBk.Enabled = true;
            btnBk.BackColor = purple;

            btnDy.Enabled = true;
            btnDy.BackColor = violet;

            btnCf.Enabled = true;
            btnCf.BackColor = purple;

            btnHo.Enabled = true;
            btnHo.BackColor = violet;

            btnEs.Enabled = true;
            btnEs.BackColor = purple;

            btnEr.Enabled = true;
            btnEr.BackColor = violet;

            btnFm.Enabled = true;
            btnFm.BackColor = purple;

            btnTm.Enabled = true;
            btnTm.BackColor = violet;

            btnMd.Enabled = true;
            btnMd.BackColor = purple; 

            btnYb.Enabled = true;
            btnYb.BackColor = violet;

            btnNo.Enabled = true;
            btnNo.BackColor = purple;

            btnLu.Enabled = true;
            btnLu.BackColor = violet;

            btnLr.Enabled = true;
            btnLr.BackColor = purple;

           
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnH_Click(object sender, EventArgs e)
        {
            


            listBox1.DataSource = controler.filtarElemento(1);
            string h = (string)listBox1.SelectedItem;
            MessageBox.Show(h);
            siglaA.Text = "H";

        }

        private void btnHe_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(2);
            string he = (string)listBox1.SelectedItem;
            MessageBox.Show(he);
            siglaA.Text = "He";
        }

        private void btnLi_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(3);
            string li = (string)listBox1.SelectedItem;
            MessageBox.Show(li);
            siglaA.Text = "Li";
        }

        private void btnBe_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(4);
            string be = (string)listBox1.SelectedItem;
            MessageBox.Show(be);
            siglaA.Text = "Be";
        }

       private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button76_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(73);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ta";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(5);
            string B = (string)listBox1.SelectedItem;
            MessageBox.Show(B);
            siglaA.Text = "B";
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(6);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "C";
        }

        private void btnN_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked==false && btnSalesNeutras.Checked==true)
            {
                DialogResult r = MessageBox.Show("Presione si para usar este elemento en su estado natural o No para usar en su estado compuesto", "Sales neutras", MessageBoxButtons.YesNo);
                if (r== DialogResult.Yes)
                {
                    siglaB.Text = "N";
                }
               

                else { siglaB.Text = "NO"; }


                 
            }
             else if (checkBox1.Checked==false && btnPeroxoacidos.Checked==true)
            {
               siglaB.Text = "NO";
                siglaA.Text = "H";


            }
            else if (checkBox1.Checked==false && btnSalesBasiscas.Checked==true)
            {
                siglaB.Text = "NO";

            }
            else
            {

                siglaA.Text = "N";

            }


            listBox1.DataSource = controler.filtarElemento(7);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
           // siglaA.Text = "N";
        }

        private void btnO_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked==false && btnSalesNeutras.Checked==true )
            {
                    siglaB.Text = "OH";
            }
          
            else
            {
                siglaA.Text = "O";
            }
            listBox1.DataSource = controler.filtarElemento(8);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
           // siglaA.Text = "O";
        }

        private void btnF_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(9);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "F";
        }

        private void btnNe_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(10);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ne";
        }

        private void btnNa_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(11);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Na";
        }

        private void btnM_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(12);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Mg";
        }

        private void btnAl_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(13);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Al";
        }

        private void btnSi_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(14);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Si";
        }

        private void btnP_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked==false && btnSalesNeutras.Checked==true)
            {
                siglaB.Text = "PO";
            }
            else if (checkBox1.Checked==false && btnSalesBasiscas.Checked==true)
            {
                siglaB.Text = "PO";
            }
            else if (checkBox1.Checked==false && btnTioacidos.Checked==true)
            {
                sigla4.Text = "P";
               
            }
            else if (checkBox1.Checked==false && btnPeroxoacidos.Checked==true)
            {
                sigla4.Text = "PO";

            }
            else
            {
                siglaA.Text = "P";
            }
            listBox1.DataSource = controler.filtarElemento(15);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            //siglaA.Text = "P";
        }

        private void btnS_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked==false && btnSalesNeutras.Checked==true)
            {
                DialogResult r = MessageBox.Show("Presione si para usar este elemento en su estado natural o No para usar en su estado compuesto", "Sales neutras", MessageBoxButtons.YesNo);
                if (r== DialogResult.Yes)
                {
                    siglaB.Text = "S";
                }
                else { siglaB.Text = "SO"; }

            }
            else if (checkBox1.Checked==false && btnPeroxoacidos.Checked==true)
            {
                siglaB.Text = "SO";
                siglaA.Text = "H";


            }
            else if (checkBox1.Checked==false && btnSalesBasiscas.Checked==true)
            {
                siglaB.Text = "SO";
                


            }
            else
            {

                siglaA.Text = "S";

            }

            listBox1.DataSource = controler.filtarElemento(16);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
          //  siglaA.Text = "S";
        }

        private void btnCl_Click(object sender, EventArgs e)
        {


            if (checkBox1.Checked==false && btnSalesNeutras.Checked==true)
            {
                DialogResult r = MessageBox.Show("Presione si para usar este elemento en su estado natural o No para usar en su estado compuesto", "Sales neutras", MessageBoxButtons.YesNo);
                if (r== DialogResult.Yes)
                {
                    siglaB.Text = "Cl";
                }
                else { siglaB.Text = "ClO"; }
               
            }
            else if (checkBox1.Checked==false && btnSalesBasiscas.Checked==true)
            {
                siglaB.Text = "ClO";



            }
            else 
            {

                siglaA.Text = "Cl";

            }

            listBox1.DataSource = controler.filtarElemento(17);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
        }

        private void btnAr_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(18);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ar";
        }

        private void btnK_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(19);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "K";
        }

        private void btnCa_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(20);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ca";
        }

        private void btnSc_Click(object sender, EventArgs e)
        {

            listBox1.DataSource = controler.filtarElemento(21);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Sc";
        }

        private void btnTi_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(22);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ti";
        }

        private void btnV_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(23);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "V";
        }

        private void btnCr_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(24);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Cr";
        }

        private void btnMn_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(25);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Mn";
        }

        private void btnCo_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(27);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Co";

        }

        private void btnFe_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(26);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Fe";
        }

        private void btnNi_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(28);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ni";
        }

        private void btnCu_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(29);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Cu";
        }

        private void btnZn_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(30);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Zn";
        }

        private void btnGa_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(31);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ga";
        }

        private void btnGe_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(32);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ge";
        }

        private void btnAs_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(33);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "As";
        }

        private void btnSe_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(34);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Se";
        }

        private void btnRb_Click(object sender, EventArgs e)
        {

           

            listBox1.DataSource = controler.filtarElemento(37);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Rb";
        }

        private void btnSr_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(38);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Sr";
        }

        private void btnY_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(39);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Y";
        }

        private void btnZr_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(40);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Zr";
        }

        private void btnNb_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(41);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Nb";
        }

        private void btnMo_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(42);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Mo";
        }

        private void btnTc_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(43);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Tc";
        }

        private void btnRu_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(44);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ru";
        }

        private void btnRh_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(45);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Rh";
        }

        private void btnPd_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(46);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Pd";
        }

        private void btnAg_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(47);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ag";
        }

        private void btnCd_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(48);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Cd";
        }

        private void btnIn_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(49);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "In";
        }

        private void btnSn_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(50);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Sn";
        }

        private void btnOtros_Click(object sender, EventArgs e)
        {
            Color desactivado = Color.Gray;
          //  listBox2.DataSource = controler.filtarMetaloidesLinq();
            labelCategoria.Text = "Metaloides";

            Color verde = Color.FromArgb(128, 255, 128);
            Color amarillo = Color.FromArgb(255, 255, 128);
            Color piel = Color.FromArgb(255, 192, 128);
            Color naranja = Color.FromArgb(255, 128, 0);
            Color mostaza = Color.FromArgb(192, 192, 0);
            Color gasesNobles = Color.SkyBlue;
            Color DodgerBlue = Color.DodgerBlue;
            Color gold = Color.Gold;
            Color violet = Color.Violet;
            Color purple = Color.Purple;

            //desactivar   gases nobles
            btnHe.Enabled=false;
            btnHe.BackColor = desactivado;

            btnNe.Enabled=false;
            btnNe.BackColor = desactivado;

            btnAr.Enabled=false;
            btnAr.BackColor = desactivado;

            btnKr.Enabled=false;
            btnKr.BackColor = desactivado;

            btnXe.Enabled=false;
            btnXe.BackColor = desactivado;

            btnRn.Enabled=false;
            btnRn.BackColor = desactivado;

            btnOg.Enabled=false;
            btnOg.BackColor = desactivado;
            //fin
            //---------------------------------






            //desactivar los que no son gases nobles

            //Gold

            btnH.Enabled=false;
            btnH.BackColor = desactivado;

            btnLi.Enabled=false;
            btnLi.BackColor = desactivado;

            btnNa.Enabled=false;
            btnNa.BackColor = desactivado;

            btnK.Enabled=false;
            btnK.BackColor = desactivado;

            btnRb.Enabled=false;
            btnRb.BackColor = desactivado;

            btnCs.Enabled=false;
            btnCs.BackColor = desactivado;

            btnFr.Enabled=false;
            btnFr.BackColor = desactivado;

            //Final Gold
            //--------------------------------------
            //mostaza
            btnBe.Enabled=false;
            btnBe.BackColor = desactivado;
            //btnBe.Visible= false;

            btnMg.Enabled=false;
            btnMg.BackColor = desactivado;

            btnCa.Enabled=false;
            btnCa.BackColor = desactivado;

            btnSr.Enabled=false;
            btnSr.BackColor = desactivado;

            btnBa.Enabled=false;
            btnBa.BackColor = desactivado;

            btnRa.Enabled=false;
            btnRa.BackColor = desactivado;

            //fin mostaza

            //-------------------------------------------------

            // Agregados por Erick 
            //verdes

            btnSc.Enabled=false;
            btnSc.BackColor = desactivado;

            btnY.Enabled=false;
            btnY.BackColor = desactivado;

            btnTi.Enabled=false;
            btnTi.BackColor = desactivado;

            btnZr.Enabled=false;
            btnZr.BackColor = desactivado;

            btnHf.Enabled=false;
            btnHf.BackColor = desactivado;

            btnRf.Enabled=false;
            btnRf.BackColor = desactivado;

            btnV.Enabled=false;
            btnV.BackColor = desactivado;

            btnNb.Enabled=false;
            btnNb.BackColor = desactivado;

            btnTa.Enabled=false;
            btnTa.BackColor = desactivado;

            btnDb.Enabled=false;
            btnDb.BackColor = desactivado;

            btnCr.Enabled=false;
            btnCr.BackColor = desactivado;

            btnMo.Enabled=false;
            btnMo.BackColor = desactivado;

            btnW.Enabled=false;
            btnW.BackColor = desactivado;

            btnSg.Enabled=false;
            btnSg.BackColor = desactivado;

            btnMn.Enabled=false;
            btnMn.BackColor = desactivado;

            btnTc.Enabled=false;
            btnTc.BackColor = desactivado;

            btnRe.Enabled=false;
            btnRe.BackColor = desactivado;

            btnBh.Enabled=false;
            btnBh.BackColor = desactivado;

            btnFe.Enabled=false;
            btnFe.BackColor = desactivado;

            btnRu.Enabled=false;
            btnRu.BackColor = desactivado;

            btnOs.Enabled=false;
            btnOs.BackColor = desactivado;

            btnHs.Enabled=false;
            btnHs.BackColor = desactivado;

            btnCo.Enabled=false;
            btnCo.BackColor = desactivado;

            btnRh.Enabled=false;
            btnRh.BackColor = desactivado;

            btnIr.Enabled=false;
            btnIr.BackColor = desactivado;

            btnMt.Enabled = false;
            btnMt.BackColor = desactivado;

            btnNi.Enabled = false;
            btnNi.BackColor = desactivado;

            btnPd.Enabled = false;
            btnPd.BackColor = desactivado;

            btnPt.Enabled = false;
            btnPt.BackColor = desactivado;

            btnDs.Enabled = false;
            btnDs.BackColor = desactivado;

            btnCu.Enabled = false;
            btnCu.BackColor = desactivado;

            btnAg.Enabled = false;
            btnAg.BackColor = desactivado;

            btnAu.Enabled = false;
            btnAu.BackColor = desactivado;

            btnRg.Enabled = false;
            btnRg.BackColor = desactivado;

            btnZn.Enabled = false;
            btnZn.BackColor = desactivado;

            btnCd.Enabled = false;
            btnCd.BackColor = desactivado;

            btnHg.Enabled = false;
            btnHg.BackColor = desactivado;

            btnCn.Enabled = false;
            btnCn.BackColor = desactivado;
            //----------------------------------------------------------------------
            // Naranja
            btnAl.Enabled = false;
            btnAl.BackColor = desactivado;

            btnGa.Enabled = false;
            btnGa.BackColor = desactivado;

            btnIn.Enabled = false;
            btnIn.BackColor = desactivado;

            btnNh.Enabled = false;
            btnNh.BackColor = desactivado;

            btnTl.Enabled = false;
            btnTl.BackColor = desactivado;

            btnSn.Enabled = false;
            btnSn.BackColor = desactivado;

            btnPb.Enabled = false;
            btnPb.BackColor = desactivado;

            btnFl.Enabled = false;
            btnFl.BackColor = desactivado;

            btnBi.Enabled = false;
            btnBi.BackColor = desactivado;

            btnMc.Enabled = false;
            btnMc.BackColor = desactivado;

            btnLv.Enabled = false;
            btnLv.BackColor = desactivado;

            //----------------------------------------------------------------------
            //amrillos

            //ativar metaloides
            //activar amarillos

            btnB.Enabled = true;
            btnB.BackColor = amarillo;

            btnSi.Enabled = true;
            btnSi.BackColor = amarillo;

            btnGe.Enabled = true;
            btnGe.BackColor = amarillo;

            btnAs.Enabled = true;
            btnAs.BackColor = amarillo;

            btnSb.Enabled = true;
            btnSb.BackColor = amarillo;

            btnTe.Enabled = true;
            btnTe.BackColor = amarillo;

            btnPo.Enabled = true;
            btnPo.BackColor = amarillo;


            btnAt.Enabled = true;
            btnAt.BackColor = DodgerBlue;


            //Color papaya XD
            btnC.Enabled = false;
            btnC.BackColor = desactivado;

            btnN.Enabled = false;
            btnN.BackColor = desactivado;

            btnP.Enabled = false;
            btnP.BackColor = desactivado;

            btnO.Enabled = false;
            btnO.BackColor = desactivado;

            btnS.Enabled = false;
            btnS.BackColor = desactivado;

            btnSe.Enabled = false;
            btnSe.BackColor = desactivado;

            //----------------------------------------------------------------------
            //Azul - DodgerBlue
            btnF.Enabled = false;
            btnF.BackColor = desactivado;

            btnCl.Enabled = false;
            btnCl.BackColor = desactivado;

            btnBr.Enabled = false;
            btnBr.BackColor = desactivado;

            btnI.Enabled = false;
            btnI.BackColor = desactivado;

            btnTs.Enabled = false;
            btnTs.BackColor = desactivado;

            //----------------------------------------------------------------------
            //violeta
            btnX0.Enabled = false;
            btnX0.BackColor = desactivado;
            //----------------------------------------------------------------------
            //purpura
            btnX1.Enabled=false;
            btnX1.BackColor = desactivado;
            //----------------------------------------------------------------------

            //--Linea p�rpura y violeta descativa 
            btnLa.Enabled = false;
            btnLa.BackColor = desactivado;

            btnAc.Enabled = false;
            btnAc.BackColor = desactivado;

            btnCe.Enabled = false;
            btnCe.BackColor = desactivado;

            btnTh.Enabled = false;
            btnTh.BackColor = desactivado;

            btnPr.Enabled = false;
            btnPr.BackColor = desactivado;

            btnPa.Enabled = false;
            btnPa.BackColor = desactivado;

            btnNd.Enabled = false;
            btnNd.BackColor = desactivado;

            btnU.Enabled = false;
            btnU.BackColor = desactivado;

            btnPm.Enabled = false;
            btnPm.BackColor = desactivado;

            btnNp.Enabled = false;
            btnNp.BackColor = desactivado;

            btnSm.Enabled = false;
            btnSm.BackColor = desactivado;

            btnPu.Enabled = false;
            btnPu.BackColor = desactivado;

            btnEu.Enabled = false;
            btnEu.BackColor = desactivado;

            btnAm.Enabled = false;
            btnAm.BackColor = desactivado;

            btnGd.Enabled = false;
            btnGd.BackColor = desactivado;

            btnA.Enabled = false;
            btnA.BackColor = desactivado;

            btnTb.Enabled = false;
            btnTb.BackColor = desactivado;

            btnBk.Enabled = false;
            btnBk.BackColor = desactivado;

            btnDy.Enabled = false;
            btnDy.BackColor = desactivado;

            btnCf.Enabled = false;
            btnCf.BackColor = desactivado;

            btnHo.Enabled = false;
            btnHo.BackColor = desactivado;

            btnEs.Enabled = false;
            btnEs.BackColor = desactivado;

            btnEr.Enabled = false;
            btnEr.BackColor = desactivado;

            btnFm.Enabled = false;
            btnFm.BackColor = desactivado;

            btnTm.Enabled = false;
            btnTm.BackColor = desactivado;

            btnMd.Enabled = false;
            btnMd.BackColor = desactivado;

            btnYb.Enabled = false;
            btnYb.BackColor = desactivado;

            btnNo.Enabled = false;
            btnNo.BackColor = desactivado;

            btnLu.Enabled = false;
            btnLu.BackColor = desactivado;

            btnLr.Enabled = false;
            btnLr.BackColor = desactivado;










        }

        private void btnNometales_Click(object sender, EventArgs e)
        {
            Color desactivado = Color.Gray;
            //listBox2.DataSource = controler.filtarNoMetalesLinq();
            labelCategoria.Text = "No Metales";


            Color verde = Color.FromArgb(128, 255, 128);
            Color amarillo = Color.FromArgb(255, 255, 128);
            Color piel = Color.FromArgb(255, 192, 128);
            Color naranja = Color.FromArgb(255, 128, 0);
            Color mostaza = Color.FromArgb(192, 192, 0);
            Color gasesNobles = Color.SkyBlue;
            Color DodgerBlue = Color.DodgerBlue;
            Color gold = Color.Gold;
            Color violet = Color.Violet;
            Color purple = Color.Purple;

            //desactivar   gases nobles
            btnHe.Enabled=false;
            btnHe.BackColor = desactivado;

            btnNe.Enabled=false;
            btnNe.BackColor = desactivado;

            btnAr.Enabled=false;
            btnAr.BackColor = desactivado;

            btnKr.Enabled=false;
            btnKr.BackColor = desactivado;

            btnXe.Enabled=false;
            btnXe.BackColor = desactivado;

            btnRn.Enabled=false;
            btnRn.BackColor = desactivado;

            btnOg.Enabled=false;
            btnOg.BackColor = desactivado;
            //fin
            //---------------------------------






            //desactivar los que no son gases nobles

            //Gold

            btnH.Enabled=true;
            btnH.BackColor = piel;

            btnLi.Enabled=false;
            btnLi.BackColor = desactivado;

            btnNa.Enabled=false;
            btnNa.BackColor = desactivado;

            btnK.Enabled=false;
            btnK.BackColor = desactivado;

            btnRb.Enabled=false;
            btnRb.BackColor = desactivado;

            btnCs.Enabled=false;
            btnCs.BackColor = desactivado;

            btnFr.Enabled=false;
            btnFr.BackColor = desactivado;

            //Final Gold
            //--------------------------------------
            //mostaza
            btnBe.Enabled=false;
            btnBe.BackColor = desactivado;
            //btnBe.Visible= false;

            btnMg.Enabled=false;
            btnMg.BackColor = desactivado;

            btnCa.Enabled=false;
            btnCa.BackColor = desactivado;

            btnSr.Enabled=false;
            btnSr.BackColor = desactivado;

            btnBa.Enabled=false;
            btnBa.BackColor = desactivado;

            btnRa.Enabled=false;
            btnRa.BackColor = desactivado;

            //fin mostaza

            //-------------------------------------------------

            // Agregados por Erick 
            //verdes

            btnSc.Enabled=false;
            btnSc.BackColor = desactivado;

            btnY.Enabled=false;
            btnY.BackColor = desactivado;

            btnTi.Enabled=false;
            btnTi.BackColor = desactivado;

            btnZr.Enabled=false;
            btnZr.BackColor = desactivado;

            btnHf.Enabled=false;
            btnHf.BackColor = desactivado;

            btnRf.Enabled=false;
            btnRf.BackColor = desactivado;

            btnV.Enabled=false;
            btnV.BackColor = desactivado;

            btnNb.Enabled=false;
            btnNb.BackColor = desactivado;

            btnTa.Enabled=false;
            btnTa.BackColor = desactivado;

            btnDb.Enabled=false;
            btnDb.BackColor = desactivado;

            btnCr.Enabled=false;
            btnCr.BackColor = desactivado;

            btnMo.Enabled=false;
            btnMo.BackColor = desactivado;

            btnW.Enabled=false;
            btnW.BackColor = desactivado;

            btnSg.Enabled=false;
            btnSg.BackColor = desactivado;

            btnMn.Enabled=false;
            btnMn.BackColor = desactivado;

            btnTc.Enabled=false;
            btnTc.BackColor = desactivado;

            btnRe.Enabled=false;
            btnRe.BackColor = desactivado;

            btnBh.Enabled=false;
            btnBh.BackColor = desactivado;

            btnFe.Enabled=false;
            btnFe.BackColor = desactivado;

            btnRu.Enabled=false;
            btnRu.BackColor = desactivado;

            btnOs.Enabled=false;
            btnOs.BackColor = desactivado;

            btnHs.Enabled=false;
            btnHs.BackColor = desactivado;

            btnCo.Enabled=false;
            btnCo.BackColor = desactivado;

            btnRh.Enabled=false;
            btnRh.BackColor = desactivado;

            btnIr.Enabled=false;
            btnIr.BackColor = desactivado;

            btnMt.Enabled = false;
            btnMt.BackColor = desactivado;

            btnNi.Enabled = false;
            btnNi.BackColor = desactivado;

            btnPd.Enabled = false;
            btnPd.BackColor = desactivado;

            btnPt.Enabled = false;
            btnPt.BackColor = desactivado;

            btnDs.Enabled = false;
            btnDs.BackColor = desactivado;

            btnCu.Enabled = false;
            btnCu.BackColor = desactivado;

            btnAg.Enabled = false;
            btnAg.BackColor = desactivado;

            btnAu.Enabled = false;
            btnAu.BackColor = desactivado;

            btnRg.Enabled = false;
            btnRg.BackColor = desactivado;

            btnZn.Enabled = false;
            btnZn.BackColor = desactivado;

            btnCd.Enabled = false;
            btnCd.BackColor = desactivado;

            btnHg.Enabled = false;
            btnHg.BackColor = desactivado;

            btnCn.Enabled = false;
            btnCn.BackColor = desactivado;
            //----------------------------------------------------------------------
            // Naranja
            btnAl.Enabled = false;
            btnAl.BackColor = desactivado;

            btnGa.Enabled = false;
            btnGa.BackColor = desactivado;

            btnIn.Enabled = false;
            btnIn.BackColor = desactivado;

            btnNh.Enabled = false;
            btnNh.BackColor = desactivado;

            btnTl.Enabled = false;
            btnTl.BackColor = desactivado;

            btnSn.Enabled = false;
            btnSn.BackColor = desactivado;

            btnPb.Enabled = false;
            btnPb.BackColor = desactivado;

            btnFl.Enabled = false;
            btnFl.BackColor = desactivado;

            btnBi.Enabled = false;
            btnBi.BackColor = desactivado;

            btnMc.Enabled = false;
            btnMc.BackColor = desactivado;

            btnLv.Enabled = false;
            btnLv.BackColor = desactivado;

            //----------------------------------------------------------------------
            //amrillos

            //desactivar metaloides
            //desactivar amarillos

            btnB.Enabled = false;
            btnB.BackColor = desactivado;

            btnSi.Enabled = false;
            btnSi.BackColor = desactivado;

            btnGe.Enabled = false;
            btnGe.BackColor = desactivado;

            btnAs.Enabled = false;
            btnAs.BackColor = desactivado;

            btnSb.Enabled = false;
            btnSb.BackColor = desactivado;

            btnTe.Enabled = false;
            btnTe.BackColor = desactivado;

            btnPo.Enabled = false;
            btnPo.BackColor = desactivado;


            btnAt.Enabled = false;
            btnAt.BackColor = desactivado;


            //Color papaya XD
            btnC.Enabled = true;
            btnC.BackColor = piel;

            btnN.Enabled = true;
            btnN.BackColor = piel;

            btnP.Enabled = true;
            btnP.BackColor = piel;

            btnO.Enabled = true;
            btnO.BackColor = piel;

            btnS.Enabled = true;
            btnS.BackColor = piel;

            btnSe.Enabled = true;
            btnSe.BackColor = piel;

            //----------------------------------------------------------------------
            //Azul - DodgerBlue
            btnF.Enabled = true;
            btnF.BackColor = DodgerBlue;

            btnCl.Enabled = true;
            btnCl.BackColor = DodgerBlue;

            btnBr.Enabled = true;
            btnBr.BackColor = DodgerBlue;

            btnI.Enabled = true;
            btnI.BackColor = DodgerBlue;

            btnTs.Enabled = true;
            btnTs.BackColor = DodgerBlue;

            //----------------------------------------------------------------------
            //violeta
            btnX0.Enabled = false;
            btnX0.BackColor = desactivado;
            //----------------------------------------------------------------------
            //purpura
            btnX1.Enabled=false;
            btnX1.BackColor = desactivado;
            //----------------------------------------------------------------------

            //--Linea p�rpura y violeta descativa 
            btnLa.Enabled = false;
            btnLa.BackColor = desactivado;

            btnAc.Enabled = false;
            btnAc.BackColor = desactivado;

            btnCe.Enabled = false;
            btnCe.BackColor = desactivado;

            btnTh.Enabled = false;
            btnTh.BackColor = desactivado;

            btnPr.Enabled = false;
            btnPr.BackColor = desactivado;

            btnPa.Enabled = false;
            btnPa.BackColor = desactivado;

            btnNd.Enabled = false;
            btnNd.BackColor = desactivado;

            btnU.Enabled = false;
            btnU.BackColor = desactivado;

            btnPm.Enabled = false;
            btnPm.BackColor = desactivado;

            btnNp.Enabled = false;
            btnNp.BackColor = desactivado;

            btnSm.Enabled = false;
            btnSm.BackColor = desactivado;

            btnPu.Enabled = false;
            btnPu.BackColor = desactivado;

            btnEu.Enabled = false;
            btnEu.BackColor = desactivado;

            btnAm.Enabled = false;
            btnAm.BackColor = desactivado;

            btnGd.Enabled = false;
            btnGd.BackColor = desactivado;

            btnA.Enabled = false;
            btnA.BackColor = desactivado;

            btnTb.Enabled = false;
            btnTb.BackColor = desactivado;

            btnBk.Enabled = false;
            btnBk.BackColor = desactivado;

            btnDy.Enabled = false;
            btnDy.BackColor = desactivado;

            btnCf.Enabled = false;
            btnCf.BackColor = desactivado;

            btnHo.Enabled = false;
            btnHo.BackColor = desactivado;

            btnEs.Enabled = false;
            btnEs.BackColor = desactivado;

            btnEr.Enabled = false;
            btnEr.BackColor = desactivado;

            btnFm.Enabled = false;
            btnFm.BackColor = desactivado;

            btnTm.Enabled = false;
            btnTm.BackColor = desactivado;

            btnMd.Enabled = false;
            btnMd.BackColor = desactivado;

            btnYb.Enabled = false;
            btnYb.BackColor = desactivado;

            btnNo.Enabled = false;
            btnNo.BackColor = desactivado;

            btnLu.Enabled = false;
            btnLu.BackColor = desactivado;

            btnLr.Enabled = false;
            btnLr.BackColor = desactivado;









        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)

        {

            labelResultado.Text="";

            if ( checkBox1.Checked)
            {       
                button3.PerformClick();
                checkBox1.Checked= false;
                checkBox1.Checked= true;  
            }

            if (Oxidosmetalicos.Checked || btnPer�xidos.Checked || Hidroxidos.Checked || btnSuperOxidos.Checked || btnSalesNeutras.Checked || btnSalesAcidas.Checked) {
                listBox1.DataSource  = controler.filtrarSiglaA_OxidosMetalicos(siglaA.Text);
            }
            if (OxidosNometalicos.Checked || btnOxacidos.Checked ) {
                listBox1.DataSource  = controler.filtrarSiglaA_OxidosNoMetalicos(siglaA.Text);
            }
            if (Ozonidos.Checked)
            {
                listBox1.DataSource  = controler.filtrarSiglaA_Ozonidos(siglaA.Text);
            }
            if (Hidruros.Checked)
            {
                listBox1.DataSource = controler.filtrarHidruros(siglaA.Text);
            }
            if (Hidracidos.Checked)
            {
                if (gaseosos.Checked==true)
                {
                    listBox1.DataSource = controler.filtrarHidracidosGaseosos(siglaA.Text);
                }
                else if (acidos.Checked==true)
                {
                    listBox1.DataSource = controler.filtrarHidracidosAcidos(siglaA.Text);
                }

            }
            if (btnTioacidos.Checked)
            {
              
                listBox4.DataSource  = controler.filtrarTioAcidos(siglaA.Text);
                listBox5.DataSource  = controler.filtrarTioAcidos(siglaB.Text);
                listBox6.DataSource = controler.filtrarTioAcidos(Sigla3.Text);
                if (sigla4.Text != string.Empty)
                {
                    listBox7.DataSource= controler.filtrarTioAcidos(sigla4.Text);
                }
            }

            if (btnPeroxoacidos.Checked )
            {
                listBox1.DataSource  = controler.filtrarSiglaA_OxidosNoMetalicos(siglaA.Text);
                
            }
            
            if (btnSalesBasiscas.Checked)
            {
                listBox1.DataSource  = controler.filtrarSiglaA_OxidosMetalicos(siglaA.Text);
                listBox5.DataSource  = controler.filtrarSiglaBSalNeutra(siglaB.Text);
                listBox6.DataSource  = controler.filtrarSiglaBSalNeutra(Sigla3.Text);
               
            }

            


            string r1 = "";

            try
            {
               r1 = (string)listBox1.SelectedItem;
            }
            catch (Exception ex)
            {
                r1 = null;
            }

            string resultadoV1 = "";
            string resultadoV2 = "";
            string resultadoV3 = "";
            string resultado = "";
            string resultado22 = "";
            string s1 = r1;
            string s2 = siglaB.Text;
            int v1 = 0;
            int v2 = 0;
            int v3 = 0;

            try
                {
                    v1 = Convert.ToInt32(valenciaA.Text);
                
                }
                catch (Exception ex) 
                { 
                    MessageBox.Show("No agrego un numero entero, por defecto se agrega 1 a la valencia A");
                    v1 = 1;
                }
              


                try
                {
                
                    v2 = Convert.ToInt32(valenciaB.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No agrego un numero entero, por defecto se agrega 1 a la valencia B");
                    v2=1;
                }

           




            int temp = 0;
            string temp2 = "";

           

          
         

            //divisibilidad
            int divisorComun = controler.divisor(v1,v2);
            v1=v1/divisorComun;
            v2=v2/divisorComun;


            //asignar prefijo y cambio
            resultadoV1=controler.prefijo(v1);
            resultadoV2=controler.prefijo2(v2);

           


            //cambio de siglas
            temp2 = s1;
            s1 = s2;
            s2 = temp2;

            String variable = "p";


            string s33 = "";//no borrar
            string aux22 = " ";//no borrar


            if (Ozonidos.Checked )
            {
                //ozonidos 
                listBox3.DataSource = controler.filtrarSiglaBOzonidos(s1);
                s1 = (string)listBox3.SelectedItem;
            }
             else if (btnSalesNeutras.Checked)
            {
                  
                listBox3.DataSource = controler.filtrarSiglaBSalNeutra(s1);
                try 
                { 
                    s1 = (string)listBox3.SelectedItem;
                    if (s1!= String.Empty)
                    {
                        variable=s1;
                    }
                    else 
                    {
                        variable=null;
                    }

                   
                }
                catch (Exception ex) { variable=null ; }
               
            }

            else if ( btnPeroxoacidos.Checked)
            {
                 
                listBox3.DataSource = controler.filtrarSiglaBSalNeutra(s1);
                try
                {
                    s1 = (string)listBox3.SelectedItem;
                    if (s1!= String.Empty)
                    {
                        variable=s1;
                    }
                    else
                    {
                        variable=null;
                    }


                }
                catch (Exception ex) { variable=null; }

            }

            


           
           else if (btnSalesAcidas.Checked)
            {
                string si3=Sigla3.Text;
                listBox3.DataSource = controler.filtrarSiglaBSalNeutra(s1);
                listBox4.DataSource = controler.filtrarSiglaBSalNeutra(si3);
                try
                {
                    s1 = (string)listBox3.SelectedItem;
                    s33 = (string)listBox3.SelectedItem;

                    if (s1!= String.Empty)
                    {
                        variable=s1;
                    }
                    else
                    {
                        variable=null;
                    }


                }
                catch (Exception ex) { variable=null; }



            }
            else
            {
                //ojo tioacido
                listBox3.DataSource = controler.filtrarSiglaB(s1);
                 s1 = (string)listBox3.SelectedItem;

            }

           


            //++
            string s1Temp = siglaA.Text;
            string s2Temp = siglaB.Text;
            //++

            string temp3 = "";
            temp3 = s1Temp;
            s1Temp = s2Temp;
            s2Temp = temp3;




            // resultado +=(resultadoV2+s1+" de "+resultadoV1+s2);


            if (Oxidosmetalicos.Checked || OxidosNometalicos.Checked || btnSalesNeutras.Checked)
            {
                //resultado nomenclatura sistematica � IUPAC
                resultado +=(resultadoV1+s1+" de "+resultadoV2+s2);
            }
            if (btnPer�xidos.Checked)
            {
                //resultado nomenclatura sistematica � IUPAC
                resultado +=(resultadoV1+"Per"+s1+" de "+resultadoV2+s2);
            }
            
            if (btnSuperOxidos.Checked)
            {
                //resultado nomenclatura sistematica � IUPAC
                resultado +=("super"+s1+" de "+s2);
            }

            if (Ozonidos.Checked)
            {
                //resultado nomenclatura sistematica � IUPAC
                resultado +=(s1+" de "+s2);
            }


            if (Hidruros.Checked)
            {
                //resultado nomenclatura sistematica � IUPAC
                resultado += (resultadoV1 + s1 + " de " + resultadoV2 + s2);
            }


            if (Hidracidos.Checked)
            {
                    //resultado nomenclatura sistematica � IUPAC
                    resultado += (s1 + " de " + s2);    
            }

            if (Hidroxidos.Checked)
            {
                //resultado nomenclatura sistematica � IUPAC
                resultado += (resultadoV1 + " Hidr" + s1 + " de " + resultadoV2 + s2);
            }

            if (btnOxacidos.Checked)
            {
                //resultado nomenclatura sistematica � IUPAC
                resultado += (resultadoV1 + " �cido de " + resultadoV2 + s2);
            }







            if (btnPeroxoacidos.Checked)
            {
                //resultado nomenclatura sistematica � IUPAC
                resultado += (resultadoV2 + " oxoperoxo " + variable+" de "+s2);
            }



            





            if (btnTioacidos.Checked)
            {
                string t1 = (string)listBox4.SelectedItem;
                string t2 = (string)listBox5.SelectedItem;
                string t3 = (string)listBox6.SelectedItem;
                string t4 = (string)listBox7.SelectedItem;

                //resultado nomenclatura sistematica � IUPAC
                if (sigla4.Text != string.Empty)
                {
                    resultado += (resultadoV1+t1+t2+t3+t4+"Azufre");
                }

                else
                {
                    resultado += (resultadoV1+t1+t2+t3+"Azufre");
                }

            }


            if (btnSalesAcidas.Checked)
            {

                try
                {

                    v3 = Convert.ToInt32(Valencia3.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No agrego un numero entero, por defecto se agrega 3 a la valencia 3");
                    v3=3;
                }

                string resultadoV33=controler.prefijo2(v3);

                string t1 = (string)listBox3.SelectedItem;
                string t2 = (string)listBox4.SelectedItem;
          

                //resultado nomenclatura sistematica � IUPAC
              
                 resultado += (t1+" "+resultadoV33+t2+" de "+s2);
                 //resultado += (resultadoV1+t1+" "+resultadoV33+t2+" de "+s2);  // preguntar cual prefiere el profesor???
               


            }
            
            if (btnSalesBasiscas.Checked)
            {

                try
                {
                    v3 = Convert.ToInt32(Valencia3.Text);


                }
                catch (Exception ex)
                {
                    MessageBox.Show("No agrego un numero entero, por defecto se agrega 1 a la valencia 3");
                    v3 = 1;

                }



                try {

                    string resultadoV33 = controler.prefijo(v3);
                    string resultadoV112 = controler.prefijo2(v1);

                    string t1 = (string)listBox1.SelectedItem;
                    s1 = (string)listBox5.SelectedItem;
                    string t3 = (string)listBox6.SelectedItem;

                    //resultado nomenclatura sistematica � IUPAC
                    resultado += (resultadoV33+t3+" "+s1+" de "+resultadoV112+t1);
                }
                catch(Exception ex) {; }
                





              

            }


            

            //resultado matematico
            string vN1 = controler.valorAbsoluto(v1);
            string vN2 = controler.valorAbsoluto(v2);



            int val3 = 0;
            string vN3 = "";

            if (btnPer�xidos.Checked && ValPeroxido.Text != string.Empty)
            {
                val3 = Convert.ToInt32(ValPeroxido.Text);
                vN3 = controler.valorAbsoluto(val3);
            }
            

            resultado22 = (s1Temp+vN1+s2Temp+vN2);


            if (btnPer�xidos.Checked || btnSuperOxidos.Checked)
            {
                //resultado nomenclatura sistematica � IUPAC
                if (ValPeroxido.Text == string.Empty)
                {
                    resultado22 = (s1Temp + vN1 + s2Temp + vN2);
                }
                else
                {
                    resultado22 = ("("+s1Temp + vN1+ ")" + vN3 + s2Temp + vN2);
                }
            }


            if (Hidracidos.Checked)
            {
                //resultado matematico
                resultado22 = (s1Temp + vN2 + s2Temp + vN1);
            }

            if (Hidroxidos.Checked)
            {
                String s = Sigla3.Text;
                //resultado matematico
                resultado22 = (s2Temp + " (" + s1Temp + s +") " + vN1 );
            }

            if (btnOxacidos.Checked)
            {
                String s = Sigla3.Text;
                //resultado matematico
                resultado22 = ("("+s+  s2Temp  + s1Temp + vN1+")");
            }

            if (btnSalesAcidas.Checked)
            {
                String s = Sigla3.Text;
                String v = Valencia3.Text;
                //resultado matematico
                resultado22 = ("(" + s2Temp  + s1Temp + vN1+s+v+")");
                //ojo preguntar por la nomenclatura en
            }



            //radioButtonAleatorio

            //verificar si esta correcta la reaccion quimica

            if ((variable == null || r1==null) && btnSalesNeutras.Checked==true && checkBox1.Checked)
            {
                checkBox1.Checked= false;
                checkBox1.Checked= true;
                button2.PerformClick();
            }
            else if (r1==null && checkBox1.Checked)
            {
                checkBox1.Checked= false;
                checkBox1.Checked= true;
                button2.PerformClick();
            }
            else if (r1==null && btnTioacidos.Checked==false) {

                MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores","Error",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            else if (variable == String.Empty && btnSalesNeutras.Checked==true)
            {

                MessageBox.Show("Error.nn");
            }
            else 
            { 
                MessageBox.Show(resultado+"  =  " + resultado22,"Resultado");
                labelResultado.Text =(resultado+"  =  " + resultado22);
                // MessageBox.Show(resultado22);
                repetir=false;
                siglaA.Visible=true;
                siglaB.Visible=true;
                valenciaA.Visible=true;
                valenciaB.Visible=true;
                labelCategoria.Visible=true;

            };
        }

        private void button70_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(79);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Au";
        }

        private void Oxidosmetalicos_CheckedChanged(object sender, EventArgs e)
        {


            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;

            siglaB.Text = "O";
            valenciaB.Text = "-2";
        }

        private void OxidosNometalicos_CheckedChanged(object sender, EventArgs e)
        {

            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;

            Sigla3.Visible = false;
            Valencia3.Visible = false;

            siglaB.Text = "O";
            valenciaB.Text = "-2";
        }

        private void btnBr_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(35);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Br";
        }

        private void btnKr_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(36);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Kr";
        }

        private void button50_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(51);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Sb";
        }

        private void btnCs_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(55);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Cs";
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button49_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(52);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Te";
        }

        private void btnBa_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(56);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ba";
        }

        private void button102_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(53);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "I";
        }

        private void button101_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(54);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Xe";
        }

        private void button78_Click(object sender, EventArgs e)
        {
            
        }

        private void button90_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(107);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Bh";
        }

        private void btnLa_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(57);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "La";
        }

        private void button135_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(58);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ce";
        }

        private void button134_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(59);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Pr";
        }

        private void button133_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(60);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Nd";
        }

        private void button132_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(61);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Pm";
        }

        private void button131_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(62);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Sm";
        }

        private void button130_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(63);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Eu";
        }

        private void button129_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(64);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Gd";
        }

        private void button128_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(65);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Tb";
        }

        private void button127_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(66);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Dy";
        }

        private void button126_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(67);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ho";
        }

        private void button125_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(68);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Er";
        }

        private void button124_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(69);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Tm";
        }

        private void button110_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(70);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Yb";
        }

        private void button109_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(71);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Lu";
        }

        private void btnHf_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(72);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Hf";
        }

        private void button75_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(74);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "W";
        }

        private void button74_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(75);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Re";
        }

        private void button73_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(76);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Os";
        }

        private void button72_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(77);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ir";
        }

        private void button71_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(78);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Pt";
        }

        private void button85_Click(object sender, EventArgs e)
        {

        }

        private void button69_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(80);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Hg";
        }

        private void button68_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(81);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ti";
        }

        private void button67_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(82);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Pb";
        }

        private void button66_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(83);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Bi";
        }

        private void button65_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(84);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Po";
        }

        private void button100_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(85);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "At";
        }

        private void button99_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(86);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Rn";
        }

        private void btnFr_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(87);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Fr";
        }

        private void btnRa_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(88);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ra";
        }

        private void btn_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(89);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ac";
        }

        private void button122_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(90);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Th";
        }

        private void button121_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(91);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Pa";
        }

        private void button120_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(92);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "U";
        }

        private void button119_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(93);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Np";
        }

        private void button118_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(94);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Pu";
        }

        private void button117_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(95);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Am";
        }

        private void button116_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(96);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "C";
        }

        private void button115_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(97);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Bk";
        }

        private void button114_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(98);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Cf";
        }

        private void button113_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(99);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Es";
        }

        private void button112_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(100);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ba";
        }

        private void button111_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(101);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Md";
        }

        private void button108_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(102);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "No";
        }

        private void button107_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(103);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Lr";
        }

        private void btnRf_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(104);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Rf";
        }

        private void button92_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(105);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Db";
        }

        private void button91_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(106);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Sg";
        }

        private void button89_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(108);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Hs";
        }

        private void button88_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(109);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Mt";
        }

        private void button87_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(110);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ds";
        }

        private void button86_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(111);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Rg";
        }

        private void button85_Click_1(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(112);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Cn";
        }

        private void button84_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(113);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Nh";
        }

        private void button83_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(114);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Fi";
        }

        private void button82_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(115);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Mc";
        }

        private void button81_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(116);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Lv";
        }

        private void button98_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(117);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Ts";
        }

        private void button97_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = controler.filtarElemento(118);
            string resultado = (string)listBox1.SelectedItem;
            MessageBox.Show(resultado);
            siglaA.Text = "Og";
        }

        private void siglaA_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;

            siglaB.Text = "O";
            valenciaB.Text = "-2";
        }

        private void label40_Click(object sender, EventArgs e)
        {

        }

        private void label45_Click(object sender, EventArgs e)
        {

        }

        private void label52_Click(object sender, EventArgs e)
        {

        }

        private void label54_Click(object sender, EventArgs e)
        {

        }

        private void btnGasesNobles_Click(object sender, EventArgs e)
        {
            Color desactivado = Color.Gray;
            Color gasesNobles = Color.SkyBlue;

           // listBox2.DataSource = controler.filtarGasesnoblesLinq();
            labelCategoria.Text = "Gases Nobles";



            //activar   gases nobles
            btnHe.Enabled=true;
            btnHe.BackColor = gasesNobles;

            btnNe.Enabled=true;
            btnNe.BackColor = gasesNobles;

            btnAr.Enabled=true;
            btnAr.BackColor = gasesNobles;

            btnKr.Enabled=true;
            btnKr.BackColor = gasesNobles;

            btnXe.Enabled=true;
            btnXe.BackColor = gasesNobles;

            btnRn.Enabled=true;
            btnRn.BackColor = gasesNobles;

            btnOg.Enabled=true;
            btnOg.BackColor = gasesNobles;
            //fin
            //---------------------------------






            //desactivar los que no son gases nobles

            //Gold

            btnH.Enabled=false;
            btnH.BackColor = desactivado;

            btnLi.Enabled=false;
            btnLi.BackColor = desactivado;

            btnNa.Enabled=false;
            btnNa.BackColor = desactivado;

            btnK.Enabled=false;
            btnK.BackColor = desactivado;

            btnRb.Enabled=false;
            btnRb.BackColor = desactivado;

            btnCs.Enabled=false;
            btnCs.BackColor = desactivado;

            btnFr.Enabled=false;
            btnFr.BackColor = desactivado;

            //Final Gold
            //--------------------------------------
            //mostaza
            btnBe.Enabled=false;
            btnBe.BackColor = desactivado;
            //btnBe.Visible= false;

            btnMg.Enabled=false;
            btnMg.BackColor = desactivado;

            btnCa.Enabled=false;
            btnCa.BackColor = desactivado;

            btnSr.Enabled=false;
            btnSr.BackColor = desactivado;

            btnBa.Enabled=false;
            btnBa.BackColor = desactivado;

            btnRa.Enabled=false;
            btnRa.BackColor = desactivado;

            //fin mostaza

            //-------------------------------------------------
            
            // Agregados por Erick 
            //verdes
            
            btnSc.Enabled=false;
            btnSc.BackColor = desactivado;

            btnY.Enabled=false;
            btnY.BackColor = desactivado;

            btnTi.Enabled=false;
            btnTi.BackColor = desactivado;

            btnZr.Enabled=false;
            btnZr.BackColor = desactivado;

            btnHf.Enabled=false;
            btnHf.BackColor = desactivado;

            btnRf.Enabled=false;
            btnRf.BackColor = desactivado;

            btnV.Enabled=false;
            btnV.BackColor = desactivado;

            btnNb.Enabled=false;
            btnNb.BackColor = desactivado;

            btnTa.Enabled=false;
            btnTa.BackColor = desactivado;

            btnDb.Enabled=false;
            btnDb.BackColor = desactivado;

            btnCr.Enabled=false;
            btnCr.BackColor = desactivado;

            btnMo.Enabled=false;
            btnMo.BackColor = desactivado;

            btnW.Enabled=false;
            btnW.BackColor = desactivado;

            btnSg.Enabled=false;
            btnSg.BackColor = desactivado;

            btnMn.Enabled=false;
            btnMn.BackColor = desactivado;
            
            btnTc.Enabled=false;
            btnTc.BackColor = desactivado;

            btnRe.Enabled=false;
            btnRe.BackColor = desactivado;

            btnBh.Enabled=false;
            btnBh.BackColor = desactivado;

            btnFe.Enabled=false;
            btnFe.BackColor = desactivado;

            btnRu.Enabled=false;
            btnRu.BackColor = desactivado;

            btnOs.Enabled=false;
            btnOs.BackColor = desactivado;

            btnHs.Enabled=false;
            btnHs.BackColor = desactivado;

            btnCo.Enabled=false;
            btnCo.BackColor = desactivado;

            btnRh.Enabled=false;
            btnRh.BackColor = desactivado;

            btnIr.Enabled=false;
            btnIr.BackColor = desactivado;

            btnMt.Enabled = false;
            btnMt.BackColor = desactivado;

            btnNi.Enabled = false;
            btnNi.BackColor = desactivado;

            btnPd.Enabled = false;
            btnPd.BackColor = desactivado;

            btnPt.Enabled = false;
            btnPt.BackColor = desactivado;

            btnDs.Enabled = false;
            btnDs.BackColor = desactivado;

            btnCu.Enabled = false;
            btnCu.BackColor = desactivado;

            btnAg.Enabled = false;
            btnAg.BackColor = desactivado;

            btnAu.Enabled = false;
            btnAu.BackColor = desactivado;

            btnRg.Enabled = false;
            btnRg.BackColor = desactivado;

            btnZn.Enabled = false;
            btnZn.BackColor = desactivado;

            btnCd.Enabled = false;
            btnCd.BackColor = desactivado;

            btnHg.Enabled = false;
            btnHg.BackColor = desactivado;

            btnCn.Enabled = false;
            btnCn.BackColor = desactivado;
            //----------------------------------------------------------------------
            // Naranja
            btnAl.Enabled = false;
            btnAl.BackColor = desactivado;

            btnGa.Enabled = false;
            btnGa.BackColor = desactivado;

            btnIn.Enabled = false;
            btnIn.BackColor = desactivado;

            btnNh.Enabled = false;
            btnNh.BackColor = desactivado;

            btnTl.Enabled = false;
            btnTl.BackColor = desactivado;

            btnSn.Enabled = false;
            btnSn.BackColor = desactivado;

            btnPb.Enabled = false;
            btnPb.BackColor = desactivado;

            btnFl.Enabled = false;
            btnFl.BackColor = desactivado;

            btnBi.Enabled = false;
            btnBi.BackColor = desactivado;

            btnMc.Enabled = false;
            btnMc.BackColor = desactivado;

            btnLv.Enabled = false;
            btnLv.BackColor = desactivado;

            //----------------------------------------------------------------------
            //amrillos

            //descativar metaloides


            btnB.Enabled = false;
            btnB.BackColor = desactivado;

            btnSi.Enabled = false;
            btnSi.BackColor = desactivado;

            btnGe.Enabled = false;
            btnGe.BackColor = desactivado;

            btnAs.Enabled = false;
            btnAs.BackColor = desactivado;

            btnSb.Enabled = false;
            btnSb.BackColor = desactivado;

            btnTe.Enabled = false;
            btnTe.BackColor = desactivado;

            btnPo.Enabled = false;
            btnPo.BackColor = desactivado;


            //Color papaya XD
            btnC.Enabled = false;
            btnC.BackColor = desactivado;

            btnN.Enabled = false;
            btnN.BackColor = desactivado;

            btnP.Enabled = false;
            btnP.BackColor = desactivado;

            btnO.Enabled = false;
            btnO.BackColor = desactivado;

            btnS.Enabled = false;
            btnS.BackColor = desactivado;

            btnSe.Enabled = false;
            btnSe.BackColor = desactivado;

            //----------------------------------------------------------------------
            //Azul - DodgerBlue
            btnF.Enabled = false;
            btnF.BackColor = desactivado;

            btnCl.Enabled = false;
            btnCl.BackColor = desactivado;

            btnBr.Enabled = false;
            btnBr.BackColor = desactivado;

            btnI.Enabled = false;
            btnI.BackColor = desactivado;

            btnAt.Enabled = false;
            btnAt.BackColor = desactivado;

            btnTs.Enabled = false;
            btnTs.BackColor = desactivado;

            //----------------------------------------------------------------------
            //violeta
            btnX0.Enabled = false;
            btnX0.BackColor = desactivado;
            //----------------------------------------------------------------------
            //purpura
            btnX1.Enabled=false;
            btnX1.BackColor = desactivado;
            //----------------------------------------------------------------------





            //--Linea p�rpura y violeta descativa 
            btnLa.Enabled = false;
            btnLa.BackColor = desactivado;

            btnAc.Enabled = false;
            btnAc.BackColor = desactivado;

            btnCe.Enabled = false;
            btnCe.BackColor = desactivado;

            btnTh.Enabled = false;
            btnTh.BackColor = desactivado;

            btnPr.Enabled = false;
            btnPr.BackColor = desactivado;

            btnPa.Enabled = false;
            btnPa.BackColor = desactivado;

            btnNd.Enabled = false;
            btnNd.BackColor = desactivado;

            btnU.Enabled = false;
            btnU.BackColor = desactivado;

            btnPm.Enabled = false;
            btnPm.BackColor = desactivado;

            btnNp.Enabled = false;
            btnNp.BackColor = desactivado;

            btnSm.Enabled = false;
            btnSm.BackColor = desactivado;

            btnPu.Enabled = false;
            btnPu.BackColor = desactivado;

            btnEu.Enabled = false;
            btnEu.BackColor = desactivado;

            btnAm.Enabled = false;
            btnAm.BackColor = desactivado;

            btnGd.Enabled = false;
            btnGd.BackColor = desactivado;

            btnA.Enabled = false;
            btnA.BackColor = desactivado;

            btnTb.Enabled = false;
            btnTb.BackColor = desactivado;

            btnBk.Enabled = false;
            btnBk.BackColor = desactivado;

            btnDy.Enabled = false;
            btnDy.BackColor = desactivado;

            btnCf.Enabled = false;
            btnCf.BackColor = desactivado;

            btnHo.Enabled = false;
            btnHo.BackColor = desactivado;

            btnEs.Enabled = false;
            btnEs.BackColor = desactivado;

            btnEr.Enabled = false;
            btnEr.BackColor = desactivado;

            btnFm.Enabled = false;
            btnFm.BackColor = desactivado;

            btnTm.Enabled = false;
            btnTm.BackColor = desactivado;

            btnMd.Enabled = false;
            btnMd.BackColor = desactivado;

            btnYb.Enabled = false;
            btnYb.BackColor = desactivado;

            btnNo.Enabled = false;
            btnNo.BackColor = desactivado;

            btnLu.Enabled = false;
            btnLu.BackColor = desactivado;

            btnLr.Enabled = false;
            btnLr.BackColor = desactivado;



        }

        private void button2_Click(object sender, EventArgs e)
        {
          
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void label80_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                siglaA.Visible=false;
                siglaB.Visible=false;
                valenciaA.Visible=false;
                valenciaB.Visible=false;



                Sigla3.Visible=false;
                sigla4.Visible=false;
                Valencia3.Visible=false;
                valencia4.Visible=false;
            }
            else
            {
                siglaA.Visible=true;
                siglaB.Visible=true;
                valenciaA.Visible=true;
                valenciaB.Visible=true;



                Sigla3.Visible=false;
                sigla4.Visible=false;
                Valencia3.Visible=false;
                valencia4.Visible=false;
            }
           
            Random random = new Random();


            int numerro1 = random.Next(1, 118);//elementos
            int numerro11 = random.Next(1, 118);//elementos
            int numerro2 = random.Next(1, 15);//reaciones quimicas
    
            int valencia = random.Next(1, 7);//valencias
            int hidracido3 = random.Next(1, 3);//solo para hidracidos
            string resultado = "";

            string resultado2 = "";
            listBox1.DataSource = controler.filtrarSiglaCheck(numerro1);
            try
            {
               resultado = (string)listBox1.SelectedItem;
            }
            catch(Exception ex) { 
                
            }




            labelCategoria.Visible=false;

            acidos.Checked=false;
            gaseosos.Checked=false;

          


            switch (numerro2)
            {
                case 1:
                    Oxidosmetalicos.Checked=true;
                    labelCategoria.Text="Oxidos metalicos";
                    break;
                case 2:
                    OxidosNometalicos.Checked=true;
                    labelCategoria.Text="Oxidos No metalicos ";
                    break;
                case 3:
                    btnPer�xidos.Checked=true;
                    labelCategoria.Text=" Per�xidos ";
                    break;
                case 4:
                    Ozonidos.Checked=true;
                    labelCategoria.Text="Ozonidos ";
                    break;
                case 5:
                    Hidruros.Checked=true;
                    labelCategoria.Text="Hidruros ";
                    break;
                case 6:
                    Hidracidos.Checked=true;

           


                    switch (hidracido3)
                    {
                        case 1:
                           
                            acidos.Checked=true;
                            gaseosos.Checked=false;
                            labelCategoria.Text="Hidracidos Acido";
                            break;
                        case 2:
                            acidos.Checked=false;
                            gaseosos.Checked=true;
                            labelCategoria.Text="Hidracidos gaseoso";
                            break;

                    }


                    break;
                case 7:
                    Hidroxidos.Checked = true;
                    labelCategoria.Text = "Hidroxidos ";
                    break;
                case 8:
                    btnSuperOxidos.Checked = true;
                    labelCategoria.Text = "SuperOxidos ";
                    break;
                case 9:
                    btnOxacidos.Checked = true;
                    labelCategoria.Text = "Oxacidos ";
                    break;
                case 10:
                    btnTioacidos.Checked = true;
                    labelCategoria.Text = "Tioacidos ";
                    break;

                case 11:
                    btnSalesNeutras.Checked = true;
                    labelCategoria.Text = "SalesNeutras ";


                    listBox5.DataSource = controler.filtrarSiglaCheck(numerro11);
                    try
                    {
                        resultado2 = (string)listBox5.SelectedItem;
                    }
                    catch (Exception ex)
                    {

                    }


                    string r2 = resultado2;
                    siglaB.Text = r2;
                    valenciaB.Text=(valencia).ToString();
                    break;

                 case 12:
                    btnSalesAcidas.Checked = true;
                    labelCategoria.Text = "SalesAcidas ";
                    break;

                case 13:
                    btnPeroxoacidos.Checked = true;
                    labelCategoria.Text = "Peroxoacidos ";
                    break;
                case 14:
                    btnSalesBasiscas.Checked = true;
                    labelCategoria.Text = "SalesBasiscas ";
                    break;


            }

            string r1 = resultado;
            siglaA.Text = r1;
            valenciaA.Text=(valencia).ToString();


        }

        private void label83_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
                button9.PerformClick();
                //button1.PerformClick();
                repetir = false;

            
        }

        private void button3_Click(object sender, EventArgs e)

        {
            labelCategoria.Text="Todos";

            Color verde = Color.FromArgb(128, 255, 128);
            Color amarillo = Color.FromArgb(255, 255, 128);
            Color piel = Color.FromArgb(255, 192, 128);
            Color naranja = Color.FromArgb(255, 128, 0);
            Color mostaza = Color.FromArgb(192, 192, 0);
            Color gasesNobles = Color.SkyBlue;
            Color DodgerBlue = Color.DodgerBlue;
            Color gold = Color.Gold;
            Color violet = Color.Violet;
            Color purple = Color.Purple;

            //activar gases nobles
            btnHe.Enabled=true;
            btnHe.BackColor = gasesNobles;

            btnNe.Enabled=true;
            btnNe.BackColor = gasesNobles;

            btnAr.Enabled=true;
            btnAr.BackColor = gasesNobles;

            btnKr.Enabled=true;
            btnKr.BackColor = gasesNobles;

            btnXe.Enabled=true;
            btnXe.BackColor = gasesNobles;

            btnRn.Enabled=true;
            btnRn.BackColor = gasesNobles;

            btnOg.Enabled=true;
            btnOg.BackColor = gasesNobles;
            //fin

            //-----------------------------------------------------------------------
            //Gold
            btnH.Enabled=true;
            btnH.BackColor = gold;

            btnLi.Enabled=true;
            btnLi.BackColor = gold;

            btnNa.Enabled=true;
            btnNa.BackColor = gold;

            btnK.Enabled=true;
            btnK.BackColor = gold;

            btnRb.Enabled=true;
            btnRb.BackColor = gold;

            btnCs.Enabled=true;
            btnCs.BackColor = gold;

            btnFr.Enabled=true;
            btnFr.BackColor = gold;
            //fin Gold

            //----------------------------------------------------
                       
            //MOSTAZA
            //btnBe.Visible= true;

            //mostaza
            btnBe.Enabled=true;
            btnBe.BackColor = mostaza;
            //btnBe.Visible= false;

            btnMg.Enabled=true;
            btnMg.BackColor = mostaza;

            btnCa.Enabled=true;
            btnCa.BackColor = mostaza;

            btnSr.Enabled=true;
            btnSr.BackColor = mostaza;

            btnBa.Enabled=true;
            btnBa.BackColor = mostaza;

            btnRa.Enabled=true;
            btnRa.BackColor = mostaza;

            //fin mostaza
            //---------------------------------------------------------------------------
            //verdes


            btnSc.Enabled = true;
            btnSc.BackColor = verde;

            btnY.Enabled = true;
            btnY.BackColor = verde;

            btnTi.Enabled = true;
            btnTi.BackColor = verde;

            btnZr.Enabled = true;
            btnZr.BackColor = verde;

            btnHf.Enabled = true;
            btnHf.BackColor = verde;

            btnRf.Enabled = true;
            btnRf.BackColor = verde;

            btnV.Enabled = true;
            btnV.BackColor = verde;

            btnNb.Enabled = true;
            btnNb.BackColor = verde;

            btnTa.Enabled = true;
            btnTa.BackColor = verde;

            btnDb.Enabled = true;
            btnDb.BackColor = verde;

            btnCr.Enabled = true;
            btnCr.BackColor = verde;

            btnMo.Enabled = true;
            btnMo.BackColor = verde;

            btnW.Enabled = true;
            btnW.BackColor = verde;

            btnSg.Enabled = true;
            btnSg.BackColor = verde;

            btnMn.Enabled = true;
            btnMn.BackColor = verde;

            btnTc.Enabled = true;
            btnTc.BackColor = verde;

            btnRe.Enabled = true;
            btnRe.BackColor = verde;

            btnBh.Enabled = true;
            btnBh.BackColor = verde;

            btnFe.Enabled = true;
            btnFe.BackColor = verde;

            btnRu.Enabled = true;
            btnRu.BackColor = verde;

            btnOs.Enabled = true;
            btnOs.BackColor = verde;

            btnHs.Enabled = true;
            btnHs.BackColor = verde;

            btnCo.Enabled = true;
            btnCo.BackColor = verde;

            btnRh.Enabled = true;
            btnRh.BackColor = verde;

            btnIr.Enabled = true;
            btnIr.BackColor = verde;

            btnMt.Enabled = true;
            btnMt.BackColor = verde;

            btnNi.Enabled = true;
            btnNi.BackColor = verde;

            btnPd.Enabled = true;
            btnPd.BackColor = verde;

            btnPt.Enabled = true;
            btnPt.BackColor = verde;

            btnDs.Enabled = true;
            btnDs.BackColor = verde;

            btnCu.Enabled = true;
            btnCu.BackColor = verde;

            btnAg.Enabled = true;
            btnAg.BackColor = verde;

            btnAu.Enabled = true;
            btnAu.BackColor = verde;

            btnRg.Enabled = true;
            btnRg.BackColor = verde;

            btnZn.Enabled = true;
            btnZn.BackColor = verde;

            btnCd.Enabled = true;
            btnCd.BackColor = verde;

            btnHg.Enabled = true;
            btnHg.BackColor = verde;

            btnCn.Enabled = true;
            btnCn.BackColor = verde;




            //----------------------------------------------------------------------
            // Naranja

            btnAl.Enabled = true;
            btnAl.BackColor = naranja;

            btnGa.Enabled = true;
            btnGa.BackColor = naranja;

            btnIn.Enabled = true;
            btnIn.BackColor = naranja;

            btnTl.Enabled = true;
            btnTl.BackColor = naranja;

            btnNh.Enabled = true;
            btnNh.BackColor = naranja;

            btnSn.Enabled = true;
            btnSn.BackColor = naranja;

            btnPb.Enabled = true;
            btnPb.BackColor = naranja;

            btnFl.Enabled = true;
            btnFl.BackColor = naranja;

            btnBi.Enabled = true;
            btnBi.BackColor = naranja;

            btnMc.Enabled = true;
            btnMc.BackColor = naranja;

            btnLv.Enabled = true;
            btnLv.BackColor = naranja;

            //----------------------------------------------------------------------
            //Color papaya XD
            btnC.Enabled = true;
            btnC.BackColor = piel;

            btnN.Enabled = true;
            btnN.BackColor = piel;

            btnP.Enabled = true;
            btnP.BackColor = piel;

            btnO.Enabled = true;
            btnO.BackColor = piel;

            btnS.Enabled = true;
            btnS.BackColor = piel;

            btnSe.Enabled = true;
            btnSe.BackColor = piel;

            //activar amarillos

            btnB.Enabled = true;
            btnB.BackColor = amarillo;

            btnSi.Enabled = true;
            btnSi.BackColor = amarillo;

            btnGe.Enabled = true;
            btnGe.BackColor = amarillo;

            btnAs.Enabled = true;
            btnAs.BackColor = amarillo;

            btnSb.Enabled = true;
            btnSb.BackColor = amarillo;

            btnTe.Enabled = true;
            btnTe.BackColor = amarillo;

            btnPo.Enabled = true;
            btnPo.BackColor = amarillo;





            //----------------------------------------------------------------------
            //Azul - DodgerBlue
            btnF.Enabled = true;
            btnF.BackColor = DodgerBlue;

            btnCl.Enabled = true;
            btnCl.BackColor = DodgerBlue;

            btnBr.Enabled = true;
            btnBr.BackColor = DodgerBlue;

            btnI.Enabled = true;
            btnI.BackColor = DodgerBlue;

            btnAt.Enabled = true;
            btnAt.BackColor = DodgerBlue;

            btnTs.Enabled = true;
            btnTs.BackColor = DodgerBlue;

            //----------------------------------------------------------------------
            //violeta
            btnX0.Enabled = true;
            btnX0.BackColor = violet;
            //----------------------------------------------------------------------
            //purpura
            btnX1.Enabled=true;
            btnX1.BackColor = purple;
            //----------------------------------------------------------------------

            //--Linea p�rpura activar 
            btnLa.Enabled = true;
            btnLa.BackColor = violet;

            btnAc.Enabled = true;
            btnAc.BackColor = purple;

            btnCe.Enabled = true;
            btnCe.BackColor = violet;

            btnTh.Enabled = true;
            btnTh.BackColor = purple;

            btnPr.Enabled = true;
            btnPr.BackColor = violet;

            btnPa.Enabled = true;
            btnPa.BackColor = purple;

            btnNd.Enabled = true;
            btnNd.BackColor = violet;

            btnU.Enabled = true;
            btnU.BackColor = purple;

            btnPm.Enabled = true;
            btnPm.BackColor = violet;

            btnNp.Enabled = true;
            btnNp.BackColor = purple;

            btnSm.Enabled = true;
            btnSm.BackColor = violet;

            btnPu.Enabled = true;
            btnPu.BackColor = purple;

            btnEu.Enabled = true;
            btnEu.BackColor = violet;

            btnAm.Enabled = true;
            btnAm.BackColor = purple;

            btnGd.Enabled = true;
            btnGd.BackColor = violet;

            btnA.Enabled = true;
            btnA.BackColor = purple;

            btnTb.Enabled = true;
            btnTb.BackColor = violet;

            btnBk.Enabled = true;
            btnBk.BackColor = purple;

            btnDy.Enabled = true;
            btnDy.BackColor = violet;

            btnCf.Enabled = true;
            btnCf.BackColor = purple; 

            btnHo.Enabled = true;
            btnHo.BackColor = violet;

            btnEs.Enabled = true;
            btnEs.BackColor = purple;

            btnEr.Enabled = true;
            btnEr.BackColor = violet;

            btnFm.Enabled = true;
            btnFm.BackColor = purple;

            btnTm.Enabled = true;
            btnTm.BackColor = violet;

            btnMd.Enabled = true;
            btnMd.BackColor = purple; 

            btnYb.Enabled = true;
            btnYb.BackColor = violet;

            btnNo.Enabled = true;
            btnNo.BackColor = purple;

            btnLu.Enabled = true;
            btnLu.BackColor = violet;

            btnLr.Enabled = true;
            btnLr.BackColor = purple;

        }

        private void radioButton1_CheckedChanged_2(object sender, EventArgs e)
        {
            siglaB.Text = "O";
            valenciaB.Text = "+3";


            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;

        }

        private void label34_Click(object sender, EventArgs e)
        {
            
        }

        private void labelResultado_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Color desactivado = Color.Gray;
            Color gold = Color.Gold;


            //activar   gases nobles
            btnHe.Enabled=false;
            btnHe.BackColor = desactivado;

            btnNe.Enabled=false;
            btnNe.BackColor = desactivado;

            btnAr.Enabled=false;
            btnAr.BackColor = desactivado;

            btnKr.Enabled=false;
            btnKr.BackColor = desactivado;

            btnXe.Enabled=false;
            btnXe.BackColor = desactivado;

            btnRn.Enabled=false;
            btnRn.BackColor = desactivado;

            btnOg.Enabled=true;
            btnOg.BackColor = desactivado;
            //fin
            //---------------------------------






            //desactivar los que no son gases nobles

            //Gold

            btnH.Enabled=true;
            btnH.BackColor = desactivado;

            btnLi.Enabled=true;
            btnLi.BackColor = desactivado;

            btnNa.Enabled=true;
            btnNa.BackColor = gold;

            btnK.Enabled=true;
            btnK.BackColor = gold;

            btnRb.Enabled=true;
            btnRb.BackColor = gold;

            btnCs.Enabled=true;
            btnCs.BackColor = gold;

            btnFr.Enabled=false;
            btnFr.BackColor = desactivado;

            //Final Gold
            //--------------------------------------
            //mostaza
            btnBe.Enabled=false;
            btnBe.BackColor = desactivado;
            //btnBe.Visible= false;

            btnMg.Enabled=false;
            btnMg.BackColor = desactivado;

            btnCa.Enabled=false;
            btnCa.BackColor = desactivado;

            btnSr.Enabled=false;
            btnSr.BackColor = desactivado;

            btnBa.Enabled=false;
            btnBa.BackColor = desactivado;

            btnRa.Enabled=false;
            btnRa.BackColor = desactivado;

            //fin mostaza

            //-------------------------------------------------

            // Agregados por Erick 
            //verdes

            btnSc.Enabled=false;
            btnSc.BackColor = desactivado;

            btnY.Enabled=false;
            btnY.BackColor = desactivado;

            btnTi.Enabled=false;
            btnTi.BackColor = desactivado;

            btnZr.Enabled=false;
            btnZr.BackColor = desactivado;

            btnHf.Enabled=false;
            btnHf.BackColor = desactivado;

            btnRf.Enabled=false;
            btnRf.BackColor = desactivado;

            btnV.Enabled=false;
            btnV.BackColor = desactivado;

            btnNb.Enabled=false;
            btnNb.BackColor = desactivado;

            btnTa.Enabled=false;
            btnTa.BackColor = desactivado;

            btnDb.Enabled=false;
            btnDb.BackColor = desactivado;

            btnCr.Enabled=false;
            btnCr.BackColor = desactivado;

            btnMo.Enabled=false;
            btnMo.BackColor = desactivado;

            btnW.Enabled=false;
            btnW.BackColor = desactivado;

            btnSg.Enabled=false;
            btnSg.BackColor = desactivado;

            btnMn.Enabled=false;
            btnMn.BackColor = desactivado;

            btnTc.Enabled=false;
            btnTc.BackColor = desactivado;

            btnRe.Enabled=false;
            btnRe.BackColor = desactivado;

            btnBh.Enabled=false;
            btnBh.BackColor = desactivado;

            btnFe.Enabled=false;
            btnFe.BackColor = desactivado;

            btnRu.Enabled=false;
            btnRu.BackColor = desactivado;

            btnOs.Enabled=false;
            btnOs.BackColor = desactivado;

            btnHs.Enabled=false;
            btnHs.BackColor = desactivado;

            btnCo.Enabled=false;
            btnCo.BackColor = desactivado;

            btnRh.Enabled=false;
            btnRh.BackColor = desactivado;

            btnIr.Enabled=false;
            btnIr.BackColor = desactivado;

            btnMt.Enabled = false;
            btnMt.BackColor = desactivado;

            btnNi.Enabled = false;
            btnNi.BackColor = desactivado;

            btnPd.Enabled = false;
            btnPd.BackColor = desactivado;

            btnPt.Enabled = false;
            btnPt.BackColor = desactivado;

            btnDs.Enabled = false;
            btnDs.BackColor = desactivado;

            btnCu.Enabled = false;
            btnCu.BackColor = desactivado;

            btnAg.Enabled = false;
            btnAg.BackColor = desactivado;

            btnAu.Enabled = false;
            btnAu.BackColor = desactivado;

            btnRg.Enabled = false;
            btnRg.BackColor = desactivado;

            btnZn.Enabled = false;
            btnZn.BackColor = desactivado;

            btnCd.Enabled = false;
            btnCd.BackColor = desactivado;

            btnHg.Enabled = false;
            btnHg.BackColor = desactivado;

            btnCn.Enabled = false;
            btnCn.BackColor = desactivado;
            //----------------------------------------------------------------------
            // Naranja
            btnAl.Enabled = false;
            btnAl.BackColor = desactivado;

            btnGa.Enabled = false;
            btnGa.BackColor = desactivado;

            btnIn.Enabled = false;
            btnIn.BackColor = desactivado;

            btnNh.Enabled = false;
            btnNh.BackColor = desactivado;

            btnTl.Enabled = false;
            btnTl.BackColor = desactivado;

            btnSn.Enabled = false;
            btnSn.BackColor = desactivado;

            btnPb.Enabled = false;
            btnPb.BackColor = desactivado;

            btnFl.Enabled = false;
            btnFl.BackColor = desactivado;

            btnBi.Enabled = false;
            btnBi.BackColor = desactivado;

            btnMc.Enabled = false;
            btnMc.BackColor = desactivado;

            btnLv.Enabled = false;
            btnLv.BackColor = desactivado;

            //----------------------------------------------------------------------
            //amrillos

            //descativar metaloides


            btnB.Enabled = false;
            btnB.BackColor = desactivado;

            btnSi.Enabled = false;
            btnSi.BackColor = desactivado;

            btnGe.Enabled = false;
            btnGe.BackColor = desactivado;

            btnAs.Enabled = false;
            btnAs.BackColor = desactivado;

            btnSb.Enabled = false;
            btnSb.BackColor = desactivado;

            btnTe.Enabled = false;
            btnTe.BackColor = desactivado;

            btnPo.Enabled = false;
            btnPo.BackColor = desactivado;


            //Color papaya XD
            btnC.Enabled = false;
            btnC.BackColor = desactivado;

            btnN.Enabled = false;
            btnN.BackColor = desactivado;

            btnP.Enabled = false;
            btnP.BackColor = desactivado;

            btnO.Enabled = false;
            btnO.BackColor = desactivado;

            btnS.Enabled = false;
            btnS.BackColor = desactivado;

            btnSe.Enabled = false;
            btnSe.BackColor = desactivado;

            //----------------------------------------------------------------------
            //Azul - DodgerBlue
            btnF.Enabled = false;
            btnF.BackColor = desactivado;

            btnCl.Enabled = false;
            btnCl.BackColor = desactivado;

            btnBr.Enabled = false;
            btnBr.BackColor = desactivado;

            btnI.Enabled = false;
            btnI.BackColor = desactivado;

            btnAt.Enabled = false;
            btnAt.BackColor = desactivado;

            btnTs.Enabled = false;
            btnTs.BackColor = desactivado;

            //----------------------------------------------------------------------
            //violeta
            btnX0.Enabled = false;
            btnX0.BackColor = desactivado;
            //----------------------------------------------------------------------
            //purpura
            btnX1.Enabled=false;
            btnX1.BackColor = desactivado;
            //----------------------------------------------------------------------





            //--Linea p�rpura y violeta descativa 
            btnLa.Enabled = false;
            btnLa.BackColor = desactivado;

            btnAc.Enabled = false;
            btnAc.BackColor = desactivado;

            btnCe.Enabled = false;
            btnCe.BackColor = desactivado;

            btnTh.Enabled = false;
            btnTh.BackColor = desactivado;

            btnPr.Enabled = false;
            btnPr.BackColor = desactivado;

            btnPa.Enabled = false;
            btnPa.BackColor = desactivado;

            btnNd.Enabled = false;
            btnNd.BackColor = desactivado;

            btnU.Enabled = false;
            btnU.BackColor = desactivado;

            btnPm.Enabled = false;
            btnPm.BackColor = desactivado;

            btnNp.Enabled = false;
            btnNp.BackColor = desactivado;

            btnSm.Enabled = false;
            btnSm.BackColor = desactivado;

            btnPu.Enabled = false;
            btnPu.BackColor = desactivado;

            btnEu.Enabled = false;
            btnEu.BackColor = desactivado;

            btnAm.Enabled = false;
            btnAm.BackColor = desactivado;

            btnGd.Enabled = false;
            btnGd.BackColor = desactivado;

            btnA.Enabled = false;
            btnA.BackColor = desactivado;

            btnTb.Enabled = false;
            btnTb.BackColor = desactivado;

            btnBk.Enabled = false;
            btnBk.BackColor = desactivado;

            btnDy.Enabled = false;
            btnDy.BackColor = desactivado;

            btnCf.Enabled = false;
            btnCf.BackColor = desactivado;

            btnHo.Enabled = false;
            btnHo.BackColor = desactivado;

            btnEs.Enabled = false;
            btnEs.BackColor = desactivado;

            btnEr.Enabled = false;
            btnEr.BackColor = desactivado;

            btnFm.Enabled = false;
            btnFm.BackColor = desactivado;

            btnTm.Enabled = false;
            btnTm.BackColor = desactivado;

            btnMd.Enabled = false;
            btnMd.BackColor = desactivado;

            btnYb.Enabled = false;
            btnYb.BackColor = desactivado;

            btnNo.Enabled = false;
            btnNo.BackColor = desactivado;

            btnLu.Enabled = false;
            btnLu.BackColor = desactivado;

            btnLr.Enabled = false;
            btnLr.BackColor = desactivado;


        }

        private void Hidruros_CheckedChanged(object sender, EventArgs e)
        {

            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;

            siglaB.Text = "H";
            valenciaB.Text = "-1";
        }

        private void valenciaB_TextChanged(object sender, EventArgs e)
        {

        }

        private void Hidracidos_CheckedChanged(object sender, EventArgs e)
        {
            siglaB.Text = "H";

            if (Hidracidos.Checked==true)
            {
                gaseosos.Visible=true;
                acidos.Visible=true;
            } else 
            {
                gaseosos.Visible=false;
                acidos.Visible=false;
            }




            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;
          

        }

        private void acidos_CheckedChanged(object sender, EventArgs e)
        {
            valenciaB.Text = "-1";
        }

        private void gaseosos_CheckedChanged(object sender, EventArgs e)
        {
            valenciaB.Text = "2";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Color desactivado = Color.Gray;
            Color verde = Color.FromArgb(128, 255, 128);
            Color amarillo = Color.FromArgb(255, 255, 128);
            Color piel = Color.FromArgb(255, 192, 128);
            Color naranja = Color.FromArgb(255, 128, 0);
            Color mostaza = Color.FromArgb(192, 192, 0);
            Color gasesNobles = Color.SkyBlue;
            Color DodgerBlue = Color.DodgerBlue;
            Color gold = Color.Gold;
            Color violet = Color.Violet;
            Color purple = Color.Purple;

            // listBox2.DataSource = controler.filtarGasesnoblesLinq();
            labelCategoria.Text = "Hidracidos";



            //activar   gases nobles
            btnHe.Enabled = false;
            btnHe.BackColor = desactivado;

            btnNe.Enabled = false;
            btnNe.BackColor = desactivado;

            btnAr.Enabled = false;
            btnAr.BackColor = desactivado;

            btnKr.Enabled = false;
            btnKr.BackColor = desactivado;

            btnXe.Enabled = false;
            btnXe.BackColor = desactivado;

            btnRn.Enabled = false;
            btnRn.BackColor = desactivado;

            btnOg.Enabled = false;
            btnOg.BackColor = desactivado;
            //fin
            //---------------------------------






            //desactivar los que no son gases nobles

            //Gold

            btnH.Enabled = false;
            btnH.BackColor = desactivado;

            btnLi.Enabled = false;
            btnLi.BackColor = desactivado;

            btnNa.Enabled = false;
            btnNa.BackColor = desactivado;

            btnK.Enabled = false;
            btnK.BackColor = desactivado;

            btnRb.Enabled = false;
            btnRb.BackColor = desactivado;

            btnCs.Enabled = false;
            btnCs.BackColor = desactivado;

            btnFr.Enabled = false;
            btnFr.BackColor = desactivado;

            //Final Gold
            //--------------------------------------
            //mostaza
            btnBe.Enabled = false;
            btnBe.BackColor = desactivado;
            //btnBe.Visible= false;

            btnMg.Enabled = false;
            btnMg.BackColor = desactivado;

            btnCa.Enabled = false;
            btnCa.BackColor = desactivado;

            btnSr.Enabled = false;
            btnSr.BackColor = desactivado;

            btnBa.Enabled = false;
            btnBa.BackColor = desactivado;

            btnRa.Enabled = false;
            btnRa.BackColor = desactivado;

            //fin mostaza

            //-------------------------------------------------

            // Agregados por Erick 
            //verdes

            btnSc.Enabled = false;
            btnSc.BackColor = desactivado;

            btnY.Enabled = false;
            btnY.BackColor = desactivado;

            btnTi.Enabled = false;
            btnTi.BackColor = desactivado;

            btnZr.Enabled = false;
            btnZr.BackColor = desactivado;

            btnHf.Enabled = false;
            btnHf.BackColor = desactivado;

            btnRf.Enabled = false;
            btnRf.BackColor = desactivado;

            btnV.Enabled = false;
            btnV.BackColor = desactivado;

            btnNb.Enabled = false;
            btnNb.BackColor = desactivado;

            btnTa.Enabled = false;
            btnTa.BackColor = desactivado;

            btnDb.Enabled = false;
            btnDb.BackColor = desactivado;

            btnCr.Enabled = false;
            btnCr.BackColor = desactivado;

            btnMo.Enabled = false;
            btnMo.BackColor = desactivado;

            btnW.Enabled = false;
            btnW.BackColor = desactivado;

            btnSg.Enabled = false;
            btnSg.BackColor = desactivado;

            btnMn.Enabled = false;
            btnMn.BackColor = desactivado;

            btnTc.Enabled = false;
            btnTc.BackColor = desactivado;

            btnRe.Enabled = false;
            btnRe.BackColor = desactivado;

            btnBh.Enabled = false;
            btnBh.BackColor = desactivado;

            btnFe.Enabled = false;
            btnFe.BackColor = desactivado;

            btnRu.Enabled = false;
            btnRu.BackColor = desactivado;

            btnOs.Enabled = false;
            btnOs.BackColor = desactivado;

            btnHs.Enabled = false;
            btnHs.BackColor = desactivado;

            btnCo.Enabled = false;
            btnCo.BackColor = desactivado;

            btnRh.Enabled = false;
            btnRh.BackColor = desactivado;

            btnIr.Enabled = false;
            btnIr.BackColor = desactivado;

            btnMt.Enabled = false;
            btnMt.BackColor = desactivado;

            btnNi.Enabled = false;
            btnNi.BackColor = desactivado;

            btnPd.Enabled = false;
            btnPd.BackColor = desactivado;

            btnPt.Enabled = false;
            btnPt.BackColor = desactivado;

            btnDs.Enabled = false;
            btnDs.BackColor = desactivado;

            btnCu.Enabled = false;
            btnCu.BackColor = desactivado;

            btnAg.Enabled = false;
            btnAg.BackColor = desactivado;

            btnAu.Enabled = false;
            btnAu.BackColor = desactivado;

            btnRg.Enabled = false;
            btnRg.BackColor = desactivado;

            btnZn.Enabled = false;
            btnZn.BackColor = desactivado;

            btnCd.Enabled = false;
            btnCd.BackColor = desactivado;

            btnHg.Enabled = false;
            btnHg.BackColor = desactivado;

            btnCn.Enabled = true;
            btnCn.BackColor = verde;
            //----------------------------------------------------------------------
            // Naranja
            btnAl.Enabled = false;
            btnAl.BackColor = desactivado;

            btnGa.Enabled = false;
            btnGa.BackColor = desactivado;

            btnIn.Enabled = false;
            btnIn.BackColor = desactivado;

            btnNh.Enabled = false;
            btnNh.BackColor = desactivado;

            btnTl.Enabled = false;
            btnTl.BackColor = desactivado;

            btnSn.Enabled = false;
            btnSn.BackColor = desactivado;

            btnPb.Enabled = false;
            btnPb.BackColor = desactivado;

            btnFl.Enabled = false;
            btnFl.BackColor = desactivado;

            btnBi.Enabled = false;
            btnBi.BackColor = desactivado;

            btnMc.Enabled = false;
            btnMc.BackColor = desactivado;

            btnLv.Enabled = false;
            btnLv.BackColor = desactivado;

            //----------------------------------------------------------------------
            //amrillos

            //descativar metaloides


            btnB.Enabled = false;
            btnB.BackColor = desactivado;

            btnSi.Enabled = false;
            btnSi.BackColor = desactivado;

            btnGe.Enabled = false;
            btnGe.BackColor = desactivado;

            btnAs.Enabled = false;
            btnAs.BackColor = desactivado;

            btnSb.Enabled = false;
            btnSb.BackColor = desactivado;

            btnTe.Enabled = true;
            btnTe.BackColor = amarillo;

            btnPo.Enabled = false;
            btnPo.BackColor = desactivado;


            //Color papaya XD
            btnC.Enabled = false;
            btnC.BackColor = desactivado;

            btnN.Enabled = false;
            btnN.BackColor = desactivado;

            btnP.Enabled = false;
            btnP.BackColor = desactivado;

            btnO.Enabled = false;
            btnO.BackColor = desactivado;

            btnS.Enabled = true;
            btnS.BackColor = piel;

            btnSe.Enabled = true;
            btnSe.BackColor = piel;

            //----------------------------------------------------------------------
            //Azul - DodgerBlue
            btnF.Enabled = true;
            btnF.BackColor = DodgerBlue;

            btnCl.Enabled = true;
            btnCl.BackColor = DodgerBlue;

            btnBr.Enabled = true;
            btnBr.BackColor = DodgerBlue;

            btnI.Enabled = true;
            btnI.BackColor = DodgerBlue;

            btnAt.Enabled = false;
            btnAt.BackColor = desactivado;

            btnTs.Enabled = false;
            btnTs.BackColor = desactivado;

            //----------------------------------------------------------------------
            //violeta
            btnX0.Enabled = false;
            btnX0.BackColor = desactivado;
            //----------------------------------------------------------------------
            //purpura
            btnX1.Enabled = false;
            btnX1.BackColor = desactivado;
            //----------------------------------------------------------------------





            //--Linea p�rpura y violeta descativa 
            btnLa.Enabled = false;
            btnLa.BackColor = desactivado;

            btnAc.Enabled = false;
            btnAc.BackColor = desactivado;

            btnCe.Enabled = false;
            btnCe.BackColor = desactivado;

            btnTh.Enabled = false;
            btnTh.BackColor = desactivado;

            btnPr.Enabled = false;
            btnPr.BackColor = desactivado;

            btnPa.Enabled = false;
            btnPa.BackColor = desactivado;

            btnNd.Enabled = false;
            btnNd.BackColor = desactivado;

            btnU.Enabled = false;
            btnU.BackColor = desactivado;

            btnPm.Enabled = false;
            btnPm.BackColor = desactivado;

            btnNp.Enabled = false;
            btnNp.BackColor = desactivado;

            btnSm.Enabled = false;
            btnSm.BackColor = desactivado;

            btnPu.Enabled = false;
            btnPu.BackColor = desactivado;

            btnEu.Enabled = false;
            btnEu.BackColor = desactivado;

            btnAm.Enabled = false;
            btnAm.BackColor = desactivado;

            btnGd.Enabled = false;
            btnGd.BackColor = desactivado;

            btnA.Enabled = false;
            btnA.BackColor = desactivado;

            btnTb.Enabled = false;
            btnTb.BackColor = desactivado;

            btnBk.Enabled = false;
            btnBk.BackColor = desactivado;

            btnDy.Enabled = false;
            btnDy.BackColor = desactivado;

            btnCf.Enabled = false;
            btnCf.BackColor = desactivado;

            btnHo.Enabled = false;
            btnHo.BackColor = desactivado;

            btnEs.Enabled = false;
            btnEs.BackColor = desactivado;

            btnEr.Enabled = false;
            btnEr.BackColor = desactivado;

            btnFm.Enabled = false;
            btnFm.BackColor = desactivado;

            btnTm.Enabled = false;
            btnTm.BackColor = desactivado;

            btnMd.Enabled = false;
            btnMd.BackColor = desactivado;

            btnYb.Enabled = false;
            btnYb.BackColor = desactivado;

            btnNo.Enabled = false;
            btnNo.BackColor = desactivado;

            btnLu.Enabled = false;
            btnLu.BackColor = desactivado;

            btnLr.Enabled = false;
            btnLr.BackColor = desactivado;



        }

        private void Hidroxidos_CheckedChanged(object sender, EventArgs e)
        {
            Sigla3.Visible = true;
            Valencia3.Visible = true;
            label33.Visible=    true;
            label32.Visible=    true;



            siglaB.Text = "O";
            valenciaB.Text = "-2";

            Sigla3.Text = "H";
            Valencia3.Text = "1";


       

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;
        }

        private void labelCategoria_Click(object sender, EventArgs e)
        {

        }

        private void btnTioacidos_CheckedChanged(object sender, EventArgs e)
        {

            Sigla3.Visible = true;
            Valencia3.Visible = true;
            label33.Visible=    true;
            label32.Visible=    true;

            sigla4.Visible=true;
            label158.Visible=true;
            valencia4.Visible=true;
            label35.Visible=true;


            siglaA.Text= "H";
            siglaB.Text= "O";
            Sigla3.Text= "S";

        }

        private void btnOxacidos_CheckedChanged(object sender, EventArgs e)
        {
            Sigla3.Visible = true;
            Valencia3.Visible = true;
            label33.Visible=    true;
            label32.Visible=    true;



            siglaB.Text = "O";
            valenciaB.Text = "-2";

            Sigla3.Text = "H";
            Valencia3.Text = "1";


            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Sigla3.Visible = true;
            Valencia3.Visible = true;
            label33.Visible=    true;
            label32.Visible=    true;



            siglaB.Text = "H";
            valenciaB.Text = "1";

            Sigla3.Text = "CO";
            Valencia3.Text = "3";


            sigla4.Visible=false;
            label158.Visible=false;

            valencia4.Visible=false;
            label35.Visible=false;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

            Sigla3.Visible = true;
            Valencia3.Visible = true;
            label33.Visible=    true;
            label32.Visible=    true;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;
            Sigla3.Text="OH";
           

        }

        private void btnSuperOxidos_CheckedChanged(object sender, EventArgs e)
        {



            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;

            siglaB.Text = "O";
            valenciaB.Text = "-2";
        }

        private void label40_Click_1(object sender, EventArgs e)
        {
               if (checkBox1.Checked==false && btnPeroxoacidos.Checked==true)
            {
                siglaB.Text = "PO";
                siglaA.Text = "H";


            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

            Sigla3.Visible = false;
            Valencia3.Visible = false;
            label33.Visible=    false;
            label32.Visible=    false;

            sigla4.Visible=false;
            label158.Visible=false;
            valencia4.Visible=false;
            label35.Visible=false;

            siglaA.Text="H";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Color desactivado = Color.Gray;
            Color verde = Color.FromArgb(128, 255, 128);
            Color amarillo = Color.FromArgb(255, 255, 128);
            Color piel = Color.FromArgb(255, 192, 128);
            Color naranja = Color.FromArgb(255, 128, 0);
            Color mostaza = Color.FromArgb(192, 192, 0);
            Color gasesNobles = Color.SkyBlue;
            Color DodgerBlue = Color.DodgerBlue;
            Color gold = Color.Gold;
            Color violet = Color.Violet;
            Color purple = Color.Purple;

            // listBox2.DataSource = controler.filtarGasesnoblesLinq();
            labelCategoria.Text = "Peroxo�cidos";



            //activar   gases nobles
            btnHe.Enabled=true;
            btnHe.BackColor = desactivado;

            btnNe.Enabled=true;
            btnNe.BackColor = desactivado;

            btnAr.Enabled=true;
            btnAr.BackColor = desactivado;

            btnKr.Enabled=true;
            btnKr.BackColor = desactivado;

            btnXe.Enabled=true;
            btnXe.BackColor = desactivado;

            btnRn.Enabled=true;
            btnRn.BackColor = desactivado;

            btnOg.Enabled=true;
            btnOg.BackColor = desactivado;
            //fin
            //---------------------------------






            //desactivar los que no son gases nobles

            //Gold

            btnH.Enabled=false;
            btnH.BackColor = desactivado;

            btnLi.Enabled=false;
            btnLi.BackColor = desactivado;

            btnNa.Enabled=false;
            btnNa.BackColor = desactivado;

            btnK.Enabled=false;
            btnK.BackColor = desactivado;

            btnRb.Enabled=false;
            btnRb.BackColor = desactivado;

            btnCs.Enabled=false;
            btnCs.BackColor = desactivado;

            btnFr.Enabled=false;
            btnFr.BackColor = desactivado;

            //Final Gold
            //--------------------------------------
            //mostaza
            btnBe.Enabled=false;
            btnBe.BackColor = desactivado;
            //btnBe.Visible= false;

            btnMg.Enabled=false;
            btnMg.BackColor = desactivado;

            btnCa.Enabled=false;
            btnCa.BackColor = desactivado;

            btnSr.Enabled=false;
            btnSr.BackColor = desactivado;

            btnBa.Enabled=false;
            btnBa.BackColor = desactivado;

            btnRa.Enabled=false;
            btnRa.BackColor = desactivado;

            //fin mostaza

            //-------------------------------------------------

            // Agregados por Erick 
            //verdes

            btnSc.Enabled=false;
            btnSc.BackColor = desactivado;

            btnY.Enabled=false;
            btnY.BackColor = desactivado;

            btnTi.Enabled=false;
            btnTi.BackColor = desactivado;

            btnZr.Enabled=false;
            btnZr.BackColor = desactivado;

            btnHf.Enabled=false;
            btnHf.BackColor = desactivado;

            btnRf.Enabled=false;
            btnRf.BackColor = desactivado;

            btnV.Enabled=false;
            btnV.BackColor = desactivado;

            btnNb.Enabled=false;
            btnNb.BackColor = desactivado;

            btnTa.Enabled=false;
            btnTa.BackColor = desactivado;

            btnDb.Enabled=false;
            btnDb.BackColor = desactivado;

            btnCr.Enabled=false;
            btnCr.BackColor = desactivado;

            btnMo.Enabled=false;
            btnMo.BackColor = desactivado;

            btnW.Enabled=false;
            btnW.BackColor = desactivado;

            btnSg.Enabled=false;
            btnSg.BackColor = desactivado;

            btnMn.Enabled=false;
            btnMn.BackColor = desactivado;

            btnTc.Enabled=false;
            btnTc.BackColor = desactivado;

            btnRe.Enabled=false;
            btnRe.BackColor = desactivado;

            btnBh.Enabled=false;
            btnBh.BackColor = desactivado;

            btnFe.Enabled=false;
            btnFe.BackColor = desactivado;

            btnRu.Enabled=false;
            btnRu.BackColor = desactivado;

            btnOs.Enabled=false;
            btnOs.BackColor = desactivado;

            btnHs.Enabled=false;
            btnHs.BackColor = desactivado;

            btnCo.Enabled=false;
            btnCo.BackColor = desactivado;

            btnRh.Enabled=false;
            btnRh.BackColor = desactivado;

            btnIr.Enabled=false;
            btnIr.BackColor = desactivado;

            btnMt.Enabled = false;
            btnMt.BackColor = desactivado;

            btnNi.Enabled = false;
            btnNi.BackColor = desactivado;

            btnPd.Enabled = false;
            btnPd.BackColor = desactivado;

            btnPt.Enabled = false;
            btnPt.BackColor = desactivado;

            btnDs.Enabled = false;
            btnDs.BackColor = desactivado;

            btnCu.Enabled = false;
            btnCu.BackColor = desactivado;

            btnAg.Enabled = false;
            btnAg.BackColor = desactivado;

            btnAu.Enabled = false;
            btnAu.BackColor = desactivado;

            btnRg.Enabled = false;
            btnRg.BackColor = desactivado;

            btnZn.Enabled = false;
            btnZn.BackColor = desactivado;

            btnCd.Enabled = false;
            btnCd.BackColor = desactivado;

            btnHg.Enabled = false;
            btnHg.BackColor = desactivado;

            btnCn.Enabled = false;
            btnCn.BackColor = desactivado;
            //----------------------------------------------------------------------
            // Naranja
            btnAl.Enabled = false;
            btnAl.BackColor = desactivado;

            btnGa.Enabled = false;
            btnGa.BackColor = desactivado;

            btnIn.Enabled = false;
            btnIn.BackColor = desactivado;

            btnNh.Enabled = false;
            btnNh.BackColor = desactivado;

            btnTl.Enabled = false;
            btnTl.BackColor = desactivado;

            btnSn.Enabled = false;
            btnSn.BackColor = desactivado;

            btnPb.Enabled = false;
            btnPb.BackColor = desactivado;

            btnFl.Enabled = false;
            btnFl.BackColor = desactivado;

            btnBi.Enabled = false;
            btnBi.BackColor = desactivado;

            btnMc.Enabled = false;
            btnMc.BackColor = desactivado;

            btnLv.Enabled = false;
            btnLv.BackColor = desactivado;

            //----------------------------------------------------------------------
            //amrillos

            //descativar metaloides


            btnB.Enabled = false;
            btnB.BackColor = desactivado;

            btnSi.Enabled = false;
            btnSi.BackColor = desactivado;

            btnGe.Enabled = false;
            btnGe.BackColor = desactivado;

            btnAs.Enabled = false;
            btnAs.BackColor = desactivado;

            btnSb.Enabled = false;
            btnSb.BackColor = desactivado;

            btnTe.Enabled = false;
            btnTe.BackColor = desactivado;

            btnPo.Enabled = false;
            btnPo.BackColor = desactivado;


            //Color papaya XD
            btnC.Enabled = false;
            btnC.BackColor = desactivado;

            btnN.Enabled = true;
            btnN.BackColor = piel;

            btnP.Enabled = true;
            btnP.BackColor = piel;

            btnO.Enabled = false;
            btnO.BackColor = desactivado;

            btnS.Enabled = true;
            btnS.BackColor = piel;

            btnSe.Enabled = false;
            btnSe.BackColor = desactivado;

            //----------------------------------------------------------------------
            //Azul - DodgerBlue
            btnF.Enabled = false;
            btnF.BackColor = desactivado;

            btnCl.Enabled = false;
            btnCl.BackColor = desactivado;

            btnBr.Enabled = false;
            btnBr.BackColor = desactivado;

            btnI.Enabled = false;
            btnI.BackColor = desactivado;

            btnAt.Enabled = false;
            btnAt.BackColor = desactivado;

            btnTs.Enabled = false;
            btnTs.BackColor = desactivado;

            //----------------------------------------------------------------------
            //violeta
            btnX0.Enabled = false;
            btnX0.BackColor = desactivado;
            //----------------------------------------------------------------------
            //purpura
            btnX1.Enabled=false;
            btnX1.BackColor = desactivado;
            //----------------------------------------------------------------------





            //--Linea p�rpura y violeta descativa 
            btnLa.Enabled = false;
            btnLa.BackColor = desactivado;

            btnAc.Enabled = false;
            btnAc.BackColor = desactivado;

            btnCe.Enabled = false;
            btnCe.BackColor = desactivado;

            btnTh.Enabled = false;
            btnTh.BackColor = desactivado;

            btnPr.Enabled = false;
            btnPr.BackColor = desactivado;

            btnPa.Enabled = false;
            btnPa.BackColor = desactivado;

            btnNd.Enabled = false;
            btnNd.BackColor = desactivado;

            btnU.Enabled = false;
            btnU.BackColor = desactivado;

            btnPm.Enabled = false;
            btnPm.BackColor = desactivado;

            btnNp.Enabled = false;
            btnNp.BackColor = desactivado;

            btnSm.Enabled = false;
            btnSm.BackColor = desactivado;

            btnPu.Enabled = false;
            btnPu.BackColor = desactivado;

            btnEu.Enabled = false;
            btnEu.BackColor = desactivado;

            btnAm.Enabled = false;
            btnAm.BackColor = desactivado;

            btnGd.Enabled = false;
            btnGd.BackColor = desactivado;

            btnA.Enabled = false;
            btnA.BackColor = desactivado;

            btnTb.Enabled = false;
            btnTb.BackColor = desactivado;

            btnBk.Enabled = false;
            btnBk.BackColor = desactivado;

            btnDy.Enabled = false;
            btnDy.BackColor = desactivado;

            btnCf.Enabled = false;
            btnCf.BackColor = desactivado;

            btnHo.Enabled = false;
            btnHo.BackColor = desactivado;

            btnEs.Enabled = false;
            btnEs.BackColor = desactivado;

            btnEr.Enabled = false;
            btnEr.BackColor = desactivado;

            btnFm.Enabled = false;
            btnFm.BackColor = desactivado;

            btnTm.Enabled = false;
            btnTm.BackColor = desactivado;

            btnMd.Enabled = false;
            btnMd.BackColor = desactivado;

            btnYb.Enabled = false;
            btnYb.BackColor = desactivado;

            btnNo.Enabled = false;
            btnNo.BackColor = desactivado;

            btnLu.Enabled = false;
            btnLu.BackColor = desactivado;

            btnLr.Enabled = false;
            btnLr.BackColor = desactivado;

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Color desactivado = Color.Gray;
            Color verde = Color.FromArgb(128, 255, 128);
            Color amarillo = Color.FromArgb(255, 255, 128);
            Color piel = Color.FromArgb(255, 192, 128);
            Color naranja = Color.FromArgb(255, 128, 0);
            Color mostaza = Color.FromArgb(192, 192, 0);
            Color gasesNobles = Color.SkyBlue;
            Color DodgerBlue = Color.DodgerBlue;
            Color gold = Color.Gold;
            Color violet = Color.Violet;
            Color purple = Color.Purple;

            // listBox2.DataSource = controler.filtarGasesnoblesLinq();
            labelCategoria.Text = "Sales Basicas";



            //activar   gases nobles
            btnHe.Enabled=false;
            btnHe.BackColor = desactivado;

            btnNe.Enabled=false;
            btnNe.BackColor = desactivado;

            btnAr.Enabled=false;
            btnAr.BackColor = desactivado;

            btnKr.Enabled=false;
            btnKr.BackColor = desactivado;

            btnXe.Enabled=false;
            btnXe.BackColor = desactivado;

            btnRn.Enabled=false;
            btnRn.BackColor = desactivado;

            btnOg.Enabled=false;
            btnOg.BackColor = desactivado;
            //fin
            //---------------------------------






            //desactivar los que no son gases nobles

            //Gold

            btnH.Enabled=false;
            btnH.BackColor = desactivado;

            btnLi.Enabled=true;
            btnLi.BackColor = gold;

            btnNa.Enabled=true;
            btnNa.BackColor = gold;

            btnK.Enabled=true;
            btnK.BackColor = gold;

            btnRb.Enabled=true;
            btnRb.BackColor = gold;

            btnCs.Enabled=true;
            btnCs.BackColor = gold;

            btnFr.Enabled=true;
            btnFr.BackColor = gold;

            //Final Gold
            //--------------------------------------
            //mostaza
            btnBe.Enabled=true;
            btnBe.BackColor = mostaza;
            //btnBe.Visible= false;

            btnMg.Enabled=true;
            btnMg.BackColor = mostaza;

            btnCa.Enabled=true;
            btnCa.BackColor = mostaza;

            btnSr.Enabled=true;
            btnSr.BackColor = mostaza;

            btnBa.Enabled=true;
            btnBa.BackColor = mostaza;

            btnRa.Enabled=true;
            btnRa.BackColor = mostaza;

            //fin mostaza

            //-------------------------------------------------

            // Agregados por Erick 
            //verdes

            btnSc.Enabled=true;
            btnSc.BackColor = verde;

            btnY.Enabled=true;
            btnY.BackColor = verde;

            btnTi.Enabled=true;
            btnTi.BackColor = verde;

            btnZr.Enabled=true;
            btnZr.BackColor = verde;

            btnHf.Enabled=true;
            btnHf.BackColor = verde;

            btnRf.Enabled=true;
            btnRf.BackColor = verde;

            btnV.Enabled=true;
            btnV.BackColor = verde;

            btnNb.Enabled=true;
            btnNb.BackColor = verde;

            btnTa.Enabled=true;
            btnTa.BackColor = verde;

            btnDb.Enabled=true;
            btnDb.BackColor = verde;

            btnCr.Enabled=true;
            btnCr.BackColor = verde;

            btnMo.Enabled=true;
            btnMo.BackColor = verde;

            btnW.Enabled=true;
            btnW.BackColor = verde;

            btnSg.Enabled=true;
            btnSg.BackColor = verde;

            btnMn.Enabled=true;
            btnMn.BackColor = verde;

            btnTc.Enabled=true;
            btnTc.BackColor = verde;

            btnRe.Enabled=true;
            btnRe.BackColor = verde;

            btnBh.Enabled=true;
            btnBh.BackColor = verde;

            btnFe.Enabled=true;
            btnFe.BackColor = verde;

            btnRu.Enabled=true;
            btnRu.BackColor = verde;

            btnOs.Enabled=true;
            btnOs.BackColor = verde;

            btnHs.Enabled=true;
            btnHs.BackColor = verde;

            btnCo.Enabled=true;
            btnCo.BackColor = verde;

            btnRh.Enabled=true;
            btnRh.BackColor = verde;

            btnIr.Enabled=true;
            btnIr.BackColor = verde;

            btnMt.Enabled = true;
            btnMt.BackColor = verde;

            btnNi.Enabled = true;
            btnNi.BackColor = verde;

            btnPd.Enabled = true;
            btnPd.BackColor = verde;

            btnPt.Enabled = true;
            btnPt.BackColor = verde;

            btnDs.Enabled = true;
            btnDs.BackColor = verde;

            btnCu.Enabled = true;
            btnCu.BackColor = verde;

            btnAg.Enabled = true;
            btnAg.BackColor = verde;

            btnAu.Enabled = true;
            btnAu.BackColor = verde;

            btnRg.Enabled = true;
            btnRg.BackColor = verde;

            btnZn.Enabled = true;
            btnZn.BackColor = verde;

            btnCd.Enabled = true;
            btnCd.BackColor = verde;

            btnHg.Enabled = true;
            btnHg.BackColor = verde;

            btnCn.Enabled = true;
            btnCn.BackColor = verde;
            //----------------------------------------------------------------------
            // Naranja
            btnAl.Enabled = false;
            btnAl.BackColor = desactivado;

            btnGa.Enabled = false;
            btnGa.BackColor = desactivado;

            btnIn.Enabled = false;
            btnIn.BackColor = desactivado;

            btnNh.Enabled = false;
            btnNh.BackColor = desactivado;

            btnTl.Enabled = false;
            btnTl.BackColor = desactivado;

            btnSn.Enabled = false;
            btnSn.BackColor = desactivado;

            btnPb.Enabled = false;
            btnPb.BackColor = desactivado;

            btnFl.Enabled = false;
            btnFl.BackColor = desactivado;

            btnBi.Enabled = false;
            btnBi.BackColor = desactivado;

            btnMc.Enabled = false;
            btnMc.BackColor = desactivado;

            btnLv.Enabled = false;
            btnLv.BackColor = desactivado;

            //----------------------------------------------------------------------
            //amrillos

            //descativar metaloides


            btnB.Enabled = false;
            btnB.BackColor = desactivado;

            btnSi.Enabled = false;
            btnSi.BackColor = desactivado;

            btnGe.Enabled = false;
            btnGe.BackColor = desactivado;

            btnAs.Enabled = false;
            btnAs.BackColor = desactivado;

            btnSb.Enabled = false;
            btnSb.BackColor = desactivado;

            btnTe.Enabled = false;
            btnTe.BackColor = desactivado;

            btnPo.Enabled = false;
            btnPo.BackColor = desactivado;


            //Color papaya XD
            btnC.Enabled = false;
            btnC.BackColor = desactivado;

            btnN.Enabled = true;
            btnN.BackColor = piel;

            btnP.Enabled = true;
            btnP.BackColor = piel;

            btnO.Enabled = false;
            btnO.BackColor = desactivado;

            btnS.Enabled = true;
            btnS.BackColor = piel;

            btnSe.Enabled = false;
            btnSe.BackColor = desactivado;

            //----------------------------------------------------------------------
            //Azul - DodgerBlue
            btnF.Enabled = false;
            btnF.BackColor = desactivado;

            btnCl.Enabled = true;
            btnCl.BackColor = DodgerBlue;

            btnBr.Enabled = false;
            btnBr.BackColor = desactivado;

            btnI.Enabled = false;
            btnI.BackColor = desactivado;

            btnAt.Enabled = false;
            btnAt.BackColor = desactivado;

            btnTs.Enabled = false;
            btnTs.BackColor = desactivado;

            //----------------------------------------------------------------------
            //violeta
            btnX0.Enabled = false;
            btnX0.BackColor = desactivado;
            //----------------------------------------------------------------------
            //purpura
            btnX1.Enabled=false;
            btnX1.BackColor = desactivado;
            //----------------------------------------------------------------------





            //--Linea p�rpura y violeta descativa 
            btnLa.Enabled = true;
            btnLa.BackColor = violet;

            btnAc.Enabled = true;
            btnAc.BackColor = purple;

            btnCe.Enabled = true;
            btnCe.BackColor = violet;

            btnTh.Enabled = true;
            btnTh.BackColor = purple;

            btnPr.Enabled = true;
            btnPr.BackColor = violet;

            btnPa.Enabled = true;
            btnPa.BackColor = purple;

            btnNd.Enabled = true;
            btnNd.BackColor = violet;

            btnU.Enabled = true;
            btnU.BackColor = purple;

            btnPm.Enabled = true;
            btnPm.BackColor = violet;

            btnNp.Enabled = true;
            btnNp.BackColor = purple;

            btnSm.Enabled = true;
            btnSm.BackColor = violet;

            btnPu.Enabled = true;
            btnPu.BackColor = purple;

            btnEu.Enabled = true;
            btnEu.BackColor = violet;

            btnAm.Enabled = true;
            btnAm.BackColor = purple;

            btnGd.Enabled = true;
            btnGd.BackColor = violet;

            btnA.Enabled = true;
            btnA.BackColor = purple;

            btnTb.Enabled = true;
            btnTb.BackColor = violet;

            btnBk.Enabled = true;
            btnBk.BackColor = purple;

            btnDy.Enabled = true;
            btnDy.BackColor = violet;

            btnCf.Enabled = true;
            btnCf.BackColor = purple;

            btnHo.Enabled = true;
            btnHo.BackColor = violet;

            btnEs.Enabled = true;
            btnEs.BackColor = purple;

            btnEr.Enabled = true;
            btnEr.BackColor = violet;

            btnFm.Enabled = true;
            btnFm.BackColor = purple;

            btnTm.Enabled = true;
            btnTm.BackColor = violet;

            btnMd.Enabled = true;
            btnMd.BackColor = purple;

            btnYb.Enabled = true;
            btnYb.BackColor = violet;

            btnNo.Enabled = true;
            btnNo.BackColor = purple;

            btnLu.Enabled = true;
            btnLu.BackColor = violet;

            btnLr.Enabled = true;
            btnLr.BackColor = purple;

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Color desactivado = Color.Gray;
            Color verde = Color.FromArgb(128, 255, 128);
            Color amarillo = Color.FromArgb(255, 255, 128);
            Color piel = Color.FromArgb(255, 192, 128);
            Color naranja = Color.FromArgb(255, 128, 0);
            Color mostaza = Color.FromArgb(192, 192, 0);
            Color gasesNobles = Color.SkyBlue;
            Color DodgerBlue = Color.DodgerBlue;
            Color gold = Color.Gold;
            Color violet = Color.Violet;
            Color purple = Color.Purple;

            // listBox2.DataSource = controler.filtarGasesnoblesLinq();
            labelCategoria.Text = "Sales Neutras";



            //activar   gases nobles
            btnHe.Enabled=false;
            btnHe.BackColor = desactivado;

            btnNe.Enabled=false;
            btnNe.BackColor = desactivado;

            btnAr.Enabled=false;
            btnAr.BackColor = desactivado;

            btnKr.Enabled=false;
            btnKr.BackColor = desactivado;

            btnXe.Enabled=false;
            btnXe.BackColor = desactivado;

            btnRn.Enabled=false;
            btnRn.BackColor = desactivado;

            btnOg.Enabled=false;
            btnOg.BackColor = desactivado;
            //fin
            //---------------------------------






            //desactivar los que no son gases nobles

            //Gold

            btnH.Enabled=false;
            btnH.BackColor = desactivado;

            btnLi.Enabled=true;
            btnLi.BackColor = gold;

            btnNa.Enabled=true;
            btnNa.BackColor = gold;

            btnK.Enabled=true;
            btnK.BackColor = gold;

            btnRb.Enabled=true;
            btnRb.BackColor = gold;

            btnCs.Enabled=true;
            btnCs.BackColor = gold;

            btnFr.Enabled=true;
            btnFr.BackColor = gold;

            //Final Gold
            //--------------------------------------
            //mostaza
            btnBe.Enabled=true;
            btnBe.BackColor = mostaza;
            //btnBe.Visible= false;

            btnMg.Enabled=true;
            btnMg.BackColor = mostaza;

            btnCa.Enabled=true;
            btnCa.BackColor = mostaza;

            btnSr.Enabled=true;
            btnSr.BackColor = mostaza;

            btnBa.Enabled=true;
            btnBa.BackColor = mostaza;

            btnRa.Enabled=true;
            btnRa.BackColor = mostaza;

            //fin mostaza

            //-------------------------------------------------

            // Agregados por Erick 
            //verdes

            btnSc.Enabled=true;
            btnSc.BackColor = verde;

            btnY.Enabled=true;
            btnY.BackColor = verde;

            btnTi.Enabled=true;
            btnTi.BackColor = verde;

            btnZr.Enabled=true;
            btnZr.BackColor = verde;

            btnHf.Enabled=true;
            btnHf.BackColor = verde;

            btnRf.Enabled=true;
            btnRf.BackColor = verde;

            btnV.Enabled=true;
            btnV.BackColor = verde;

            btnNb.Enabled=true;
            btnNb.BackColor = verde;

            btnTa.Enabled=true;
            btnTa.BackColor = verde;

            btnDb.Enabled=true;
            btnDb.BackColor = verde;

            btnCr.Enabled=true;
            btnCr.BackColor = verde;

            btnMo.Enabled=true;
            btnMo.BackColor = verde;

            btnW.Enabled=true;
            btnW.BackColor = verde;

            btnSg.Enabled=true;
            btnSg.BackColor = verde;

            btnMn.Enabled=true;
            btnMn.BackColor = verde;

            btnTc.Enabled=true;
            btnTc.BackColor = verde;

            btnRe.Enabled=true;
            btnRe.BackColor = verde;

            btnBh.Enabled=true;
            btnBh.BackColor = verde;

            btnFe.Enabled=true;
            btnFe.BackColor = verde;

            btnRu.Enabled=true;
            btnRu.BackColor = verde;

            btnOs.Enabled=true;
            btnOs.BackColor = verde;

            btnHs.Enabled=true;
            btnHs.BackColor = verde;

            btnCo.Enabled=true;
            btnCo.BackColor = verde;

            btnRh.Enabled=true;
            btnRh.BackColor = verde;

            btnIr.Enabled=true;
            btnIr.BackColor = verde;

            btnMt.Enabled = true;
            btnMt.BackColor = verde;

            btnNi.Enabled = true;
            btnNi.BackColor = verde;

            btnPd.Enabled = true;
            btnPd.BackColor = verde;

            btnPt.Enabled = true;
            btnPt.BackColor = verde;

            btnDs.Enabled = true;
            btnDs.BackColor = verde;

            btnCu.Enabled = true;
            btnCu.BackColor = verde;

            btnAg.Enabled = true;
            btnAg.BackColor = verde;

            btnAu.Enabled = true;
            btnAu.BackColor = verde;

            btnRg.Enabled = true;
            btnRg.BackColor = verde;

            btnZn.Enabled = true;
            btnZn.BackColor = verde;

            btnCd.Enabled = true;
            btnCd.BackColor = verde;

            btnHg.Enabled = true;
            btnHg.BackColor = verde;

            btnCn.Enabled = true;
            btnCn.BackColor = verde;
            //----------------------------------------------------------------------
            // Naranja
            btnAl.Enabled = false;
            btnAl.BackColor = desactivado;

            btnGa.Enabled = false;
            btnGa.BackColor = desactivado;

            btnIn.Enabled = false;
            btnIn.BackColor = desactivado;

            btnNh.Enabled = false;
            btnNh.BackColor = desactivado;

            btnTl.Enabled = false;
            btnTl.BackColor = desactivado;

            btnSn.Enabled = false;
            btnSn.BackColor = desactivado;

            btnPb.Enabled = false;
            btnPb.BackColor = desactivado;

            btnFl.Enabled = false;
            btnFl.BackColor = desactivado;

            btnBi.Enabled = false;
            btnBi.BackColor = desactivado;

            btnMc.Enabled = false;
            btnMc.BackColor = desactivado;

            btnLv.Enabled = false;
            btnLv.BackColor = desactivado;

            //----------------------------------------------------------------------
            //amrillos

            //descativar metaloides


            btnB.Enabled = false;
            btnB.BackColor = desactivado;

            btnSi.Enabled = false;
            btnSi.BackColor = desactivado;

            btnGe.Enabled = false;
            btnGe.BackColor = desactivado;

            btnAs.Enabled = false;
            btnAs.BackColor = desactivado;

            btnSb.Enabled = false;
            btnSb.BackColor = desactivado;

            btnTe.Enabled = false;
            btnTe.BackColor = desactivado;

            btnPo.Enabled = false;
            btnPo.BackColor = desactivado;


            //Color papaya XD
            btnC.Enabled = false;
            btnC.BackColor = desactivado;

            btnN.Enabled = true;
            btnN.BackColor = piel;

            btnP.Enabled = true;
            btnP.BackColor = piel;

            btnO.Enabled = false;
            btnO.BackColor = desactivado;

            btnS.Enabled = true;
            btnS.BackColor = piel;

            btnSe.Enabled = false;
            btnSe.BackColor = desactivado;

            //----------------------------------------------------------------------
            //Azul - DodgerBlue
            btnF.Enabled = true;
            btnF.BackColor = DodgerBlue;

            btnCl.Enabled = true;
            btnCl.BackColor = DodgerBlue;

            btnBr.Enabled = true;
            btnBr.BackColor = DodgerBlue;

            btnI.Enabled = false;
            btnI.BackColor = desactivado;

            btnAt.Enabled = false;
            btnAt.BackColor = desactivado;

            btnTs.Enabled = false;
            btnTs.BackColor = desactivado;

            //----------------------------------------------------------------------
            //violeta
            btnX0.Enabled = false;
            btnX0.BackColor = desactivado;
            //----------------------------------------------------------------------
            //purpura
            btnX1.Enabled=false;
            btnX1.BackColor = desactivado;
            //----------------------------------------------------------------------





            //--Linea p�rpura y violeta descativa 
            btnLa.Enabled = true;
            btnLa.BackColor = violet;

            btnAc.Enabled = true;
            btnAc.BackColor = purple;

            btnCe.Enabled = true;
            btnCe.BackColor = violet;

            btnTh.Enabled = true;
            btnTh.BackColor = purple;

            btnPr.Enabled = true;
            btnPr.BackColor = violet;

            btnPa.Enabled = true;
            btnPa.BackColor = purple;

            btnNd.Enabled = true;
            btnNd.BackColor = violet;

            btnU.Enabled = true;
            btnU.BackColor = purple;

            btnPm.Enabled = true;
            btnPm.BackColor = violet;

            btnNp.Enabled = true;
            btnNp.BackColor = purple;

            btnSm.Enabled = true;
            btnSm.BackColor = violet;

            btnPu.Enabled = true;
            btnPu.BackColor = purple;

            btnEu.Enabled = true;
            btnEu.BackColor = violet;

            btnAm.Enabled = true;
            btnAm.BackColor = purple;

            btnGd.Enabled = true;
            btnGd.BackColor = violet;

            btnA.Enabled = true;
            btnA.BackColor = purple;

            btnTb.Enabled = true;
            btnTb.BackColor = violet;

            btnBk.Enabled = true;
            btnBk.BackColor = purple;

            btnDy.Enabled = true;
            btnDy.BackColor = violet;

            btnCf.Enabled = true;
            btnCf.BackColor = purple;

            btnHo.Enabled = true;
            btnHo.BackColor = violet;

            btnEs.Enabled = true;
            btnEs.BackColor = purple;

            btnEr.Enabled = true;
            btnEr.BackColor = violet;

            btnFm.Enabled = true;
            btnFm.BackColor = purple;

            btnTm.Enabled = true;
            btnTm.BackColor = violet;

            btnMd.Enabled = true;
            btnMd.BackColor = purple;

            btnYb.Enabled = true;
            btnYb.BackColor = violet;

            btnNo.Enabled = true;
            btnNo.BackColor = purple;

            btnLu.Enabled = true;
            btnLu.BackColor = violet;

            btnLr.Enabled = true;
            btnLr.BackColor = purple;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                button3.PerformClick();
                checkBox1.Checked= false;
                checkBox1.Checked= true;
            }


            string mensajeFinal = "";
            string reaccion = "";
            bool bandera = false;


            string s1 = siglaA.Text;
            string s2 = siglaB.Text;
            string s3 = Sigla3.Text;
            string s4 = sigla4.Text;

            int v1 = 0;
            int v2 = 0;
            int v3 = 0;
            int v4 = 0;


            try
            {
                v1 = Convert.ToInt32(valenciaA.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show("No agrego un numero entero, por defecto se agrega 1 a la valencia A");
                v1 = 1;
            }



            try
            {

                v2 = Convert.ToInt32(valenciaB.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("No agrego un numero entero, por defecto se agrega 1 a la valencia B");
                v2=1;
            }




            try
            {

                v3 = Convert.ToInt32(Valencia3.Text);
            }
            catch (Exception ex)
            {
               // MessageBox.Show("No agrego un numero entero, por defecto se agrega 1 a la valencia B");
                v3=1;
            }



            try
            {

                v4= Convert.ToInt32(valencia4.Text);
            }
            catch (Exception ex)
            {
               // MessageBox.Show("No agrego un numero entero, por defecto se agrega 1 a la valencia B");
                v4=1;
            }




            if (Oxidosmetalicos.Checked )
            {

                string mensaje  = controler.oxidosMetalicosR(s1,s2,v1,v2);

                if(mensaje == String.Empty)
                {
                   // MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Oxidos Metalicos";
                    bandera=false;

                }
                else
                {
                   // MessageBox.Show(mensaje, "Oxidos Metalicos");

                    mensajeFinal=mensaje;
                    reaccion="Oxidos Metalicos";
                    bandera=true;
                }
                
            }


            if (OxidosNometalicos.Checked)
            {

                string mensaje = controler.oxidosNoMetalicosR(s1, s2, v1, v2);

                if (mensaje == String.Empty)
                {
                    //MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Oxidos No Metalicos";
                    bandera=false;

                }
                else
                {
                    //MessageBox.Show(mensaje, "Oxidos No Metalicos");
                    mensajeFinal=mensaje;
                    reaccion="Oxidos No Metalicos";
                    bandera=true;
                }

            }





            if (btnPer�xidos.Checked)
            {

                string mensaje = controler.peroxidosR(s1, s2, v1, v2);

                if (mensaje == String.Empty)
                {
                    //MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Per�xidos";
                    bandera=false;
                }
                else
                {
                    // MessageBox.Show(mensaje, "Per�xidos");
                    mensajeFinal=mensaje;
                    reaccion="Per�xidos";
                    bandera=true;
                }

            }



            if (btnSuperOxidos.Checked)
            {

                string mensaje = controler.superOxidosR(s1, s2, v1, v2);

                if (mensaje == String.Empty)
                {
                    // MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="SuperOxidos";
                    bandera=false;
                }
                else
                {
                  //  MessageBox.Show(mensaje, "SuperOxidos");
                    mensajeFinal=mensaje;
                    reaccion="SuperOxidos";
                    bandera=true;
                }

            }


            if (Hidruros.Checked)
            {

                string mensaje = controler.oxidosMetalicosR(s1, s2, v1, v2);

                if (mensaje == String.Empty)
                {
                  //  MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Hidruros";
                    bandera=false;

                }
                else
                {
                    //MessageBox.Show(mensaje, "Hidruros");
                    mensajeFinal=mensaje;
                    reaccion="Hidruros";
                    bandera=true;
                }

            }



            if (Ozonidos.Checked)
            {

                string mensaje = controler.OzonidosR(s1, s2, v1, v2);

                if (mensaje == String.Empty)
                {
                    //  MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Ozonidos";
                    bandera=false;

                }
                else
                {
                   // MessageBox.Show(mensaje, "Ozonidos");
                    mensajeFinal=mensaje;
                    reaccion="Ozonidos";
                    bandera=true;
                }

            }





            if (Hidracidos.Checked)
            {
                if (gaseosos.Checked==true)
                {
                    
                    //listBox1.DataSource = controler.filtrarHidracidosGaseosos(siglaA.Text);
                    string mensaje = controler.gaseosoR(s1, s2, v1, v2);
                    if (mensaje == String.Empty)
                    {
                        //MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        mensajeFinal="Error. Por favor verifique su reaccion";
                        reaccion="Hidracidos gaseosos";
                        bandera=false;
                    }
                    else
                    {
                       // MessageBox.Show(mensaje, "Hidracido gaseoso");
                        mensajeFinal=mensaje;
                        reaccion="Hidracido gaseoso";
                        bandera=true;
                    }

                }
                else if (acidos.Checked==true)
                {
                    //listBox1.DataSource = controler.filtrarHidracidosAcidos(siglaA.Text);

                    string mensaje = controler.acidoR(s1, s2, v1, v2);
                    if (mensaje == String.Empty)
                    {
                        //MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        mensajeFinal="Error. Por favor verifique su reaccion";
                        reaccion="Hidracidos acidos";
                        bandera=false;
                    }
                    else
                    {
                        //MessageBox.Show(mensaje, "Hidracido Acido");
                        mensajeFinal=mensaje;
                        reaccion="Hidracido Acido";
                        bandera=true;
                    }

                }

            }



            if (btnSalesNeutras.Checked)
            {

                string mensaje = controler.salesNeutrasR(s1, s2, v1, v2);

                if (mensaje == String.Empty)
                {
                    //MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Sales Neutras";
                    bandera=false;

                }
                else
                {
                    //MessageBox.Show(mensaje, "SalesNeutras");
                    mensajeFinal=mensaje;
                    reaccion="SalesNeutras";
                    bandera=true;
                }

            }




            if (btnPeroxoacidos.Checked)
            {

                string mensaje = controler.peroxoacidosR(s1, s2, v1, v2);

                if (mensaje == String.Empty)
                {
                 //   MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Peroxoacidos";
                    bandera=false;
                }
                else
                {
                    //MessageBox.Show(mensaje, "SalesNeutras");
                    mensajeFinal=mensaje;
                    reaccion="Peroxoacidos";
                    bandera=true;
                }

            }






            if (btnSalesBasiscas.Checked)
            {

                string mensaje = controler.salesBasiscasR(s1, s2,s3, v1, v2,v3);

                if (mensaje == String.Empty)
                {
                    //   MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Sales Basicas";
                    bandera=false;

                }
                else
                {
                   // MessageBox.Show(mensaje, "Sales Basiscas");
                    mensajeFinal=mensaje;
                    reaccion="Sales Basiscas";
                    bandera=true;
                }

            }


            if (Hidroxidos.Checked)
            {

                string mensaje = controler.hidroxidosR(s1, s2, s3, v1, v2, v3);

                if (mensaje == String.Empty)
                {
                   // MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Hidroxidos";
                    bandera=false;
                }
                else
                {
                  //  MessageBox.Show(mensaje, "Hidroxidos");
                    mensajeFinal=mensaje;
                    reaccion="Hidroxidos";
                    bandera=true;
                }

            }



            if (btnOxacidos.Checked)
            {

                string mensaje = controler.oxacidosR(s1, s2, s3, v1, v2, v3);

                if (mensaje == String.Empty)
                {
                   // MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Oxacidos";
                    bandera=false;

                }
                else
                {
                  //  MessageBox.Show(mensaje, "Ox�cidos");
                    mensajeFinal=mensaje;
                    reaccion="Ox�cidos";
                    bandera=true;
                }

            }



            if (btnSalesAcidas.Checked)
            {

                string mensaje = controler.salesAcidasR(s1, s2, s3, v1, v2, v3);

                if (mensaje == String.Empty)
                {
                    //MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Sales Acidas";
                    bandera=false;

                }
                else
                {
                   // MessageBox.Show(mensaje, "Sales Acidas");
                    mensajeFinal=mensaje;
                    reaccion="Sales Acidas";
                    bandera=true;
                }

            }


            if (btnTioacidos.Checked)
            {

                string mensaje = controler.tioacidosR(s1, s2, s3,s4, v1, v2, v3,v4);

                if (mensaje == String.Empty)
                {
                    // MessageBox.Show("Error. Por favor verifique los elementos seleccionados para mostrar una reacci�n o filtre los elementos por categor�a para evitar errores", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mensajeFinal="Error. Por favor verifique su reaccion";
                    reaccion="Tioacidos";
                    bandera=false;

                }
                else
                {
                    //MessageBox.Show(mensaje, "Tioacidos");
                    mensajeFinal=mensaje;
                    reaccion="Tioacidos";
                    bandera=true;
                }

            }



            if (bandera==false && checkBox1.Checked)
            {
                checkBox1.Checked= false;
                checkBox1.Checked= true;
                button2.PerformClick();
            }
            else if (bandera==true && checkBox1.Checked)
            {
                MessageBox.Show(mensajeFinal, reaccion);
                labelResultado.Text =(mensajeFinal);
                bandera=false;
               // checkBox1.Checked= false;
                //checkBox1.Checked= true;
                labelCategoria.Visible=true;
                siglaA.Visible=true;
                siglaB.Visible=true;
                valenciaA.Visible=true;
                valenciaB.Visible=true;
            }

            else if (bandera==true)
            {
                MessageBox.Show(mensajeFinal, reaccion);
                labelResultado.Text =(mensajeFinal);
                bandera=false;
                

            }
            else
            {
              
                MessageBox.Show(mensajeFinal, "Error con "+reaccion, MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            //



        }//fin boton

        private void ValPeroxido_TextChanged(object sender, EventArgs e)
        {

        }
    }

}