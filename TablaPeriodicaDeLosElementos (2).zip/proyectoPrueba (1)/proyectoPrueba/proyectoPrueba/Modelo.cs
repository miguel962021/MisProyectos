﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoPrueba
{
    internal class Modelo
    {

        public List<ElementoModelo> origen = new List<ElementoModelo>();

        //public string metal = "METAL" ;
        //public string noMetal = "NO METAL";
        //public string otro = "OTRO";

        public Modelo()
        {
            origen.Add(new ElementoModelo() { nombre="Hidrogeno",     sigla="H",     pesoAtomico=1,       tipo="NO METAL"       , valencias="-1, +1" });
            origen.Add(new ElementoModelo() { nombre="HELIO    ",     sigla="He",    pesoAtomico=2,       tipo="Gases nobles"   , valencias="0" });
            origen.Add(new ElementoModelo() { nombre="LITIO    ",     sigla="Li",    pesoAtomico=3,       tipo="METAL"          , valencias="+1" });
            origen.Add(new ElementoModelo() { nombre="BERILIO  ",     sigla="Be",    pesoAtomico=4,       tipo="METAL"          , valencias="+2" });
            origen.Add(new ElementoModelo() { nombre="Boro     ",     sigla="B",     pesoAtomico=5,       tipo= "Metaloides"    , valencias="+3" });
            origen.Add(new ElementoModelo() { nombre="Carbono  ",     sigla="C",     pesoAtomico=6,       tipo="NO METAL"       , valencias="-4, +2, +4" });
            origen.Add(new ElementoModelo() { nombre="Nitrogeno",     sigla="N",     pesoAtomico=7,       tipo="NO METAL"       , valencias="-3, +3 ,+5" });
            origen.Add(new ElementoModelo() { nombre="Oxigeno  ",     sigla="O",     pesoAtomico=8,       tipo="NO METAL"       , valencias="-1, -2" });
            origen.Add(new ElementoModelo() { nombre="Fluor    ",     sigla="F",     pesoAtomico=9,       tipo="NO METAL"       , valencias="-1" });
            origen.Add(new ElementoModelo() { nombre="Neon     ",     sigla="Ne",    pesoAtomico=10,      tipo="Gases nobles"   , valencias="0" });
            origen.Add(new ElementoModelo() { nombre="Sodio    ",     sigla="Na",    pesoAtomico=11,      tipo="METAL"          , valencias="+1" });
            origen.Add(new ElementoModelo() { nombre="Magnesio ",     sigla="Mg",    pesoAtomico=12,      tipo="METAL"          , valencias="+2" });
            origen.Add(new ElementoModelo() { nombre="Aluminio ",     sigla="Al",    pesoAtomico=13,      tipo="METAL"          , valencias="+3" });
            origen.Add(new ElementoModelo() { nombre="Silicio  ",     sigla="Si",    pesoAtomico=14,      tipo="Metaloides"     , valencias="-4, +2, +4" });
            origen.Add(new ElementoModelo() { nombre="Fosforo  ",     sigla="P",     pesoAtomico=15,      tipo="NO METAL"       , valencias="-3, +3 ,+5" });
            origen.Add(new ElementoModelo() { nombre="Azufre   ",     sigla="S",     pesoAtomico=16,      tipo="NO METAL"       , valencias="-2, +2, +4, +6" });
            origen.Add(new ElementoModelo() { nombre="Cloro    ",     sigla="CL",    pesoAtomico=17,      tipo="NO METAL"       , valencias="-1, +1, +3, +5, +7" });
            origen.Add(new ElementoModelo() { nombre="Argon    ",     sigla="Ar",    pesoAtomico=18,      tipo="Gases nobles"   , valencias="0" });
            origen.Add(new ElementoModelo() { nombre="Potasio  ",     sigla="K",     pesoAtomico=19,      tipo="METAL"          , valencias="+1" });
            origen.Add(new ElementoModelo() { nombre="Calcio   ",     sigla="Ca",    pesoAtomico=20,      tipo="METAL"          , valencias="+2" });
            origen.Add(new ElementoModelo() { nombre="Escandio ",     sigla="Sc",    pesoAtomico=21,      tipo="METAL"          , valencias="+3" });
            origen.Add(new ElementoModelo() { nombre="Titanio  ",     sigla="Ti",    pesoAtomico=22,      tipo="METAL"          , valencias="+2, +3, +4" });
            origen.Add(new ElementoModelo() { nombre="Vanadio  ",     sigla="V",     pesoAtomico=23,      tipo="METAL"          , valencias="+2, +3, +4, +5" });
            origen.Add(new ElementoModelo() { nombre="Cromo    ",     sigla="Cr",    pesoAtomico=24,      tipo="METAL"          , valencias="+2, +3, +6" });
            origen.Add(new ElementoModelo() { nombre="Manganeso",     sigla="Mn",    pesoAtomico=25,      tipo="METAL"          , valencias="+2, +3, +4, +6, +7" });
            origen.Add(new ElementoModelo() { nombre="Hierro   ",     sigla="Fe",    pesoAtomico=26,      tipo="METAL"          , valencias="+2, +3" });
            origen.Add(new ElementoModelo() { nombre="Cobalto  ",     sigla="Co",    pesoAtomico=27,      tipo="METAL"          , valencias="+2, +3" });
            origen.Add(new ElementoModelo() { nombre="Niquel   ",     sigla="Ni",    pesoAtomico=28,      tipo="METAL"          , valencias="+2, +3" });
            origen.Add(new ElementoModelo() { nombre="Cobre    ",     sigla="Cu",    pesoAtomico=29,      tipo="METAL"          , valencias="+1, +2" });
            origen.Add(new ElementoModelo() { nombre="Zinc     ",     sigla="Zn",    pesoAtomico=30,      tipo="METAL"          , valencias="+2" });
            origen.Add(new ElementoModelo() { nombre="Galio    ",     sigla="Ga",    pesoAtomico=31,      tipo="METAL"          , valencias="+1, +3" });
            origen.Add(new ElementoModelo() { nombre="Germanio ",     sigla="Ge",    pesoAtomico=32,      tipo="Metaloides"     , valencias="-4, +2, +4" });
            origen.Add(new ElementoModelo() { nombre="Arsenico ",     sigla="As",    pesoAtomico=33,      tipo="Metaloides"     , valencias="-3, +3, +5" });
            origen.Add(new ElementoModelo() { nombre="Selenio  ",     sigla="Se",    pesoAtomico=34,      tipo="NO METAL"       , valencias="-2, +2, +4, +6" });
            origen.Add(new ElementoModelo() { nombre="Bromo    ",     sigla="Br",    pesoAtomico=35,      tipo="NO METAL"       , valencias="-1, +1, +3, +5, +7" });
            origen.Add(new ElementoModelo() { nombre="Kripton  ",     sigla="Kr",    pesoAtomico=36,      tipo="Gases nobles"   , valencias="0" });
            origen.Add(new ElementoModelo() { nombre="Rubidio  ",     sigla="Rb",    pesoAtomico=37,      tipo="METAL"          , valencias="+1" });
            origen.Add(new ElementoModelo() { nombre="Estroncio",     sigla="Sr",    pesoAtomico=38,      tipo="METAL"          , valencias="+2" });
            origen.Add(new ElementoModelo() { nombre="Itrio    ",     sigla="Y",     pesoAtomico=39,      tipo="METAL"          , valencias="+3" });
            origen.Add(new ElementoModelo() { nombre="Zirconio ",     sigla="Zr",    pesoAtomico=40,      tipo="METAL"          , valencias="+3, +4" });
            origen.Add(new ElementoModelo() { nombre="Niobio   ",     sigla="Nb",    pesoAtomico=41,      tipo="METAL"          , valencias="+2, +3, +4, +5" });
            origen.Add(new ElementoModelo() { nombre="Molibdeno",     sigla="Mo",    pesoAtomico=42,      tipo="METAL"          , valencias="+2, +3, +4, +5, +6" });
            origen.Add(new ElementoModelo() { nombre="Tecnecio ",     sigla="Tc",    pesoAtomico=43,      tipo="METAL"          , valencias="+4, +5, +6, +7" });
            origen.Add(new ElementoModelo() { nombre="Rutenio  ",     sigla="Ru",    pesoAtomico=44,      tipo="METAL"          , valencias="+2, +3, +4, +5, +6, +7, +8" });
            origen.Add(new ElementoModelo() { nombre="Rodio    ",     sigla="Rh",    pesoAtomico=45,      tipo="METAL"          , valencias="+2, +3, +4, +5, +6" });
            origen.Add(new ElementoModelo() { nombre="Paladio  ",     sigla="Pd",    pesoAtomico=46,      tipo="METAL"          , valencias="+2, +4" });
            origen.Add(new ElementoModelo() { nombre="Plata    ",     sigla="Ag",    pesoAtomico=47,      tipo="METAL"          , valencias="+1" });
            origen.Add(new ElementoModelo() { nombre="Cadmio   ",     sigla="Cd",    pesoAtomico=48,      tipo="METAL"          , valencias="+2" });
            origen.Add(new ElementoModelo() { nombre="Indio    ",     sigla="In",    pesoAtomico=49,      tipo="METAL"          , valencias="+1, +3" });
            origen.Add(new ElementoModelo() { nombre="Estaño   ",     sigla="Sn",    pesoAtomico=50,      tipo="METAL"          , valencias="+2, +4" });
            origen.Add(new ElementoModelo() { nombre="Antimonio",     sigla="Sb",    pesoAtomico= 51,     tipo="Metaloides"     , valencias="-3, +3, +5" });
            origen.Add(new ElementoModelo() { nombre="Telurio  ",     sigla="Te",    pesoAtomico= 52,     tipo="Metaloides"     , valencias="-2, +4, +6" });
            origen.Add(new ElementoModelo() { nombre="Yodo",          sigla="I ",    pesoAtomico=53,      tipo="NO METAL"       , valencias="-1, +1, +3, +5, +7" });
            origen.Add(new ElementoModelo() { nombre="Xenón",         sigla="Xe",    pesoAtomico=54,      tipo="Gases nobles"   , valencias="0, +2, +4" });
            origen.Add(new ElementoModelo() { nombre="Cesio",         sigla="Cs",    pesoAtomico=55,      tipo="METAL"          , valencias="+1" });
            origen.Add(new ElementoModelo() { nombre="Bario",         sigla="Ba",    pesoAtomico=56,      tipo="METAL"          , valencias="+2" });
            origen.Add(new ElementoModelo() { nombre="Lantano",       sigla="La",    pesoAtomico=57,      tipo="METAL"          , valencias="+3" });
            origen.Add(new ElementoModelo() { nombre="Cerio ",        sigla="Ce",    pesoAtomico=58,      tipo="METAL"          , valencias="3" });
            origen.Add(new ElementoModelo() { nombre="Praseodimio",   sigla="Pr",    pesoAtomico=59,      tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Neodimio",      sigla="Nd",    pesoAtomico=60,      tipo="METAL"          , valencias="+2, +3, +4" });
            origen.Add(new ElementoModelo() { nombre="Prometio",      sigla="Pm",    pesoAtomico=61,      tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Samario",       sigla= "Sm",   pesoAtomico=62,      tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Europio",       sigla="Eu",    pesoAtomico=63,      tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Gadolinio",     sigla="Gd",    pesoAtomico=64,      tipo="METAL"          , valencias="+3" });
            origen.Add(new ElementoModelo() { nombre="Terbio",        sigla="Tb",    pesoAtomico = 65,    tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Disprosio",     sigla="Dy",    pesoAtomico = 66,    tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Holmio",        sigla="Ho",    pesoAtomico = 67,    tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Erbio",         sigla="Er",    pesoAtomico = 68,    tipo="METAL"          , valencias="+3" });
            origen.Add(new ElementoModelo() { nombre="Tulio",         sigla="Tm",    pesoAtomico = 69,    tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Iterbio",       sigla="Yb",    pesoAtomico = 70,    tipo="METAL"          , valencias="+3" });
            origen.Add(new ElementoModelo() { nombre="Lutecio",       sigla="Lu",    pesoAtomico = 71,    tipo="METAL"          , valencias="0, +1 (Lu+), +2 (Lu2+), +3 (Lu3+)" });
            origen.Add(new ElementoModelo() { nombre="Hafnio ",       sigla="Hf",    pesoAtomico = 72,    tipo="METAL"          , valencias="+3, +4" });
            origen.Add(new ElementoModelo() { nombre="Tántalo",       sigla="Ta",    pesoAtomico = 73,    tipo="METAL"          , valencias="+3, +4, +5" });
            origen.Add(new ElementoModelo() { nombre="Wolframio",     sigla="W",     pesoAtomico = 74,    tipo="METAL"          , valencias="+2, +3, +4,+5, +6" });
            origen.Add(new ElementoModelo() { nombre="Renio",         sigla="Re",    pesoAtomico = 75,    tipo="METAL"          , valencias="+2, +3 (+4,+6,+7))" });
            origen.Add(new ElementoModelo() { nombre="Osmio",         sigla="Os",    pesoAtomico = 76,    tipo="METAL"          , valencias="+2, +3, +4,+5, +6, +7, +8" });
            origen.Add(new ElementoModelo() { nombre="Iridio",        sigla="Ir",    pesoAtomico = 77,    tipo="METAL"          , valencias="+2, +3, +4,+5, +6" });
            origen.Add(new ElementoModelo() { nombre="Platino",       sigla="Pt",    pesoAtomico = 78,    tipo="METAL"          , valencias="+2, +4" });
            origen.Add(new ElementoModelo() { nombre="Oro",           sigla="Au",    pesoAtomico = 79,    tipo="METAL"          , valencias="+1, +3" });
            origen.Add(new ElementoModelo() { nombre="Mercurio",      sigla="Hg",    pesoAtomico = 80,    tipo="METAL"          , valencias="+1, +2" });
            origen.Add(new ElementoModelo() { nombre="Talio",         sigla="Ti",    pesoAtomico = 81,    tipo="METAL"          , valencias="+1, +3" });
            origen.Add(new ElementoModelo() { nombre="Plomo",         sigla="Pb",    pesoAtomico = 82,    tipo="METAL"          , valencias="+2, +4" });
            origen.Add(new ElementoModelo() { nombre="Bismuto",       sigla="Bi",    pesoAtomico = 83,    tipo="METAL"          , valencias="+3, +5" });
            origen.Add(new ElementoModelo() { nombre="Polonio",       sigla="Po",    pesoAtomico = 84,    tipo="Metaloides"     , valencias="-2, +4, +6" });
            origen.Add(new ElementoModelo() { nombre="Astato",        sigla="At",    pesoAtomico = 85,    tipo="Metaloides"     , valencias="-1, -7" });
            origen.Add(new ElementoModelo() { nombre="Radón",         sigla="Rn",    pesoAtomico = 86,    tipo="Gases nobles"   , valencias="0, +2, +4" });
            origen.Add(new ElementoModelo() { nombre="Francio",       sigla="Fr",    pesoAtomico = 87,    tipo="METAL"          , valencias="+1" });
            origen.Add(new ElementoModelo() { nombre="Radio",         sigla="Ra",    pesoAtomico = 88,    tipo="METAL"          , valencias="+2" });
            origen.Add(new ElementoModelo() { nombre="Actinio",       sigla="Ac",    pesoAtomico = 89,    tipo="METAL"          , valencias="+3" });
            origen.Add(new ElementoModelo() { nombre="Torio",         sigla="Th",    pesoAtomico = 90,    tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Protactinio",   sigla="Pa",    pesoAtomico = 91,    tipo="METAL"          , valencias="+4, +5" });
            origen.Add(new ElementoModelo() { nombre="Uranio",        sigla="U",     pesoAtomico = 92,    tipo="METAL"          , valencias="+6" });
            origen.Add(new ElementoModelo() { nombre="Neptunio",      sigla="Np",    pesoAtomico = 93,    tipo="METAL"          , valencias="+4, +5" });
            origen.Add(new ElementoModelo() { nombre="Plutonio",      sigla="Pu",    pesoAtomico = 94,    tipo="METAL"          , valencias="+3, +4, +5, +6" });
            origen.Add(new ElementoModelo() { nombre="Americio",      sigla="Am",    pesoAtomico = 95,    tipo="METAL"          , valencias="+3, +4, +5, +6" });
            origen.Add(new ElementoModelo() { nombre="Curio",         sigla="Cm",    pesoAtomico = 96,    tipo="METAL"          , valencias="+3, +4" });
            origen.Add(new ElementoModelo() { nombre="Berkelio",      sigla="Bk",    pesoAtomico = 97,    tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Californio",    sigla="Cf",    pesoAtomico = 98,    tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Einstenio",     sigla="Es",    pesoAtomico = 99,    tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Fermio",        sigla="Fm",    pesoAtomico = 100,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Mendelevio",    sigla="Md",    pesoAtomico = 101,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Nobelio",       sigla="No",    pesoAtomico = 102,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Lawrencio",     sigla="Lr",    pesoAtomico = 103,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Rutherfordio",  sigla="Rf",    pesoAtomico = 104,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Dubnio",        sigla="Db",    pesoAtomico = 105,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Seaborgio",     sigla="Sg",    pesoAtomico = 106,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Bohrio",        sigla="Bh",    pesoAtomico = 107,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Hasio",         sigla="Hs",    pesoAtomico = 108,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Meitnerio",     sigla="Mt",    pesoAtomico = 109,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Darmstatio",    sigla="Ds",    pesoAtomico = 110,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Roentgenio",    sigla="Rg",    pesoAtomico = 111,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Copernicio",    sigla="Cn",    pesoAtomico = 112,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Nihonio",       sigla="Nh",    pesoAtomico = 103,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Flerovio",      sigla="Fi",    pesoAtomico = 114,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Moscovio",      sigla="Mc",    pesoAtomico = 115,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Livermorio",    sigla="Lv",    pesoAtomico = 116,   tipo="METAL"          , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Teneso",        sigla="Ts",    pesoAtomico = 117,   tipo="NO METAL"       , valencias="" });
            origen.Add(new ElementoModelo() { nombre="Oganessón",     sigla="Og",    pesoAtomico = 118,   tipo="Gases nobles"   , valencias="" });

        }
    }    
}
