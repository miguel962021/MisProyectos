﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoPrueba
{
    internal class ModeloGas
    {
        public List<RadicalesModelo> origen = new List<RadicalesModelo>();

        public ModeloGas()
        {
            origen.Add(new RadicalesModelo() { nombre = "Fluoruro", sigla = "F", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "Hidrogeno", sigla = "H", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "Cloruro", sigla = "Cl", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "bromuro", sigla = "Br", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "yoduro", sigla = "I", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "sulfuro", sigla = "S", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "selenuro", sigla = "Se", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "telururo", sigla = "Te", valencia = 2 });
           
            origen.Add(new RadicalesModelo() { nombre = "Cianuro", sigla = "Cn", valencia = 2 });

        }

    }
}
