﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoPrueba
{
    internal class Modelo3
    {

        public List<Ozonidos> origen = new List<Ozonidos>();

        public Modelo3()
        {
            origen.Add(new Ozonidos() { nombre="Ozonido", sigla="O", valencia=+3 });

        }
    }
}
