﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoPrueba
{
    internal class tioacidos
    {
        public List<RadicalesModelo> origen = new List<RadicalesModelo>();

        public tioacidos()
        {
            origen.Add(new RadicalesModelo() { nombre="Hidr", sigla="H", valencia=-1 });
            origen.Add(new RadicalesModelo() { nombre="Fosfuro", sigla="P", valencia=-3 });
            origen.Add(new RadicalesModelo() { nombre="Sulfuro", sigla="S", valencia=-2 });
            origen.Add(new RadicalesModelo() { nombre="Oxido", sigla="O", valencia=-1 });
      

        }

    }
}
