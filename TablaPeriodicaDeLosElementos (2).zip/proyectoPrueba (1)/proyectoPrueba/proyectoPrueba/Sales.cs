﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoPrueba
{
    internal class Sales
    {
        public List<RadicalesModelo> origen = new List<RadicalesModelo>();

        public Sales()
        {
            origen.Add(new RadicalesModelo() { nombre = "hidroxido", sigla = "OH", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "cloruro", sigla = "Cl", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "clorito", sigla = "ClO", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "sulfuro", sigla = "S", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "sulfato", sigla = "SO", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "nitruro", sigla = "N", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "nitrato", sigla = "NO", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "fluoruro", sigla = "F", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "bromuro", sigla = "Br", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "fosfato", sigla = "PO", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "hidrogeno", sigla = "H", valencia = 2 });
            origen.Add(new RadicalesModelo() { nombre = "oxocarbonato", sigla = "CO", valencia = 2 });

        }
    }
}
