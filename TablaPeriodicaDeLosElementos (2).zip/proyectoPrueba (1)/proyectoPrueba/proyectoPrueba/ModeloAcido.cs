﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoPrueba
{
    internal class ModeloAcido
    {

        public List<RadicalesModelo> origen = new List<RadicalesModelo>();

        public ModeloAcido()
        {
            origen.Add(new RadicalesModelo() { nombre = "fluorhídrico", sigla = "F", valencia = -1 });
            origen.Add(new RadicalesModelo() { nombre = "Ácido", sigla = "H", valencia = -1 });
            origen.Add(new RadicalesModelo() { nombre = "clorhídrico", sigla = "Cl", valencia = -1 });
            origen.Add(new RadicalesModelo() { nombre = "bromhídrico", sigla = "Br", valencia = -1 });
            origen.Add(new RadicalesModelo() { nombre = "yodhídrico", sigla = "I", valencia = -1 });
            origen.Add(new RadicalesModelo() { nombre = "sulfhídrico", sigla = "S", valencia = -1 });
            origen.Add(new RadicalesModelo() { nombre = "selenhídrico", sigla = "Se", valencia = -1 });
            origen.Add(new RadicalesModelo() { nombre = "telurhídrico", sigla = "Te", valencia = -1 });
            origen.Add(new RadicalesModelo() { nombre = "cianhídrico", sigla = "Cn", valencia = -1 });

        }
    }
}
