﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoPrueba
{
    internal class ElementoModelo
    {
      
        public string nombre      { get; set; }
        public string sigla       { get; set; }
        public int    pesoAtomico { get; set; }
        public string tipo        { get; set; }
        public string valencias { get; set; }


    }
}
