﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoPrueba
{
    internal class Modelo2
    {
        public List<RadicalesModelo> origen = new List<RadicalesModelo>();

        public Modelo2()
        {
            origen.Add(new RadicalesModelo() { nombre="Fluoruro"    , sigla="F",  valencia=-1 });
            origen.Add(new RadicalesModelo() { nombre="Hidruro"     , sigla="H", valencia=-1 });
            origen.Add(new RadicalesModelo() { nombre="Cloruro"     , sigla="Cl", valencia=-1 });
            origen.Add(new RadicalesModelo() { nombre="Bromuro"     , sigla="Br", valencia=-1 });
            origen.Add(new RadicalesModelo() { nombre="Yoduro"      , sigla="I", valencia=-1 });
            origen.Add(new RadicalesModelo() { nombre="Óxido"       , sigla="O", valencia=-2 });
            origen.Add(new RadicalesModelo() { nombre="Sulfuro"     , sigla="S", valencia=-2 });
            origen.Add(new RadicalesModelo() { nombre="Selenuro"    , sigla="Se", valencia=-2 });
            origen.Add(new RadicalesModelo() { nombre="Nitruro"     , sigla="N", valencia=-3 });
            origen.Add(new RadicalesModelo() { nombre="Fosfuro"     , sigla="P", valencia=-3 });
            origen.Add(new RadicalesModelo() { nombre="Carburo"     , sigla="C", valencia=-4 });

        }
    }
}
