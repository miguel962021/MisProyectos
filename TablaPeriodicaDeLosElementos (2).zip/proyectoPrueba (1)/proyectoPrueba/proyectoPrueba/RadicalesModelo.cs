﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectoPrueba
{
    internal class RadicalesModelo
    {
        public string nombre { get; set; }
        public string sigla { get; set; }
        public int    valencia { get; set; }
    }
}
